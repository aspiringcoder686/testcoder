Class : AdditionalReferencesRepository
Method name : LoadRefDataTypesAsync
No of Lines : 8
Query : 
{
            var group = await securedEntityManger.FindAllAsync<AmUserGroup>(
                q => q
                    .Include(hv => hv.AmUserGroupFunctions)
                        .ThenInclude(f => f.AmRefFunctionAccessLevel)
                            .ThenInclude(ra => ra.FunctionCodeNavigation)
                    .AsNoTracking()
                    .AsSplitQuery()
            );

