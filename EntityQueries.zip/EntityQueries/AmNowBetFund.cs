Class : TaskSchedulerRepository
Method name : FindAllFunds
No of Lines : 6
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmNowBetFund>(
                q => q.Include(f => f.NowBetFundStatusCodeNavigation)
                .Include(f => f.FundGroupShortNameNavigation)
                .Include(f => f.NowBetFundCurrencyNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : ReferenceDataManager
Method name : FindAllReferenceDataFund
No of Lines : 5
Query : 
{
            var s = await securedEntityManger.FindAllAsync<AmNowBetFund>(q => q
                .Include(f => f.FundGroupShortNameNavigation)
                .Include(f => f.NowBetFundCurrencyNavigation)
                .Include(f => f.NowBetFundStatusCodeNavigation)
                .AsNoTracking());

