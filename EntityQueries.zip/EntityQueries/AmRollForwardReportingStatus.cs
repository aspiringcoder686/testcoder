Class : ViewAdministrationRepository
Method name : FindRollForwardPeriodStatusesByType
No of Lines : 9
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmRollForwardReportingStatus>(
                q => q.Where(rf => rf.RollForwardTypeCode.ToLower() == type.ToLower())
                .Include(rf => rf.ReportPeriodTo)
                    .ThenInclude(r => r.ReportPeriodStateCodeNavigation)
                .Include(rf => rf.ReportPeriodTo)
                    .ThenInclude(r => r.ReportPeriodTypeCodeNavigation)
                .Include(rf => rf.RollForwardTypeCodeNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : AssetInfoManager
Method name : FindAllocationPeriodsDto
No of Lines : 28
Query : 
{
            var periods = await securedEntityManger.FindAllAsync<AmRollForwardReportingStatus>(
                q => q.Where(r => r.RollForwardTypeCode == "HRCY")
                      .Include(r => r.RollForwardTypeCodeNavigation)
                      .Include(r => r.ReportPeriodTo)
                        .ThenInclude(tp => tp.ReportPeriodStateCodeNavigation)
                        .Include(r => r.ReportPeriodTo)
                            .ThenInclude(tp => tp.ReportPeriodTypeCodeNavigation)
                        .Include(r => r.ReportPeriodTo)
                            .ThenInclude(tp => tp.AmAssetReportingStatuses)
                        .Include(r => r.ReportPeriodTo)
                            .ThenInclude(tp => tp.AmUploadTypeReportingStatuses)
                        .Include(r => r.ReportPeriodTo)
                            .ThenInclude(tp => tp.AmReportPeriodStatuses)
                      .AsSplitQuery()
                    .Select(r => new AmRollForwardReportingStatus
                    {
                        ReportPeriodTo = new AmReportPeriod
                        {
                            ReportPeriodGuid = r.ReportPeriodTo.ReportPeriodGuid,
                            ReportPeriodStartDate = r.ReportPeriodTo.ReportPeriodStartDate,
                            ReportPeriodEndDate = r.ReportPeriodTo.ReportPeriodEndDate,
                            ReportPeriodStateCodeNavigation = r.ReportPeriodTo.ReportPeriodStateCodeNavigation,
                            ReportPeriodTypeCodeNavigation = r.ReportPeriodTo.ReportPeriodTypeCodeNavigation,
                            ReportPeriodDesc = r.ReportPeriodTo.ReportPeriodDesc,
                            AmAssetReportingStatuses = r.ReportPeriodTo.AmAssetReportingStatuses,
                            AmReportPeriodStatuses = r.ReportPeriodTo.AmReportPeriodStatuses,
                        }
                    }));

