Class : PortfolioAdministrationRepository
Method name : FindAllPortfolios
No of Lines : 5
Query : 
{

            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolio>(
                q => q
                .Where(hp => hp.DeletedUser == null)
                .Include(hp => hp.FundGroupShortNameNavigation)
                .AsNoTracking());

Class : PortfolioAdministrationRepository
Method name : FindPortfolioById
No of Lines : 3
Query : 
{
            var result = await securedEntityManger.FindAsync<AmHierarchyPortfolio>(
                q=> q.Where(hp=> hp.HierarchyPortfolioGuid == id)
                .Include(hp => hp.FundGroupShortNameNavigation).AsNoTracking());

Class : ViewAdministrationRepository
Method name : FindAllHierarchyPortfolios
No of Lines : 6
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolio>(
                q => q.Where(hp => hp.DeletedUser == null)
                .Include(hp => hp.FundGroupShortNameNavigation)
                .Include(hp => hp.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindHierarchyPortfolioById
No of Lines : 7
Query : 
{
            var result = await securedEntityManger.FindAsync<AmHierarchyPortfolio>(
                q => q.Where(hp => hp.HierarchyPortfolioGuid == id)
                .Include(hp => hp.CreatedUser)
                .Include(hp => hp.FundGroupShortNameNavigation)
                .Include(hp => hp.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindHierarchyPortfoliosByIds
No of Lines : 7
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolio>(
                q => q.Where(a => ids.Contains(a.HierarchyPortfolioGuid))
                .Include(hp => hp.CreatedUser)
                .Include(hp => hp.FundGroupShortNameNavigation)
                .Include(hp => hp.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

