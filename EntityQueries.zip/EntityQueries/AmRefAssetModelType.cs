Class : BusinessRulesRepository
Method name : GetAssetModelTypes
No of Lines : 3
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmRefAssetModelType>(
                q => q.Include(q => q.UploadTypeCodeNavigation)
                .AsNoTracking());

