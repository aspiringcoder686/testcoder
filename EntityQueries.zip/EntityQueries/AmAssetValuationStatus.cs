Class : AssetInfoManager
Method name : GetUploadedAssetValuationStatusesForPeriod
No of Lines : 10
Query : 
{
            //**WARNING there are multiple records for an asset/period combination - we are only interested in the latest
            var result = await securedEntityManger.FindAllAsync<AmAssetValuationStatus>(
                q => q.Where(s => s.ReportPeriodGuid == periodId)
                      .Include(s => s.Asset)
                      .Include(s => s.ReportPeriod)
                      .Include(s => s.ReportingStatusCodeNavigation)
                      .Include(s => s.ReportingOnTypeCodeNavigation)
                      .Include(s => s.ChangedUser)
                      .Include(s => s.Upload).ThenInclude(u => u.UploadStatusCodeNavigation)
                      .AsNoTracking()
                      .AsSplitQuery());

