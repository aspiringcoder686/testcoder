Class : ReferenceDataManager
Method name : FindAllReferenceDataUOM
No of Lines : 3
Query : 
{
            var s = await securedEntityManger.FindAllAsync<AmUom>(q => q
            .Include(u => u.AssetTypeCodeNavigation)
            .AsNoTracking());

