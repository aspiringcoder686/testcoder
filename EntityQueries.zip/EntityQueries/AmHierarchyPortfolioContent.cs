Class : PortfolioAdministrationRepository
Method name : FindPortfolioContents
No of Lines : 7
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolioContent>(
                q => q.Where(hpc => hpc.HierarchyPortfolioGuid == portfolioId && hpc.ReportPeriod.ReportPeriodEndDate == reportPeriodDate && hpc.DeletedUser == null)
                .Include(hvc => hvc.Asset)
                    .ThenInclude(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                .Include(rf => rf.HierarchyPortfolio)
                .AsNoTracking()
                .AsSplitQuery());

Class : PortfolioAdministrationRepository
Method name : FindPortfolioContentByPeriod
No of Lines : 12
Query : 
logger.LogInformation("Finding all portfolio content by date");

            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolioContent>(
                q => q.Where(pc => pc.DeletedUserGuid == null && pc.ReportPeriodGuid == reportPeriod)
                .Include(pc => pc.Asset)
                    .ThenInclude(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                        .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(pc => pc.HierarchyPortfolio)
                    .ThenInclude(hp => hp.FundGroupShortNameNavigation)
                .Include(pc => pc.ReportPeriod)
                .Include(pc => pc.CreatedUser)
                .Include(pc => pc.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAllPortfolioContentsByReportingPeriodId
No of Lines : 10
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolioContent>(
                q => q.Where(hpc => hpc.ReportPeriodGuid == id && hpc.DeletedUser == null)
                .Include(hvc => hvc.Asset)
                    .ThenInclude(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                        .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(rf => rf.HierarchyPortfolio)
                    .ThenInclude(hp => hp.FundGroupShortNameNavigation)
                .Include(hvc => hvc.ReportPeriod)
                .AsNoTracking()
                .AsSplitQuery());

