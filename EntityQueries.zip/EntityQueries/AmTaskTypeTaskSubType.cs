Class : TaskSchedulerRepository
Method name : FindTaskSubTypes
No of Lines : 4
Query : 
throw new InvalidOperationException($"Task type '{taskTypeCode}' not found.");

            var taskSubTypeLinks = await securedEntityManger.FindAllAsync<AmTaskTypeTaskSubType>(
                q => q.AsNoTracking()
                .Where(link => link.TaskTypeGuid == taskTypeEntity.TaskTypeGuid)
                .Include(link => link.TaskSubType));

