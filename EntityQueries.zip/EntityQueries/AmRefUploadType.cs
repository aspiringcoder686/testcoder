Class : ViewAdministrationRepository
Method name : FindUploadTypesByCategory
No of Lines : 4
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmRefUploadType>(
               q => q.Where(ut => ut.UploadCategoryCode == category)
                .Include(ut => ut.UploadCategoryCodeNavigation)
                .AsNoTracking());

