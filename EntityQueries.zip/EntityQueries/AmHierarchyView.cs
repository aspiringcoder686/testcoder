Class : ViewAdministrationRepository
Method name : FindHierarchyViewById
No of Lines : 4
Query : 
{
            var result = await securedEntityManger.FindAsync<AmHierarchyView>(
                q => q.Where(hv => hv.HierarchyViewGuid == id)
                .Include(hv => hv.FundGroupShortNameNavigation)
                .AsNoTracking());

