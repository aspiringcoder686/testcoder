Class : PortfolioAdministrationRepository
Method name : FindViewAssetContentByAssetAndPeriod
No of Lines : 10
Query : 
_logger.LogInformation("Retrieving view asset content for asset {0}", assetId);

            var result = await securedEntityManger.FindAllAsync<AmHierarchyViewContentAsset>(
                q => q.Where(va => va.DeletedUserGuid == null && va.Asset.AssetGuid == assetId && va.ReportPeriod.ReportPeriodEndDate == reportPeriodDate)
                .Include(va => va.Asset)
                    .ThenInclude(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                        .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(pc => pc.ReportPeriod)
                .Include(pc => pc.CreatedUser)
                .Include(pc => pc.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAllHierarchyViewAssetContents
No of Lines : 21
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyViewContentAsset>(
                q => q.Where(hvc =>
                    hvc.HierarchyViewGuid == id &&
                    (!reportPeriodDate.HasValue || hvc.ReportPeriod.ReportPeriodEndDate == reportPeriodDate.Value) && (includeDeleted || hvc.DeletedUser == null))
                .Include(hvc => hvc.Asset)
                    .ThenInclude(a => a.AmFundAssets)
                        .ThenInclude(fa => fa.NowBetFund)
                            .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(hvc => hvc.Asset)
                    .ThenInclude(a => a.AmAssetTeamMembers)
                        .ThenInclude(tm => tm.AvailableAssetTeamMember)
                .Include(hvc => hvc.Asset)
                    .ThenInclude(a => a.AmAssetTeamMembers).ThenInclude(tm => tm.AvailableAssetTeamMember)
                .Include(hvc => hvc.ReportPeriod)
                .Include(hvc => hvc.HierarchyView)
                    .ThenInclude(hv => hv.FundGroupShortNameNavigation)
                .Include(hvc => hvc.CreatedUser)
                .Include(hvc => hvc.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery()
            );

