Class : BusinessRuleAssetOverviewRepository
Method name : GetAllBasicAssets
No of Lines : 6
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                .Include(a => a.AssetTypeCodeNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : PortfolioAdministrationRepository
Method name : FindAllAssets
No of Lines : 12
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                .Include(a => a.AmAssetTeamMembers)
                    .ThenInclude(at => at.AvailableAssetTeamMember)
                        .ThenInclude(at => at.User)
                .Include(a => a.AmAssetAddresses)
                .Include(a => a.AssetTypeCodeNavigation)
                .Include(a => a.UsstateCodeNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : PortfolioAdministrationRepository
Method name : FindAssetsByIds
No of Lines : 6
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q.Where(a => ids.Contains(a.AssetGuid))
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                .Include(a => a.AmAssetTeamMembers).ThenInclude(tm => tm.AvailableAssetTeamMember)
                .AsNoTracking()
                .AsSplitQuery());

Class : TaskSchedulerRepository
Method name : FindAssetsWithFundGroups
No of Lines : 5
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(q => q
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                    .ThenInclude(f => f.FundGroupShortNameNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAssetsByDateAcquired
No of Lines : 12
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q.Where(a => a.AcquisitionDate <= date)
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                    .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(a => a.AmAssetTeamMembers)
                    .ThenInclude(at => at.AvailableAssetTeamMember)
                        .ThenInclude(at => at.User)
                .Include(a => a.AmAssetAddresses)
                .Include(a => a.AssetTypeCodeNavigation)
                .Include(a => a.UsstateCodeNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAssetById
No of Lines : 8
Query : 
{
            var result = await securedEntityManger.FindAsync<AmAsset>(
                q => q.Where(a => a.AssetGuid == id)
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                    .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(a => a.AmAssetTeamMembers).ThenInclude(tm => tm.AvailableAssetTeamMember)
                .Include(a => a.AmAssetBusinessRuleExceptions)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAssetsByIds
No of Lines : 7
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q.Where(a => ids.Contains(a.AssetGuid))
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                    .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(a => a.AmAssetTeamMembers).ThenInclude(tm => tm.AvailableAssetTeamMember)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAllAssets
No of Lines : 6
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q
                .Include(a => a.AmFundAssets).ThenInclude(fa => fa.NowBetFund)
                    .ThenInclude(f => f.FundGroupShortNameNavigation)
                .AsNoTracking()
                .AsSplitQuery());

Class : AssetInfoManager
Method name : FindAllAssets
No of Lines : 13
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAsset>(
                q => q
                .Include(a => a.AmFundAssets)
                    .ThenInclude(fa => fa.NowBetFund)
                        .ThenInclude(f => f.FundGroupShortNameNavigation)
                .Include(a => a.AmAssetTeamMembers)
                    .ThenInclude(at => at.AvailableAssetTeamMember)
                        .ThenInclude(at => at.User)
                .Include(a => a.AmAssetAddresses)
                .Include(a => a.AssetTypeCodeNavigation)
                .Include(a => a.UsstateCodeNavigation)
                .AsNoTracking()
                .AsSplitQuery());

