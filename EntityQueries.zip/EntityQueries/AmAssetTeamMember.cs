Class : TaskSchedulerRepository
Method name : FindAnalystsForAllAssets
No of Lines : 9
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmAssetTeamMember>(
                q => q.Where(item => item.AssetTeamMemberTypeCode == "ANL")
                .Include(item => item.AvailableAssetTeamMember)
                    .ThenInclude(t => t.ExternalUser)
                .Include(item => item.AvailableAssetTeamMember)
                    .ThenInclude(t => t.User)
                .Include(hvc => hvc.Asset)
                .AsNoTracking()
                .AsSplitQuery());

