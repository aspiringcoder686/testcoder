Class : ReferenceDataManager
Method name : FindAllReferenceDataValuationBridgeSubtypes
No of Lines : 3
Query : 
{
            var s = await securedEntityManger.FindAllAsync<AmRefValuationBridgeSubtype>(q => q
                .Include(v => v.ValuationBridgeTypeCodeNavigation)
                .AsNoTracking());

