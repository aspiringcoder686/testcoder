Class : FieldDictionaryRepository
Method name : FindFieldDefinitons
No of Lines : 6
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmFieldDefinition>(
                q => q.Where(defs => defs.FieldDictionaryGuid == guid
                   && (!defs.IsDeleted.HasValue || !defs.IsDeleted.Value))
               .Include(defs => defs.FieldTypeCodeNavigation)
               .Include(defs => defs.FieldDictionary)
               .AsNoTracking());

Class : FieldDictionaryRepository
Method name : FindFieldDefinitionByName
No of Lines : 9
Query : 
{
            var result = await securedEntityManger.FindAsync<AmFieldDefinition>(
                q => q
                    .Where(defs =>
                        defs.UniqueName.ToLower() == name.ToLower() &&
                        (defs.IsDeleted == null || defs.IsDeleted == false)
                    )
                    .Include(defs => defs.FieldTypeCodeNavigation)
                    .AsNoTracking()
            );

