Class : ReferenceDataManager
Method name : FindAllMetrics
No of Lines : 5
Query : 
{
            var templates = await securedEntityManger.FindAllAsync<AmAssetTypeSpecificMetricsTemplate>(
                q => q.Where(t => t.AssetTypeCodeNavigation.AssetTypeCode == assetTypeCode)
                    .Include(a => a.AssetTypeCodeNavigation)
                    .AsNoTracking()
            );

