Class : PortfolioAdministrationRepository
Method name : FindAllPortfolioRichtext
No of Lines : 2
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyPortfolioRichtext>
            (q => q.Where(q => q.HierarchyPortfolioGuid == Id).Include(q => q.Richtext)
            .AsNoTracking());

