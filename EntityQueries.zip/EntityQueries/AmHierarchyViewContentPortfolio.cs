Class : PortfolioAdministrationRepository
Method name : FindViewPortfolioContentByPeriod
No of Lines : 9
Query : 
_logger.LogInformation("Retrieving view portfolio content for date {0}", reportPeriodDate);

            var result = await securedEntityManger.FindAllAsync<AmHierarchyViewContentPortfolio>(
                q => q.Where(hvc => hvc.DeletedUserGuid == null && hvc.ReportPeriod.ReportPeriodEndDate == reportPeriodDate)
                .Include(hvc => hvc.HierarchyPortfolio)
                    .ThenInclude(hp => hp.FundGroupShortNameNavigation)
                .Include(pc => pc.ReportPeriod)
                .Include(pc => pc.CreatedUser)
                .Include(pc => pc.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAllHierarchyViewPortfolioContents
No of Lines : 13
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmHierarchyViewContentPortfolio>(
                q => q.Where(hvc =>
                    hvc.HierarchyViewGuid == id &&
                    (!reportPeriodDate.HasValue || hvc.ReportPeriod.ReportPeriodEndDate == reportPeriodDate.Value) && (includeDeleted || hvc.DeletedUser == null))
                .Include(hvp => hvp.HierarchyPortfolio)
                    .ThenInclude(hp => hp.FundGroupShortNameNavigation)
                .Include(hvp => hvp.ReportPeriod)
                .Include(hvp => hvp.HierarchyView)
                    .ThenInclude(hv => hv.FundGroupShortNameNavigation)
                .Include(hvp => hvp.CreatedUser)
                .Include(hvp => hvp.DeletedUser)
                .AsNoTracking()
                .AsSplitQuery());

