Class : ReferenceDataManager
Method name : FindAllReferenceDataSectorDiversification
No of Lines : 4
Query : 
{
            var s = await securedEntityManger.FindAllAsync<AmSectorDiversification>(
                q => q.Include(sd => sd.AssetTypeCodeNavigation)
                 .Include(sd => sd.DemandDriver)
                .AsNoTracking());

