Class : AssetInfoManager
Method name : FindAssetsInValuations
No of Lines : 6
Query : 
{
            var assets = await securedEntityManger.FindAllAsync<AmAssetInValuations>(
                q => q.Where(s => s.ReportPeriodGuid == periodId)
                      .Include(s => s.Asset)
                      .Include(s => s.ReportPeriod)
                      .AsNoTracking()
                      .AsSplitQuery());

Class : AssetInfoManager
Method name : FindInValuationsQuartersForAsset
No of Lines : 6
Query : 
{
            var result = (await securedEntityManger.FindAllAsync<AmAssetInValuations>(
                q => q.Where(aiv => aiv.AssetGuid == asset.Id)
                      .Include(aiv => aiv.ReportPeriod)
                      .Include(aiv => aiv.Asset)
                      .AsNoTracking()
                      .AsSplitQuery()));

