Class : TaskSchedulerRepository
Method name : FindTaskScheuleById
No of Lines : 7
Query : 
{
            var result = await securedEntityManger.FindAsync<AmTaskSchedule>(
                q => q.Where(t => t.TaskScheduleGuid == id)
                .Include(t => t.TaskType)
                .Include(t => t.AmTaskScheduleFundRules)
                .Include(t => t.AmTaskScheduleAssetRules)
                .AsNoTracking()
                .AsSplitQuery());

Class : TaskSchedulerRepository
Method name : FindAllTaskScheules
No of Lines : 5
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmTaskSchedule>(
                q => q.Include(ts => ts.AmTaskScheduleFundRules)
               .Include(ts => ts.AmTaskScheduleAssetRules)
               .Include(ts => ts.TaskType)
               .AsNoTracking());

