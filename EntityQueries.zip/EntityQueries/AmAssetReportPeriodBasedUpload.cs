Class : AssetInfoManager
Method name : FindUploadsByTypeReportingPeriodDate
No of Lines : 8
Query : 
{
             var result = await securedEntityManger.FindAllAsync<AmAssetReportPeriodBasedUpload>(
                 q => q.Where(upload => upload.ReportPeriod.ReportPeriodTypeCodeNavigation.ReportPeriodTypeCode == "M"
                                  && upload.Upload.UploadTypeCodeNavigation.UploadTypeCode == uploadType
                                  && upload.ReportPeriod.ReportPeriodEndDate == reportPeriodEndDate)
                      .Include(upload => upload.Upload)
                      .Include(upload => upload.ReportPeriod)
                      .AsNoTracking()
                      .AsSplitQuery());

