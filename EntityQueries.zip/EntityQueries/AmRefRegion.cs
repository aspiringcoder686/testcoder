Class : ReferenceDataManager
Method name : FindAllRegions
No of Lines : 3
Query : 
{
            var regions = await securedEntityManger.FindAllAsync<AmRefRegion>(q => q
                .Include(r => r.AmRefRegionSubRegions)
                .AsNoTracking());

Class : ReferenceDataManager
Method name : CreateOrUpdateRegion
No of Lines : 4
Query : 
{
            var existingRecord = await  securedEntityManger.FindAsync<AmRefRegion>(q =>
                q.Where(eq => eq.RegionCode == region.Id)
                 .Include(r => r.AmRefRegionSubRegions)
                 .AsNoTracking());

