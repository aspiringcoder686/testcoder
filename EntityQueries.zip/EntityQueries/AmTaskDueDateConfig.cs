Class : TaskSchedulerRepository
Method name : FindTaskDueDates
No of Lines : 3
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmTaskDueDateConfig>(
                q => q.AsNoTracking()
                .Include(t => t.TaskType));

