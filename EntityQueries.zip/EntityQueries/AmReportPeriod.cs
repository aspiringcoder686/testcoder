Class : ReportingPeriodRepository
Method name : FindFirstUninitializedPeriod
No of Lines : 10
Query : 
{
            var result = await securedEntityManger.FindAsync<AmReportPeriod>(
                q => q.Where(p => p.ReportPeriodTypeCode == "M" && p.ReportPeriodStateCode == "X")
                    .Include(r => r.ReportPeriodStateCodeNavigation)
                    .Include(r => r.ReportPeriodTypeCodeNavigation)
                    .Include(r => r.AmAssetReportingStatuses)
                    .Include(r => r.AmUploadTypeReportingStatuses)
                    .Include(r => r.AmReportPeriodStatuses)
                    .OrderBy(r => r.ReportPeriodEndDate)
                    .AsNoTracking()
                    .AsSplitQuery());

Class : ReportingPeriodRepository
Method name : FindQuarterByDate
No of Lines : 10
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmReportPeriod>(
            q => q.Where(r => r.ReportPeriodTypeCode == "Q" && r.ReportPeriodStateCode != "X")
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .Include(r => r.AmReportPeriodStatuses)
                .OrderBy(r => r.ReportPeriodGuid)
                .AsNoTracking()
                .AsSplitQuery());

Class : ReportingPeriodRepository
Method name : GetAssetIdsOpenForValuationsReportingPeriod
No of Lines : 9
Query : 
{
            var result = await securedEntityManger.FindAsync<AmReportPeriod>(
            q => q.Where(p => p.ReportPeriodTypeCode == "M" && p.ReportPeriodEndDate == date)
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .Include(r => r.AmReportPeriodStatuses)
                .OrderBy(r => r.ReportPeriodGuid)
                .AsNoTracking());

Class : ReportingPeriodRepository
Method name : GetCurrentSMTReportingPeriod
No of Lines : 12
Query : 
{
            var result = await securedEntityManger.FindAsync<AmReportPeriod>(
                q => q.Where(period => period.ReportPeriodTypeCode == "Q"
                  && date >= period.ReportPeriodStartDate
                  && date <= period.ReportPeriodEndDate)
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .Include(r => r.AmReportPeriodStatuses)
                .OrderBy(r => r.ReportPeriodGuid)
                .AsNoTracking()
                .AsSplitQuery());

Class : TaskSchedulerRepository
Method name : FindReportingPeriods
No of Lines : 8
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmReportPeriod>(q => q
                .Where(r => r.ReportPeriodTypeCode == "M" && (r.ReportPeriodEndDate >= minDate &&
                    r.ReportPeriodEndDate <= maxDate))
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .AsNoTracking().AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindQuarterlyReportingPeriods
No of Lines : 8
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmReportPeriod>(
                q => q.Where(r => r.ReportPeriodTypeCode == sCode)
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .AsNoTracking()
                .AsSplitQuery());

Class : ViewAdministrationRepository
Method name : FindAllReportingPeriodsBetweenDate
No of Lines : 8
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmReportPeriod>(
                q => q.Where(r => r.ReportPeriodTypeCode == sCode && r.ReportPeriodEndDate <= maxdate && r.ReportPeriodEndDate >= mindate)
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .AsNoTracking()
                .AsSplitQuery());

Class : AssetInfoManager
Method name : FindAllReportingPeriods
No of Lines : 9
Query : 
{
            var result = await securedEntityManger.FindAllAsync<AmReportPeriod>(
                q => q
                .Include(r => r.ReportPeriodStateCodeNavigation)
                .Include(r => r.ReportPeriodTypeCodeNavigation)
                .Include(r => r.AmAssetReportingStatuses)
                .Include(r => r.AmUploadTypeReportingStatuses)
                .Include(r => r.AmReportPeriodStatuses)
                .AsNoTracking()
                .AsSplitQuery());

