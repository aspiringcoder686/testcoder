Class : ViewAdministrationRepository
Method name : FindReportingPreference
No of Lines : 4
Query : 
{
            var result = await securedEntityManger.FindAsync<AmReportingPreference>(
                q => q.Where(rp => rp.UserSid == userSid && rp.Canned == false && rp.ReportName == reportName)
                .Include(rp => rp.AmReportingPreferenceFields)
                .AsNoTracking());

