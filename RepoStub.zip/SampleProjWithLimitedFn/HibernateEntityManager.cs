﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Business.EnterpriseLibrary.Common.Persistence;
using NHibernate;
//using Remotion.Linq.Utilities;
using log4net;
using NHibernate.Criterion;
using Spring.Transaction.Interceptor;
using Remotion.Linq.Utilities;
using EFUnderstandingBuildingBlock;
using Remotion.Data.Linq.Utilities;

namespace Business.EnterpriseLibrary.Persistence.Hibernate
{
    public class HibernateEntityManager : AbstractEntityManager
    {
        public static readonly ILog log = LogManager.GetLogger(typeof(HibernateEntityManager));
        


        
        public override void Create(object o)
        {
            try
            {
                Save(o);
            }
            catch (HibernateException he)
            {
                log.Error(he.Message, he);
                throw new PersistenceException(he.Message, he);
            }
        }


        
        public override void Update(object o)
        {
            try
            {
                var session = GetSession();
                session.Update(o);
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }

        
        public override void CreateOrUpdate(object o)
        {
            try
            {
                SaveOrUpdate(o);
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }

        }

        
        public override void CreateOrUpdateAll<T>(IList<T> entries)
        {
            foreach (var entry in entries)
                CreateOrUpdate(entry);
        }


        
        public override void Merge(object o)
        {
            try
            {
                Merge(o);
            }
            catch (HibernateException he)
            {
                log.Error(he.Message, he);
                throw new PersistenceException(he.Message, he);
            }
        }


        
        public override void Remove<T>(object key)
        {
            try
            {
                var o = Find<T>(key);
                Delete(o);
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw;
            }
        }

        
        public override void Remove(object o)
        {
            try
            {
                Delete(o);
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }


        
        public override void RemoveAll(Type type)
        {
            throw new NotImplementedException();
        }

        
        public override void RemoveAll<T>(IList<T> data)
        {
            foreach (var o in data)
                Remove(o);
        }

        
        public override void RemoveAllByNamedQuery(Type type, string queryName)
        {
            throw new NotImplementedException();
        }

        
        public override void RemoveAllByNamedQuery(Type type, string queryName, Dictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        
        public override T Find<T>(object key)
        {
            try
            {
                return Load<T>(key);
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }


        
        public List<object> FindAllByNamedQuery(Type type, string queryName, Dictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        
        public override void Flush()
        {
            try
            {
                Flush();
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }

        private static void SetParameterValue(IQuery query, int position, object value)
        {
            try
            {
                query.SetParameter(position, value);
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }

        
        public override IList<T> FindAll<T>()
        {
            return CreateCriteria(typeof(T)).List<T>();
        }

        
        public override int Count<T>()
        {
            var criteria = CreateCriteria(typeof(T));
            criteria.SetProjection(Projections.RowCount());
            return (Int32)(criteria.List()[0]);
        }

        
        public override IList<T> FindAllByNamedQuery<T>(string queryName)
        {
            return FindAllByNamedQuery<T>(queryName, null, null, null);
        }

        
        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters)
        {
            return FindAllByNamedQuery<T>(queryName, parameters, null, null);
        }

        
        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            try
            {
                Type type = typeof(T);
                IQuery q = GetNamedQuery(type.FullName + "." + queryName);

                if (parameters != null)
                {
                    for (var i = 0; i < parameters.Length; i++)
                    {
                        SetParameterValue(q, i, parameters[i]);
                    }
                }

                if (start.HasValue)
                    q.SetFirstResult(start.Value);

                if (max.HasValue)
                    q.SetMaxResults(max.Value);

                return q.List<T>();

            }
            catch (HibernateException he)
            {
                log.Error(he.Message, he);
                throw new PersistenceException(he.Message, he);
            }
        }

        [Transaction(NoRollbackFor = new[] { typeof(EntityNotFoundException) })]
        public override T FindByNamedQuery<T>(string queryName)
        {
            return FindSingle(FindAllByNamedQuery<T>(queryName));
        }

        [Transaction(NoRollbackFor = new[] { typeof(EntityNotFoundException) })]
        public override T FindByNamedQuery<T>(string queryName, object[] parameters)
        {
            return FindSingle(FindAllByNamedQuery<T>(queryName, parameters));
        }

        [Transaction(NoRollbackFor = new[] { typeof(EntityNotFoundException) })]
        public override T FindByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            return FindSingle(FindAllByNamedQuery<T>(queryName, parameters, start, max));
        }

        [Transaction(NoRollbackFor = new[] { typeof(EntityNotFoundException) })]
        private T FindSingle<T>(IList<T> list)
        {
            if (list.Count == 0)
                throw new EntityNotFoundException();
            if (list.Count > 1)
                throw new PersistenceException("Found more than one persistent object.");

            return list[0];
        }

        
        public override void ExecuteSQLQuery(string sql)
        {
            ExecuteSQLQuery(sql, new Dictionary<string, object>());
        }

        
        public override void ExecuteSQLQuery(string sql, IDictionary<string, object> parameters)
        {
            ISQLQuery query = GetSQLQuery(sql, parameters);
            query.ExecuteUpdate();
        }

        
        public override void ExecuteStoredProcedure(string name)
        {
            try
            {
                var query = CreateSQLQuery("exec " + name);
                query.ExecuteUpdate();
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }

        }

        
        public override IList<T> ExecuteStoredProcedure<T>(string name)
        {
            try
            {
                var query = CreateSQLQuery("exec " + name);
                // AddEntity helps cast this generic correctly
                return query.AddEntity(typeof(T)).List<T>();
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }

        // Execute a stored procedure by name, with a dictionary of parameters. This method is for procedures with no return value
        
        public override void ExecuteStoredProcedure(string name, IDictionary<string, object> paramDictionary)
        {
            try
            {
                var query = BuildStoredProcedureSql(name, paramDictionary);
                query.ExecuteUpdate();
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }

        }

        // Execute a stored procedure by name, with a dictionary of parameters. This method returns a strongly-typed list of results
        
        public override IList<T> ExecuteStoredProcedure<T>(string name, IDictionary<string, object> paramDictionary)
        {
            try
            {
                var query = BuildStoredProcedureSql(name, paramDictionary);
                // AddEntity helps cast this generic correctly
                return query.AddEntity(typeof(T)).List<T>();
            }
            catch (HibernateException e)
            {
                log.Error(e.Message, e);
                throw new PersistenceException(e.Message, e);
            }
        }

        // Build the query used with stored procedures
        private ISQLQuery BuildStoredProcedureSql(string name, IDictionary<string, object> paramDictionary)
        {
            // If paramDictionary is null or is an empty dictionary, throw an exception
            if (paramDictionary == null)
                throw new ArgumentNullException("paramDictionary", "paramDictionary cannot be null. There is another overload for this method that does not use parameters for the stored procedure.");

            if (paramDictionary.Keys.Count == 0)
                throw new ArgumentEmptyException("paramDictionary");

            // Build a sql string with replaceable parameters
            var stringBuilder = new StringBuilder("exec ");
            stringBuilder.Append(name + " ");
            foreach (var pair in paramDictionary)
            {
                stringBuilder.Append("@");
                stringBuilder.Append(pair.Key);
                stringBuilder.Append("=:");
                stringBuilder.Append(pair.Key);
                stringBuilder.Append(", ");
            }
            // Cut out the extra space and comma
            stringBuilder.Remove(stringBuilder.Length - 2, 2);

            var query = CreateSQLQuery(stringBuilder.ToString());

            // Substitute in parameters, typing them correctly if possible
            foreach (var pair in paramDictionary)
            {
                var type = pair.Value.GetType();
                if (type == typeof(DateTime))
                {
                    query.SetDateTime(pair.Key, (DateTime)pair.Value);
                }
                else if (type == typeof(Guid))
                {
                    query.SetGuid(pair.Key, (Guid)pair.Value);
                }
                else
                {
                    query.SetString(pair.Key, pair.Value.ToString());
                }
            }
            return query;
        }

        private ISQLQuery GetSQLQuery(string sql, ICollection<KeyValuePair<string, object>> parameters)
        {
            try
            {
                var query = CreateQuery(sql) as ISQLQuery;

                if (query == null)
                    throw new PersistenceException("Couldn't create sql query " + query);

                if (parameters != null && parameters.Count > 0)
                {
                    foreach (var parameter in parameters)
                        query.SetParameter(parameter.Key, parameter.Value);
                }

                return query;
            }
            catch (HibernateException he)
            {
                throw new PersistenceException(he.Message, he);
            }
        }


        
        public override IList FindAllByNamedQuery(string name)
        {
            return GetNamedQuery(name).List();
        }

        
        public override IList FindAllByNamedQuery(string name, object[] parameters)
        {
            IQuery q = GetNamedQuery(name);

            if (parameters != null)
            {
                for (var i = 0; i < parameters.Length; i++)
                {
                    SetParameterValue(q, i, parameters[i]);
                }
            }


            return q.List();

        }

        //sample of a dynamic read - leaving it here because this could save quite a bit of research
        //       
        //        public override string Bananas<T>()
        //        {
        //            //test method to return the contents of one or more SmtSummaryResults records
        //            //(mapped to the FACT_SUMMARY_RESULTS table)
        //            var mySession=GetSession();
        //            string	sResult=String.Empty;
        //            try
        //            {
        //                //from the hibernate mapping (entity-name="SmtSummaryResults")
        //                String	sQuery=@"from SmtSummaryResults summaryResult where summaryResult.id='7854FD66-4396-4C6A-9EB8-6722FD400FB9' ";
        //                IQuery	myQuery=mySession.CreateQuery(sQuery);

        ////				Dictionary<string, T> teMap=new Dictionary<string, T>();
        //                var listResult=myQuery.List();

        //                foreach(var objResult in listResult)
        //                {	//for each DB record
        //                    var thisRow=(Hashtable)objResult;

        //                    foreach(DictionaryEntry de in thisRow)
        //                    {
        //                        string	sKeyType=de.Key.GetType().ToString();
        //                        string	sKeyName=de.Key.ToString();
        //                        string	sValueType=(de.Value==null)?"nullvalue":de.Value.GetType().ToString();
        //                        string	svalue=(de.Value==null)?"nullvalue":de.Value.ToString()+"("+sValueType+")";
        //                        sResult+=sKeyName+"/"+svalue+"/"+"---";
        //                    }
        //                    sResult+="\r\n";
        //                }
        //            }
        //            catch(Exception exc)
        //            {
        //                sResult+="Boom! "+exc.Message;
        //            }
        //            return sResult;
        //		}

        
        //create a record of type <T> using the dictionary of column (property) name/value pairs
        public override System.Object Create<T>(Dictionary<string, object> dictNewRecordValues)
        {
            System.Object oResult = null;
            var mySession = GetSession();

            try
            {
                string sTypeName = typeof(T).Name;
                oResult = mySession.Save(sTypeName, dictNewRecordValues);
            }
            catch (Exception exc) { throw new PersistenceException(exc.Message, exc); }

            return oResult;
        }

        // Detach an object form the nhibernate session
        public override void Detach(object o)
        {
            Evict(o);
        }
    }
}

