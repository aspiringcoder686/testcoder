﻿namespace SampleProjWithLimitedFn
{
    internal class EntityNotFoundException
    {
    }
}