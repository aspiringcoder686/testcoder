﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq.Expressions;
using NHibernate;
using NHibernate.Hql.Ast;
using NHibernate.SqlCommand;
using NHibernate.Util;
using log4net;
using Microsoft.Data.SqlClient;


namespace SampleProjWithLimitedFn
{
    public class AmsEntityManager : EfEntityManager
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(AmsEntityManager));
        private readonly HibernateEntityManagerFactory factory;

        public AmsEntityManager(MyAppDbContext dbContext)
            : base(dbContext)
        {
        }

        public virtual IList<T> Query<T>(Expression<Func<T, bool>> where = null,
                                         Expression<Func<T, T>> select = null,
                                         bool approvedOnly = true)
            where T : class
        {
            throw new NotImplementedException();
        }

        public virtual IList<TResult> Query<T, TResult>(Expression<Func<T, bool>> where,
                                                         Expression<Func<T, TResult>> select,
                                                         bool approvedOnly = true)
            where T : class
            where TResult : class
        {
            throw new NotImplementedException();
        }

        public virtual IList<TResult> QueryProjection<T, TResult>(
            Func<IQueryable<T>, IQueryable<T>> queryFilter = null,
            Expression<Func<T, TResult>> select = null,
            bool approvedOnly = true)
            where T : class
            where TResult : class
        {
            throw new NotImplementedException();
        }

        //public virtual IEnumerable<T> SqlQuery<T>(string query,
        //                                          Func<IDataReader, T> projection,
        //                                          IEnumerable<SqlParmeter> parameters = null)
        //{
        //    throw new NotImplementedException();
        //}

        public override T Find<T>(object key)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAll<T>()
        {
            throw new NotImplementedException();
        }

        private const string DIMUPLOADStatement = "DELETE FROM REP_DIM_AP_UPLOAD_RELATIONSHIP WHERE UPLOAD_KEY='$0'";
        private const string AMASSETStatement = "DELETE FROM REP_DIM_AP_UPLOAD_RELATIONSHIP WHERE ASSET_ID='$0'";
        private const string AMHPCStatement = "DELETE FROM REP_DIM_AP_UPLOAD_RELATIONSHIP WHERE ASSET_PORTFOLIO_ID='$0'";
        private const string AMPERIODStatement = "DELETE FROM REP_DIM_AP_UPLOAD_RELATIONSHIP WHERE REPORTING_PERIOD='$0'";

        public override void CreateOrUpdate(object o)
        {
            throw new NotImplementedException();
        }

        public override void Create(object o)
        {
            throw new NotImplementedException();
        }

        public override void Remove(object o)
        {
            throw new NotImplementedException();
        }

        private void UpdateDependentTables(object o)
        {
            throw new NotImplementedException();
        }

        private bool IsInterceptedType(Type type)
        {
            throw new NotImplementedException();
        }

        public virtual void SqlStoredProcedure(string sProcedureName,
                                               IEnumerable<SqlParameter> sqlparameters = null,
                                               int? commandTimeout = null,
                                               bool useReportingDb = false,
                                               bool throwException = false)
        {
            throw new NotImplementedException();
        }

        public virtual DataTable SqlStoredProcedureWithDataTable(string sProcedureName,
                                                                  IEnumerable<SqlParameter> sqlparameters = null,
                                                                  int? commandTimeout = null,
                                                                  bool useReportingDb = false,
                                                                  bool throwException = false)
        {
            throw new NotImplementedException();
        }

        public int ExecuteSQLQueryInt(string sql, IDictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteSQLQuery(string sql)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteSQLQuery(string sql, IDictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public virtual IList<T> FindAllByNamedQuery<T>(string queryName,
                                                       Dictionary<string, object> parameters,
                                                       bool approvedOnly = true)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            throw new NotImplementedException();
        }

        public virtual IList<T> FindAllByNamedQuery<T>(string queryName,
                                                       object[] parameters = null,
                                                       int? start = null,
                                                       int? max = null,
                                                       bool approvedOnly = true)
        {
            throw new NotImplementedException();
        }

        public virtual T FindByNamedQuery<T>(string queryName)
        {
            throw new NotImplementedException();
        }

        public virtual T FindByNamedQuery<T>(string queryName, object[] parameters)
        {
            throw new NotImplementedException();
        }

        public virtual T FindByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            throw new NotImplementedException();
        }

        private T FindSingle<T>(IList<T> list)
        {
            throw new NotImplementedException();
        }

        protected IList<T> FilterListByApproval<T>(bool doFilter, IList<T> originalList)
        {
            throw new NotImplementedException();
        }

        private Guid AssetIdSelector<T>(T item)
        {
            throw new NotImplementedException();
        }

        public IDictionary<Guid, bool> GetAssetApprovement(HashSet<Guid> assetIds)
        {
            throw new NotImplementedException();
        }
    }
}
