﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace SampleProjWithLimitedFn
{
    public abstract class EntityManager
    {
        /// <summary>
        /// Persist this transient object to the database.
        /// </summary>
        /// <param name="o"></param>
        public abstract void Create(object o);

        /// <summary>
        /// Update this persistent object in the database.
        /// </summary>
        /// <param name="o"></param>
        public abstract void Update(object o);


        /// <summary>
        /// </summary>
        /// <param name="o"></param>
        public abstract void Merge(object o);

        /// <summary>
        /// Create this transient object in the database. If this object already exists, update it instead.
        /// </summary>
        /// <param name="o">Object to create or update</param>
        public abstract void CreateOrUpdate(object o);

        public abstract void CreateOrUpdateAll<T>(IList<T> entries);

        /// <summary>
        /// Remove a persistent object from the database.
        /// </summary>
        /// <param name="o"></param>
        public abstract void Remove(object o);

        public abstract void RemoveAll<T>(IList<T> entries);

        /// <summary>
        /// Remove all persistent objects from the database with the given type.
        /// </summary>
        /// <param name="type"></param>
        public abstract void RemoveAll(Type type);

        /// <summary>
        /// Remove all persistent objects from the database for the given type returned by the named query
        /// </summary>
        /// <param name="type"></param>
        /// <param name="queryName"></param>
        public abstract void RemoveAllByNamedQuery(Type type, string queryName);

        /// <summary>
        /// Remove all persistent objects from the database for the give type returned by the named query and parameters. 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="queryName"></param>
        /// <param name="parameters"></param>
        public abstract void RemoveAllByNamedQuery(Type type, string queryName, Dictionary<string, object> parameters);


        public abstract void Remove<T>(object o);
        /// <summary>
        /// Find a persistent object with the given type and key.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public abstract T Find<T>(object key);

        public abstract IList<T> FindAll<T>();
        public abstract int Count<T>();
        public abstract IList<T> FindAllByNamedQuery<T>(string queryName);
        public abstract IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters);
        public abstract IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max);


        public abstract T FindByNamedQuery<T>(string queryName);
        public abstract T FindByNamedQuery<T>(string queryName, object[] parameters);
        public abstract T FindByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max);

        public abstract void Flush();

        public abstract void ExecuteSQLQuery(string sql);
        public abstract void ExecuteSQLQuery(string sql, IDictionary<string, object> parameters);

        public abstract void ExecuteNonSQLQuery(string name);
        public abstract void ExecuteNonSQLQuery(string name, IDictionary<string, object> parameters);

        /// <summary>
        /// Execute a stored procedure with no parameters that returns a strongly typed list
        /// </summary>
        /// <param name="name">Stored procedure name</param>
        public abstract IList<T> ExecuteStoredProcedure<T>(string name);

        /// <summary>
        /// Execute a stored procedure with no parameters that returns nothing
        /// </summary>
        /// <param name="name">Stored procedure name</param>
        public abstract void ExecuteStoredProcedure(string name);

        /// <summary>
        /// Execute a stored procedure with parameters that returns a strongly typed list
        /// </summary>
        /// <param name="name">Stored procedure name</param>
        /// <param name="paramDictionary">Dictionary of one or more parameters that are passed to the stored procedure</param>
        public abstract IList<T> ExecuteStoredProcedure<T>(string name, IDictionary<string, object> paramDictionary);

        /// <summary>
        /// Execute a stored procedure with parameters that returns nothing
        /// </summary>
        /// <param name="name">Stored procedure name</param>
        /// <param name="paramDictionary">Dictionary of one or more parameters that are passed to the stored procedure</param>
        public abstract void ExecuteStoredProcedure(string name, IDictionary<string, object> paramDictionary);

        public abstract IList FindAllByNamedQuery(string name);
        public abstract IList FindAllByNamedQuery(string name, object[] parameters);
        public abstract IList FindAllByNamedQuery(string name, IDictionary<string, object> parameters);

        /// <summary>
        /// Create an object using dynamic field naming
        /// </summary>
        /// <param name="dictNewRecordValues">Dictionary conaining field name/value pairs</param>
		public abstract object Create<T>(Dictionary<string, object> dictNewRecordValues);

        /// <summary>
        /// Detach an object from the nhibernate session
        /// </summary>
        /// <param name="o"></param>
        public abstract void Detach(object o);
    }
}
