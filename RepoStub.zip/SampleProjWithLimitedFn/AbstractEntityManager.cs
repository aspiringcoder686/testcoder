﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace SampleProjWithLimitedFn
{
    public class AbstractEntityManager : EntityManager
    {
        public override void Create(object o)
        {
            throw new NotImplementedException();
        }

        public override void Update(object o)
        {
            throw new NotImplementedException();
        }

        public override void Merge(object o)
        {
            throw new NotImplementedException();
        }

        public override void CreateOrUpdate(object o)
        {
            throw new NotImplementedException();
        }

        public override void CreateOrUpdateAll<T>(IList<T> entries)
        {
            throw new NotImplementedException();
        }

        public override void Remove(object o)
        {
            throw new NotImplementedException();
        }

        public override void RemoveAll<T>(IList<T> entries)
        {
            throw new NotImplementedException();
        }

        public override void RemoveAll(Type type)
        {
            throw new NotImplementedException();
        }

        public override void RemoveAllByNamedQuery(Type type, string queryName)
        {
            throw new NotImplementedException();
        }

        public override void RemoveAllByNamedQuery(Type type, string queryName, Dictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public override void Remove<T>(object o)
        {
            throw new NotImplementedException();
        }

        public override T Find<T>(object key)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAll<T>()
        {
            throw new NotImplementedException();
        }

        public override int Count<T>()
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            throw new NotImplementedException();
        }

        public override T FindByNamedQuery<T>(string queryName)
        {
            throw new NotImplementedException();
        }

        public override T FindByNamedQuery<T>(string queryName, object[] parameters)
        {
            throw new NotImplementedException();
        }

        public override T FindByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            throw new NotImplementedException();
        }

        public override void Flush()
        {
            throw new NotImplementedException();
        }

        public override void ExecuteSQLQuery(string sql)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteSQLQuery(string sql, IDictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteNonSQLQuery(string name)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteNonSQLQuery(string name, IDictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public override IList<T> ExecuteStoredProcedure<T>(string name)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteStoredProcedure(string name)
        {
            throw new NotImplementedException();
        }

        public override IList<T> ExecuteStoredProcedure<T>(string name, IDictionary<string, object> paramDictionary)
        {
            throw new NotImplementedException();
        }

        public override void ExecuteStoredProcedure(string name, IDictionary<string, object> paramDictionary)
        {
            throw new NotImplementedException();
        }

        public override IList FindAllByNamedQuery(string name)
        {
            throw new NotImplementedException();
        }

        public override IList FindAllByNamedQuery(string name, object[] parameters)
        {
            throw new NotImplementedException();
        }

        public override IList FindAllByNamedQuery(string name, IDictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public override object Create<T>(Dictionary<string, object> dictNewRecordValues)
        {
            throw new NotImplementedException();
        }

        public override void Detach(object o)
        {
            throw new NotImplementedException();
        }
    }
}

