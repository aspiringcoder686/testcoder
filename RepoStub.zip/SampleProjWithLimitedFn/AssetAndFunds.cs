﻿namespace SampleProjWithLimitedFn
{
    public class AssetAndFunds
    {
    }
}