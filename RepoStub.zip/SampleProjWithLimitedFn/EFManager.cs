﻿using log4net;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Data;

namespace SampleProjWithLimitedFn
{
    /// <summary>
    /// Sample DbContext for EF Core
    /// </summary>
    public class MyAppDbContext : DbContext
    {
        public MyAppDbContext(DbContextOptions<MyAppDbContext> options)
            : base(options)
        {
        }

        // Register your entities here:
        // public DbSet<Asset> Assets { get; set; }
        // public DbSet<Fund> Funds { get; set; }
        // public DbSet<User> Users { get; set; }
    }

    /// <summary>
    /// EF Core–based entity manager implementing the full contract
    /// </summary>
    public class EfEntityManager : IDisposable
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(EfEntityManager));
        private readonly MyAppDbContext _db;
        private bool _disposed;

        public EfEntityManager(MyAppDbContext dbContext)
        {
            _db = dbContext;
        }

        public virtual void Create(object entity)
        {
            try
            {
                _db.Add(entity);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public void Update(object entity)
        {
            try
            {
                _db.Update(entity);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public void Merge(object entity)
        {
            // EF Core Update acts as merge
            Update(entity);
        }

        public virtual void CreateOrUpdate(object entity)
        {
            try
            {
                var entry = _db.Entry(entity);
                if (entry.IsKeySet)
                    Update(entity);
                else
                    Create(entity);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public virtual void CreateOrUpdateAll<T>(IList<T> entities)
        {
            foreach (var e in entities)
                CreateOrUpdate(e);
        }

        public virtual void Remove(object entity)
        {
            try
            {
                _db.Remove(entity);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public virtual void Remove<T>(object key) where T : class
        {
            try
            {
                var entity = Find<T>(key);
                if (entity != null)
                    Remove(entity);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public virtual void RemoveAll(Type type)
        {
            try
            {
                var set = (IQueryable)_db.GetType().GetMethod("Set").MakeGenericMethod(type).Invoke(_db, null);
                var list = ((IEnumerable)set).Cast<object>().ToList();
                _db.RemoveRange(list);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public void RemoveAll<T>(IList<T> entities)
        {
            try
            {
                _db.RemoveRange(entities);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public void RemoveAllByNamedQuery(Type type, string queryName)
        {
            throw new NotImplementedException();
        }

        public void RemoveAllByNamedQuery(Type type, string queryName, Dictionary<string, object> parameters)
        {
            throw new NotImplementedException();
        }

        public virtual T Find<T>(object key) where T : class
        {
            try
            {
                return _db.Find<T>(key);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public virtual IList<T> FindAll<T>() where T : class
        {
            try
            {
                return _db.Set<T>().ToList();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public int Count<T>() where T : class
        {
            try
            {
                return _db.Set<T>().Count();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public virtual IList<T> FindAllByNamedQuery<T>(string queryName) where T : class
        {
            throw new NotImplementedException();
        }

        public virtual IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters) where T : class
        {
            throw new NotImplementedException();
        }

        public virtual IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max) where T : class
        {
            throw new NotImplementedException();
        }

        public T FindByNamedQuery<T>(string queryName) where T : class
        {
            throw new NotImplementedException();
        }

        public T FindByNamedQuery<T>(string queryName, object[] parameters) where T : class
        {
            throw new NotImplementedException();
        }

        public T FindByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max) where T : class
        {
            throw new NotImplementedException();
        }

        public void Flush()
        {
            _db.SaveChanges();
        }

        public virtual void ExecuteSQLQuery(string sql)
        {
            try
            {
                _db.Database.ExecuteSqlRaw(sql);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public virtual void ExecuteSQLQuery(string sql, IDictionary<string, object> parameters)
        {
            try
            {
                _db.Database.ExecuteSqlRaw(sql, parameters.Values.ToArray());
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public void ExecuteNonSQLQuery(string name)
        {
            ExecuteSQLQuery(name);
        }

        public void ExecuteNonSQLQuery(string name, IDictionary<string, object> parameters)
        {
            ExecuteSQLQuery(name, parameters);
        }

        public void ExecuteStoredProcedure(string name)
        {
            ExecuteSQLQuery($"EXEC {name}");
        }

        public IList<T> ExecuteStoredProcedure<T>(string name) where T : class
        {
            try
            {
                return _db.Set<T>().FromSqlRaw($"EXEC {name}").ToList();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw new PersistenceException(ex.Message, ex);
            }
        }

        public void ExecuteStoredProcedure(string name, IDictionary<string, object> paramDictionary)
        {
            throw new NotImplementedException();
        }

        public IList<T> ExecuteStoredProcedure<T>(string name, IDictionary<string, object> paramDictionary) where T : class
        {
            throw new NotImplementedException();
        }

        public virtual object Create<T>(Dictionary<string, object> dictNewRecordValues) where T : class
        {
            throw new NotImplementedException();
        }

        public void Detach(object entity)
        {
            _db.Entry(entity).State = EntityState.Detached;
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                _db.Dispose();
                _disposed = true;
            }
        }
    }
}
