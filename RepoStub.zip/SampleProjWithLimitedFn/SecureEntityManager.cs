﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace SampleProjWithLimitedFn
{
    /// <summary>
    /// Secure entity manager with access filtering, stubbed
    /// </summary>
    public class SecureEntityManager : AmsEntityManager
    {
        public SecureEntityManager(MyAppDbContext dbContext)
            : base(dbContext)
        {
        }

        public override IList<T> FindAll<T>()
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName)
        {
            throw new NotImplementedException();
        }

        public override IList<T> FindAllByNamedQuery<T>(string queryName, object[] parameters, int? start, int? max)
        {
            throw new NotImplementedException();
        }

        public override IList<T> Query<T>(Expression<Func<T, bool>> where = null,
                                           Expression<Func<T, T>> select = null,
                                           bool approvedOnly = true)
        {
            throw new NotImplementedException();
        }

        public override IList<TResult> Query<T, TResult>(Expression<Func<T, bool>> where,
                                                         Expression<Func<T, TResult>> select,
                                                         bool approvedOnly = true)
        {
            throw new NotImplementedException();
        }

        public override void CreateOrUpdate(object o)
        {
            throw new NotImplementedException();
        }

        protected IList<T> FilterListByAccess<T>(IList<T> originalList)
        {
            throw new NotImplementedException();
        }

        public virtual IList<AssetAndFunds> FetchAssetAndFunds()
        {
            throw new NotImplementedException();
        }
    }// TODO: Add AMS-specific overrides or custom methods here.
}
