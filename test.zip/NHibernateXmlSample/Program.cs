using NHibernateXmlSample;
using NHibernateXmlSample.Entities;

Console.WriteLine("Connecting to DB...");

using var session = NHibernateHelper.OpenSession();
using var tx = session.BeginTransaction();

var dept = session.Query<Department>().FirstOrDefault(d => d.Name == "Architecture");

// Option 2: Create new department if not exists
if (dept == null)
{
    dept = new Department { Name = "Architecture" };
    session.Save(dept);
}

// Now create the employee with department
var empl = new Employee
{
    Name = "Rajar",
    Department = dept
};


session.Save(empl);
tx.Commit();

var tx1 = session.BeginTransaction();

var depts = new Department { Name = "IT Department" };
depts.Employees.Add(new Employee { Name = "Alice" });
depts.Employees.Add(new Employee { Name = "Bob" });

session.Save(dept); // thanks to cascade="all", employees are saved too

tx1.Commit();

Console.WriteLine($"Employee Saved. ID: {empl.Id}");

// Step 1: Load the Department object by name
var dept1 = session.Query<Department>().FirstOrDefault(d => d.Name == "Architecture");

if (dept1 == null)
{
    Console.WriteLine("Department not found.");
    return;
}

// Step 2: Pass the entity into the HQL query
var employees = session
    .GetNamedQuery("Employee.ByDepartment")
    .SetParameter("dept", dept1) //
    .List<Employee>();

foreach (var emp in employees)
{
    Console.WriteLine($"{emp.Name} - {emp.Department.Name}");
}


foreach (var emp in employees)
{
    Console.WriteLine($"{emp.Id} - {emp.Name} - {emp.Department}");
}

foreach (var emp in employees)
{
    Console.WriteLine($"{emp.Id} | {emp.Name} | {emp.Department?.Name}");
}



var loadedDept = session.Get<Department>(dept.Id);

Console.WriteLine($"Department: {loadedDept.Name}");
foreach (var emp in loadedDept.Employees)
{
    Console.WriteLine($" - {emp.Name}");
}