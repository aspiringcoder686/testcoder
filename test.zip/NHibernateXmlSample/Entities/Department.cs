using FluentNHibernate.Mapping;
using NHibernateXmlSample.Entities;

namespace NHibernateXmlSample.Entities;

//public class EmployeeMap : ClassMap<Employee>
//{
//    public EmployeeMap()
//    {
//        Table("Employees");
//        Id(x => x.Id).GeneratedBy.Identity();
//        Map(x => x.Name).Not.Nullable();
//        Map(x => x.Department).Not.Nullable();
//    }
//}


public class Department
{
    public virtual int Id { get; set; }
    public virtual string Name { get; set; }

    public virtual IList<Employee> Employees { get; set; } = new List<Employee>();
}
