//using NHibernate;
//using NHibernate.Cfg;

//namespace NHibernateXmlSample;

//public static class NHibernateHelper
//{
//    private static ISessionFactory _sessionFactory;

//    public static ISessionFactory SessionFactory
//    {
//        get
//        {
//            if (_sessionFactory == null)
//            {
//                var cfg = new Configuration();
//                cfg.Configure(); // Loads hibernate.cfg.xml
//                _sessionFactory = cfg.BuildSessionFactory();
//            }
//            return _sessionFactory;
//        }
//    }

//    public static ISession OpenSession() => SessionFactory.OpenSession();
//}


using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernateXmlSample;
using NHibernateXmlSample.Entities;
//using NHibernateXmlSample.Mappings;
//using NHibernateXmlSample.Mappings;

namespace NHibernateXmlSample;

public static class NHibernateHelper
{
    private static ISessionFactory _sessionFactory;

    public static ISessionFactory SessionFactory
    {
        get
        {
            if (_sessionFactory == null)
            {
                //_sessionFactory = Fluently.Configure()
                //    .Database(MsSqlConfiguration.MsSql2012
                //        .ConnectionString("Data Source=DESKTOP-4OEOQIM\\SQLEXPRESS;Initial Catalog=testme;Integrated Security=True")
                //        .ShowSql())
                //    .Mappings(m => m.FluentMappings.AddFromAssemblyOf<EmployeeMap>())
                //    .BuildSessionFactory();
                foreach (var res in typeof(Employee).Assembly.GetManifestResourceNames())
                    Console.WriteLine(res);

                _sessionFactory = Fluently.Configure()
    .Database(MsSqlConfiguration.MsSql2012
        .ConnectionString("Data Source=DESKTOP-4OEOQIM\\SQLEXPRESS;Initial Catalog=testme;Integrated Security=True")
        .ShowSql())
    .Mappings(m =>
    {
        //m.FluentMappings.AddFromAssemblyOf<Department>(); // Fluent mappings (optional)
        //m.HbmMappings.AddFromAssemblyOf<Department>();
        m.FluentMappings.AddFromAssemblyOf<Employee>(); // Fluent mappings (optional)
        m.HbmMappings.AddFromAssemblyOf<Employee>();    // XML .hbm.xml mappings
    })
    .BuildSessionFactory();

        }
            return _sessionFactory;
        }
    }

    public static ISession OpenSession() => SessionFactory.OpenSession();
}

