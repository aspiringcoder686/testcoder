
using Microsoft.AspNetCore.Mvc;
using MyCompany.Application.Interfaces;
using MyCompany.Application.DTOs;

namespace MyCompany.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserProfileController : ControllerBase
    {
        private readonly IUserProfileService _userService;

        public UserProfileController(IUserProfileService userService)
        {
            _userService = userService;
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var user = _userService.GetUserProfile(id);
            if (user == null)
                return NotFound();
            return Ok(user);
        }
    }
}
