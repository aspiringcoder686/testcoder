
using MyCompany.Application.DTOs;

namespace MyCompany.Application.Interfaces
{
    public interface IUserProfileService
    {
        UserProfileDto GetUserProfile(int id);
    }
}
