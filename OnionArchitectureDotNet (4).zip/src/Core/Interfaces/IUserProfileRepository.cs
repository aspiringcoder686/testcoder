
using MyCompany.Domain.Entities;

namespace MyCompany.Domain.Interfaces
{
    public interface IUserProfileRepository
    {
        UserProfile GetById(int id);
    }
}
