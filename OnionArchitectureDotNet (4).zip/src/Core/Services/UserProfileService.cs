
using MyCompany.Application.DTOs;
using MyCompany.Application.Interfaces;
using MyCompany.Domain.Interfaces;

namespace MyCompany.Application.Services
{
    public class UserProfileService : IUserProfileService
    {
        private readonly IUserProfileRepository _repository;

        public UserProfileService(IUserProfileRepository repository)
        {
            _repository = repository;
        }

        public UserProfileDto GetUserProfile(int id)
        {
            var user = _repository.GetById(id);
            if (user == null) return null;

            return new UserProfileDto
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email
            };
        }
    }
}
