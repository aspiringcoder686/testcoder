
namespace Core.Persistence
{
    public interface IUnitOfWork
    {
        void SaveChanges();
    }
}
