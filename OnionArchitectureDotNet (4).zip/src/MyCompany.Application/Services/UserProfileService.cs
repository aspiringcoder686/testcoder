
using MyCompany.Application.DTOs;
using MyCompany.Application.Interfaces;
using Core.Persistence;
using MyCompany.Domain.Entities;

namespace MyCompany.Application.Services
{
    public class UserProfileService : IUserProfileService
    {
        private readonly IRepository<UserProfile> _repository;

        public UserProfileService(IRepository<UserProfile> repository)
        {
            _repository = repository;
        }

        public UserProfileDto GetUserProfile(int id)
        {
            var entity = _repository.GetById(id);
            if (entity == null) return null;
            return new UserProfileDto { Id = entity.Id, Name = entity.Name, Email = entity.Email };
        }
    }
}
