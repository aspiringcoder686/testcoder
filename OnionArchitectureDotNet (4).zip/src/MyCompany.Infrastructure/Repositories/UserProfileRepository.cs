
using MyCompany.Domain.Entities;
using Core.Persistence;

namespace MyCompany.Infrastructure.Repositories
{
    public class UserProfileRepository : IRepository<UserProfile>
    {
        public UserProfile GetById(int id)
        {
            return new UserProfile { Id = id, Name = "From DB", Email = "user@domain.com" };
        }

        public void Add(UserProfile entity) { /* Implementation */ }

        public void Remove(UserProfile entity) { /* Implementation */ }
    }
}
