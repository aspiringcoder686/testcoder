﻿import React, { useEffect, useMemo, useState } from 'react'

// Operators for WHERE
const OPS = [
    { k: '==', label: '=' },
    { k: '!=', label: '<>' },
    { k: '>', label: '>' },
    { k: '>=', label: '>=' },
    { k: '<', label: '<' },
    { k: '<=', label: '<=' },
    { k: 'contains', label: 'Contains' },
    { k: 'startswith', label: 'StartsWith' },
    { k: 'endswith', label: 'EndsWith' },
]

// Projection modes
const PROJ_FLAVORS = [
    { k: 'anon', label: 'Anonymous' },
    { k: 'dto', label: 'DTO' }
]

// safe helpers
const S = v => (typeof v === 'string' ? v : (v == null ? '' : String(v)))
const A = v => (Array.isArray(v) ? v : [])
const lc = v => S(v).toLowerCase()
const quoteSql = s => `'${String(s).replace(/'/g, "''")}'`

// --- fuzzy name matching (AM/DM prefixes, Dto/Model suffixes, etc.) ---
const normalize = (s) =>
    S(s)
        .replace(/dto$/i, '').replace(/model$/i, '').replace(/entity$/i, '').replace(/view$/i, '')
        .replace(/^am/i, '').replace(/^dm/i, '')
        .replace(/[^a-z0-9]/gi, '')
        .toLowerCase()

function matchScore(request, candidate) {
    const r = normalize(request), c = normalize(candidate)
    if (!r || !c) return 0
    if (r === c) return 100
    if (r.endsWith(c) || c.endsWith(r)) return 80
    if (r.includes(c) || c.includes(r)) return 60
    return 0
}

export default function RightPanel({ entityName, includes, dashboard }) {
    const [mode, setMode] = useState('ef')

    // Notes per-entity
    const [notes, setNotes] = useState('')
    useEffect(() => {
        const key = entityName ? `notes-${entityName}` : 'notes-__none'
        setNotes(localStorage.getItem(key) || '')
    }, [entityName])
    useEffect(() => {
        const key = entityName ? `notes-${entityName}` : 'notes-__none'
        localStorage.setItem(key, notes || '')
    }, [entityName, notes])

    // === Resolve base entity def (fuzzy) ===
    const baseDef = useMemo(() => {
        if (!entityName) return null
        const defs = A(dashboard)
        let best = null, bestScore = -1
        for (const d of defs) {
            const s = matchScore(entityName, d?.name)
            if (s > bestScore) { best = d; bestScore = s }
        }
        return best
    }, [dashboard, entityName])

    // Keep only includes that belong to this entity
    const cleanedIncludes = useMemo(() => {
        if (!baseDef) return []
        const relNames = new Set(A(baseDef.relationships).map(r => lc(r?.name)))
        return A(includes).filter(s => relNames.has(lc(String(s).split('.')[0])))
    }, [includes, baseDef])

    // === Helpers to find defs ===
    const findDefByName = (name) =>
        A(dashboard).find(d => lc(d?.name) === lc(name)) || null

    const relByName = (def, name) =>
        A(def?.relationships).find(r => lc(r?.name) === lc(name)) || null

    // === Build SCOPES (root + first-level navs + deeper includes) ===
    // scope.key: '' for root, 'Customer', 'Customer.Address', ...
    const scopes = useMemo(() => {
        if (!baseDef) return []
        const map = new Map() // key -> { key, label, targetDef }
        const add = (key, targetDef) => {
            const k = S(key)
            if (!map.has(k)) map.set(k, { key: k, label: k || 'Entity', targetDef })
        }

        add('', baseDef) // root

        // first-level
        for (const r of A(baseDef.relationships)) {
            const tgt = findDefByName(r.class)
            if (tgt) add(r.name, tgt)
        }

        // deeper (from selected include paths)
        for (const p of cleanedIncludes) {
            const steps = String(p || '').split('.').map(s => s.trim()).filter(Boolean)
            if (!steps.length) continue
            let current = baseDef
            for (let i = 0; i < steps.length; i++) {
                const rel = relByName(current, steps[i])
                if (!rel) break
                const tgt = findDefByName(rel.class)
                if (!tgt) break
                const key = steps.slice(0, i + 1).join('.')
                add(key, tgt)
                current = tgt
            }
        }

        return Array.from(map.values())
    }, [baseDef, cleanedIncludes, dashboard])

    // columns for each scope (properties of the scope's target def)
    const columnsByScope = useMemo(() => {
        const dict = {}
        for (const s of scopes) {
            dict[s.key] = A(s.targetDef?.properties || [])
        }
        return dict
    }, [scopes])

    const firstField = (scopeKey) => {
        const cols = columnsByScope[scopeKey] || []
        return cols[0]?.name || ''
    }

    // === Type metadata for EF/SQL per selected scope+column ===
    function metaFor(scopeKey, fieldName) {
        if (!baseDef) return { type: '', isCollection: false }
        if (!scopeKey) {
            const p = A(baseDef.properties).find(x => lc(x?.name) === lc(fieldName))
            return { type: p?.type || '', isCollection: false }
        }
        // walk to final target
        let current = baseDef
        let isCollection = false
        const steps = scopeKey.split('.').filter(Boolean)
        for (const step of steps) {
            const rel = relByName(current, step)
            if (!rel) return { type: '', isCollection }
            if (lc(rel.type) === 'bag') isCollection = true
            const tgt = findDefByName(rel.class)
            if (!tgt) return { type: '', isCollection }
            current = tgt
        }
        const p = A(current.properties).find(x => lc(x?.name) === lc(fieldName))
        return { type: p?.type || '', isCollection }
    }

    const isNumeric = t => /^int|^long|^decimal|^double|^float|^uint|^short|^byte/i.test(t || '')
    const isBool = t => /^bool/i.test(t || '')
    const isDate = t => /^date/i.test(t || '') || /^datetime/i.test(t || '')

    const efValue = (v, type) => {
        if (!type) return `"${v}"`
        if (isBool(type)) return String(v).toLowerCase() === 'true' ? 'true' : 'false'
        if (isNumeric(type)) return String(v)
        if (isDate(type)) return `DateTime.Parse("${v}")`
        return `"${String(v).replace(/"/g, '\\"')}"`
    }
    const sqlValue = (v, type) => {
        if (!type) return quoteSql(v)
        if (isBool(type)) return (String(v).toLowerCase() === 'true') ? '1' : '0'
        if (isNumeric(type)) return String(v)
        return quoteSql(v)
    }

    // =====================================================================================
    // PROJECTION (scope + column + alias)
    // =====================================================================================
    const [projFlavor, setProjFlavor] = useState('anon')
    const [projDtoName, setProjDtoName] = useState(entityName ? `${entityName}Dto` : '')
    useEffect(() => { setProjDtoName(entityName ? `${entityName}Dto` : '') }, [entityName])

    // projRows: { scope:'', field:'', alias:'' }
    const [projRows, setProjRows] = useState([])

    // seed one default projection row when entity/scopes change
    useEffect(() => {
        if (scopes.length) {
            const scope = scopes[0].key
            setProjRows([{ scope, field: firstField(scope), alias: '' }])
        } else {
            setProjRows([])
        }
    }, [entityName, scopes, columnsByScope])

    const addProj = () => {
        const scope = scopes[0]?.key ?? ''
        setProjRows(rs => [...rs, { scope, field: firstField(scope), alias: '' }])
    }
    const clearProj = () => setProjRows([])
    const delProj = i => setProjRows(rs => rs.filter((_, idx) => idx !== i))
    const updProj = (i, patch) => setProjRows(rs => rs.map((r, idx) => idx === i ? { ...r, ...patch } : r))

    // default root columns when none selected (fallbacks)
    const defaultRootCols = useMemo(() => {
        const names = A(baseDef?.properties).map(p => p.name).filter(Boolean)
        if (names.length >= 3) return names.slice(0, 3)
        if (names.length) return names
        return ['/* choose root col */']
    }, [baseDef])

    // =====================================================================================
    // WHERE (scope + column + operator + value)
    // =====================================================================================
    // conds: { scope:'', field:'', op:'==', value:'' }
    const [conds, setConds] = useState([])

    // seed one default where row when entity/scopes change
    useEffect(() => {
        if (scopes.length) {
            const scope = scopes[0].key
            setConds([{ scope, field: firstField(scope), op: '==', value: '' }])
        } else {
            setConds([])
        }
    }, [entityName, scopes, columnsByScope])

    const addCond = () => {
        const scope = scopes[0]?.key ?? ''
        setConds(cs => [...cs, { scope, field: firstField(scope), op: '==', value: '' }])
    }
    const delCond = i => setConds(cs => cs.filter((_, idx) => idx !== i))
    const updCond = (i, patch) => setConds(cs => cs.map((c, idx) => idx === i ? { ...c, ...patch } : c))
    const resetConds = () => setConds([])

    // Build EF predicate
    const efPredicateChunks = useMemo(() => {
        const chunks = []
        for (const c of conds) {
            const path = c.scope ? `${c.scope}.${c.field}` : c.field
            const { type, isCollection } = metaFor(c.scope, c.field)
            const v = efValue(c.value, type)

            if (isCollection) {
                const [head, ...rest] = path.split('.')
                const inner = rest.length ? rest.join('.') : c.field
                if (['contains', 'startswith', 'endswith'].includes(c.op)) {
                    const fn = c.op === 'contains' ? 'Contains' : c.op === 'startswith' ? 'StartsWith' : 'EndsWith'
                    chunks.push(`e.${head}.Any(i => i.${inner}.${fn}(${v}))`)
                } else {
                    chunks.push(`e.${head}.Any(i => i.${inner} ${c.op} ${v})`)
                }
            } else {
                if (['contains', 'startswith', 'endswith'].includes(c.op)) {
                    const fn = c.op === 'contains' ? 'Contains' : c.op === 'startswith' ? 'StartsWith' : 'EndsWith'
                    chunks.push(`e.${path}.${fn}(${v})`)
                } else {
                    chunks.push(`e.${path} ${c.op} ${v}`)
                }
            }
        }
        return chunks
    }, [conds])

    const efWhereClause = useMemo(() => (
        efPredicateChunks.length
            ? `.Where(e => ${efPredicateChunks.map(x => `(${x})`).join(' && ')})`
            : `.Where(e => /* filter */)`
    ), [efPredicateChunks])

    // =====================================================================================
    // Include chain (from selected includes in the table)
    // =====================================================================================
    function normalizeIncludePaths(paths) {
        const seen = new Set(), out = []
        for (const p of A(paths)) {
            const s = String(p || '').trim()
            if (!s) continue
            const k = s.toLowerCase()
            if (!seen.has(k)) { seen.add(k); out.push(s) }
        }
        // Drop plain root include when deeper exists under same root
        const byRoot = new Map()
        out.forEach(p => {
            const r = p.split('.')[0].toLowerCase()
            if (!byRoot.has(r)) byRoot.set(r, [])
            byRoot.get(r).push(p)
        })
        const result = []
        for (const [, list] of byRoot) {
            const hasDeep = list.some(x => x.includes('.'))
            for (const p of list) {
                if (hasDeep && !p.includes('.')) continue
                result.push(p)
            }
        }
        return result
    }

    function buildIncludeChain(path) {
        const segs = String(path).split('.').filter(Boolean)
        if (!segs.length) return ''
        const lines = []
        lines.push(`.Include(e => e.${segs[0]})`)
        for (let i = 1; i < segs.length; i++) {
            const prev = segs[i - 1]
            const v = (prev && prev[0]) ? prev[0].toLowerCase() : 'x'
            lines.push(`.ThenInclude(${v} => ${v}.${segs[i]})`)
        }
        return lines.join('\n        ')
    }

    const includeLines = useMemo(() => {
        const incs = normalizeIncludePaths(cleanedIncludes)
        if (!incs.length) return '// (select include checkboxes to add Include()s)'
        return incs.map(p => buildIncludeChain(p)).join('\n        ')
    }, [cleanedIncludes])

    // =====================================================================================
    // OUTPUTS
    // =====================================================================================

    // Build SELECT (.Select(...))
    const efSelectLine = useMemo(() => {
        // rows fallback to root defaults
        const chosen =
            projRows.length
                ? projRows
                : defaultRootCols.map(n => ({ scope: '', field: n, alias: '' }))

        const piecesAnon = chosen.map(r => {
            const path = r.scope ? `e.${r.scope}.${r.field}` : `e.${r.field}`
            const a = (r.alias || '').trim()
            return a ? `${a} = ${path}` : path
        }).join(', ')

        const dtoType = S(projDtoName || baseDef?.name || entityName || 'DtoType').trim() || 'DtoType'

        if (projFlavor === 'anon') {
            return `.Select(e => new { ${piecesAnon} })`
        }

        const dtoInit = chosen.map(r => {
            const left = (r.alias || (r.scope ? `${r.scope}_${r.field}` : r.field)).replace(/\./g, '_')
            const right = r.scope ? `e.${r.scope}.${r.field}` : `e.${r.field}`
            return `${left} = ${right}`
        }).join(',\n        ')

        return `.Select(e => new ${dtoType}
{
        ${dtoInit}
})`
    }, [projRows, projFlavor, projDtoName, entityName, defaultRootCols, baseDef])

    // Build SQL (joins first-level related tables needed by includes/where/projection)
    const sqlQuery = useMemo(() => {
        if (!entityName || !baseDef) return '-- Pick an entity to generate SQL'
        const def = baseDef
        const baseTable = def?.table || entityName
        const baseAlias = 't0'
        const lines = [`SELECT ${baseAlias}.*`, `FROM ${baseTable} ${baseAlias}`]

        // Roots required: include roots + any scope roots referenced in WHERE/Projection
        const roots = new Set()
        normalizeIncludePaths(cleanedIncludes).forEach(p => roots.add(p.split('.')[0].toLowerCase()))
        projRows.forEach(r => { if (r.scope) roots.add(r.scope.split('.')[0].toLowerCase()) })
        conds.forEach(c => { if (c.scope) roots.add(c.scope.split('.')[0].toLowerCase()) })

        const aliasByRoot = {}
        let i = 1
        for (const root of Array.from(roots)) {
            const rel = relByName(def, root)
            if (!rel) continue
            const targetDef = findDefByName(rel.class)
            const targetTable = targetDef?.table || (rel?.class || root)
            const alias = `t${i++}`
            aliasByRoot[root] = { alias, rel, targetDef }
            if (rel && rel.sourceColumn && rel.destinationColumn) {
                // tX.Dest = t0.Source
                lines.push(`LEFT JOIN ${targetTable} ${alias} ON ${alias}.${rel.destinationColumn} = ${baseAlias}.${rel.sourceColumn}`)
            } else {
                lines.push(`-- LEFT JOIN ${targetTable} ${alias} ON /* TODO: link ${root} */`)
            }
        }

        const whereParts = []
        for (const c of conds) {
            const { type } = metaFor(c.scope, c.field)
            const val = sqlValue(c.value, type)
            let alias = baseAlias
            let colName = c.field

            if (c.scope) {
                const head = c.scope.split('.')[0].toLowerCase()
                alias = aliasByRoot[head]?.alias || alias
                const tdef = aliasByRoot[head]?.targetDef
                const pdef = A(tdef?.properties).find(p => lc(p?.name) === lc(c.field))
                colName = pdef?.column || c.field
            } else {
                const pdef = A(def?.properties).find(p => lc(p?.name) === lc(c.field))
                colName = pdef?.column || c.field
            }

            if (['contains', 'startswith', 'endswith'].includes(c.op)) {
                const pat = c.op === 'contains' ? `'%'+${val}+'%'` : c.op === 'startswith' ? `${val}+'%'` : `'%'+${val}`
                whereParts.push(`${alias}.${colName} LIKE ${pat}`)
            } else {
                whereParts.push(`${alias}.${colName} ${c.op} ${val}`)
            }
        }

        if (whereParts.length) lines.push('WHERE ' + whereParts.map(x => `(${x})`).join(' AND '))
        return lines.join('\n')
    }, [entityName, baseDef, cleanedIncludes, projRows, conds])

    // EF full query
    const efCombinedQuery = useMemo(() => {
        if (!entityName || !baseDef) return '// Pick an entity to generate'
        return `using Microsoft.EntityFrameworkCore;

// ─────────────────────────────────────────────
// EF query with Include() + ThenInclude() + Where + Projection
// ─────────────────────────────────────────────
var list = await db.Set<${baseDef.name}>()
        ${includeLines}
        ${efWhereClause}
        ${efSelectLine}
        .ToListAsync();`
    }, [entityName, baseDef, includeLines, efWhereClause, efSelectLine])

    const out = mode === 'ef' ? efCombinedQuery : sqlQuery
    const copy = async () => { try { await navigator.clipboard.writeText(out); alert('Copied!') } catch { alert('Copy failed') } }

    // ========= UI =========
    if (!entityName) {
        return (
            <aside className="right">
                <div className="panel"><div className="panel-head"><div className="title">Query generator</div></div>
                    <div className="empty" style={{ padding: 12 }}>Pick an entity to start.</div>
                </div>
                <div className="panel"><div className="panel-head"><div className="title">Notes</div></div>
                    <textarea className="notes" placeholder="Notes…" value={notes} onChange={e => setNotes(e.target.value)} />
                </div>
            </aside>
        )
    }

    const scopeOptions = scopes.map(s => ({ value: s.key, label: s.label }))

    return (
        <aside className="right">
            <div className="panel">
                <div className="panel-head">
                    <div className="title">Query generator</div>
                    <div className="seg">
                        <button className={'segbtn' + (mode === 'ef' ? ' active' : '')} onClick={() => setMode('ef')}>EF Include</button>
                        <button className={'segbtn' + (mode === 'sql' ? ' active' : '')} onClick={() => setMode('sql')}>SQL</button>
                    </div>
                </div>

                {/* Projection */}
                <div className="where">
                    <div className="where-head">
                        <div className="wh-title">Projection</div>
                        <div className="wh-actions" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                            <select className="wh-op" value={projFlavor} onChange={e => setProjFlavor(e.target.value)} title="Projection flavor" style={{ maxWidth: 220 }}>
                                {PROJ_FLAVORS.map(f => <option key={f.k} value={f.k}>{f.label}</option>)}
                            </select>
                            {projFlavor === 'dto' && (
                                <input className="wh-val" placeholder="DTO type (e.g., OrderDto)" value={projDtoName} onChange={e => setProjDtoName(e.target.value)} style={{ maxWidth: 240 }} />
                            )}
                            <button className="btn" onClick={addProj} disabled={!scopes.length}>Add</button>
                            <button className="btn" onClick={clearProj} disabled={!projRows.length}>Clear</button>
                        </div>
                    </div>

                    {projRows.length === 0 && (
                        <div className="empty" style={{ padding: '6px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                            <span>No columns selected. Use <b>Add</b> to pick scope & field.</span>
                            <button className="btn" onClick={addProj} disabled={!scopes.length}>Add</button>
                        </div>
                    )}

                    {projRows.map((r, i) => {
                        const cols = columnsByScope[r.scope] || []
                        const disabledCol = !cols.length
                        return (
                            <div className="wh-row" key={i} style={{ gridTemplateColumns: '1fr 1fr .6fr 30px' }}>
                                <select
                                    className="wh-sel"
                                    value={r.scope}
                                    onChange={e => {
                                        const newScope = e.target.value
                                        updProj(i, { scope: newScope, field: firstField(newScope) })
                                    }}
                                >
                                    {scopeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                                </select>
                                <select
                                    className="wh-sel"
                                    value={r.field}
                                    disabled={disabledCol}
                                    onChange={e => updProj(i, { field: e.target.value })}
                                >
                                    {(columnsByScope[r.scope] || []).map(p => (
                                        <option key={p.name} value={p.name}>{p.name}</option>
                                    ))}
                                </select>
                                <input
                                    className="wh-val"
                                    placeholder="alias (optional)"
                                    value={r.alias || ''}
                                    onChange={e => updProj(i, { alias: e.target.value })}
                                />
                                <button className="xbtn" onClick={() => delProj(i)} title="Remove">{'\u00D7'}</button>
                            </div>
                        )
                    })}
                </div>

                {/* WHERE */}
                <div className="where">
                    <div className="where-head">
                        <div className="wh-title">Where</div>
                        <div className="wh-actions">
                            <button className="btn" onClick={addCond} disabled={!scopes.length}>Add</button>
                            <button className="btn" onClick={resetConds} disabled={!conds.length}>Clear</button>
                        </div>
                    </div>

                    {conds.length === 0 && <div className="empty" style={{ padding: '6px 12px' }}>No conditions</div>}

                    {conds.map((c, i) => {
                        const cols = columnsByScope[c.scope] || []
                        const disabledCol = !cols.length
                        return (
                            <div className="wh-row" key={i} style={{ gridTemplateColumns: '1fr 1fr .6fr 1fr 30px' }}>
                                <select
                                    className="wh-sel"
                                    value={c.scope}
                                    onChange={e => {
                                        const newScope = e.target.value
                                        updCond(i, { scope: newScope, field: firstField(newScope) })
                                    }}
                                >
                                    {scopeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                                </select>

                                <select
                                    className="wh-sel"
                                    value={c.field}
                                    disabled={disabledCol}
                                    onChange={e => updCond(i, { field: e.target.value })}
                                >
                                    {(columnsByScope[c.scope] || []).map(p => (
                                        <option key={p.name} value={p.name}>{p.name}</option>
                                    ))}
                                </select>

                                <select className="wh-op" value={c.op} onChange={e => updCond(i, { op: e.target.value })}>
                                    {OPS.map(o => <option key={o.k} value={o.k}>{o.label}</option>)}
                                </select>

                                <input className="wh-val" value={c.value} onChange={e => updCond(i, { value: e.target.value })} placeholder="value" />
                                <button className="xbtn" onClick={() => delCond(i)} title="Remove">{'\u00D7'}</button>
                            </div>
                        )
                    })}
                </div>

                <pre className="code slim">{out}</pre>
                <div className="panel-actions">
                    <button className="btn" onClick={copy}>Copy</button>
                </div>
            </div>

            <div className="panel">
                <div className="panel-head"><div className="title">Notes</div></div>
                <textarea className="notes" placeholder={`Notes for ${entityName}…`} value={notes} onChange={e => setNotes(e.target.value)} />
            </div>
        </aside>
    )
}