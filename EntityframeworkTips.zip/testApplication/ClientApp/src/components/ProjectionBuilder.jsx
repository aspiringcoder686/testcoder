﻿import React, { useMemo, useState } from 'react'

/* ---------- safe helpers ---------- */
const asArr = v => (Array.isArray(v) ? v : [])
const safeStr = v => (typeof v === 'string' ? v : (v == null ? '' : String(v)))
const lc = v => safeStr(v).toLowerCase()

function findEntityMeta(dashboard, name) {
    const list = asArr(dashboard)
    const needle = lc(name)
    if (!needle) return null
    return list.find(e => lc(e?.name) === needle) || null
}

function relTargetName(rel) {
    // handle varied metadata shapes without crashing
    return (
        rel?.target ??
        rel?.to ??
        rel?.className ??
        rel?.entity ??
        rel?.type ??
        ''
    )
}

/* ---------- fields collector (root + 1-level) ---------- */
function collectFields(entityName, dashboard) {
    const root = findEntityMeta(dashboard, entityName)
    if (!root) return { rootScalars: [], navScalars: [], rootMissing: true }

    const props = asArr(root.properties)
    const rels = asArr(root.relationships)

    const rootScalars = props.map(p => ({
        path: safeStr(p?.name),
        label: safeStr(p?.name),
        type: safeStr(p?.type) || 'object'
    })).filter(f => f.path)

    const navScalars = []
    rels.forEach(rel => {
        const relName = safeStr(rel?.name)
        if (!relName) return
        const target = findEntityMeta(dashboard, relTargetName(rel))
        if (!target) return
        asArr(target.properties).forEach(p => {
            const propName = safeStr(p?.name)
            if (!propName) return
            navScalars.push({
                path: `${relName}.${propName}`,
                label: `${relName}.${propName}`,
                type: safeStr(p?.type) || 'object'
            })
        })
    })

    return { rootScalars, navScalars, rootMissing: false }
}

/* ---------- codegen ---------- */
function toSel(path) { return `e.${path}` }
function toAlias(path) { return safeStr(path).replace(/\./g, '_') }

function buildWhere(conds) {
    const cs = asArr(conds)
    if (!cs.length) return ''
    const exprs = cs.map(c => {
        const left = toSel(c?.fieldPath || 'Id')
        const p = (c?.param || 'value').trim()
        switch (c?.op) {
            case '==': case '!=': case '>': case '>=': case '<': case '<=':
                return `${left} ${c.op} ${p}`
            case 'Contains': return `${left}.Contains(${p})`
            case 'StartsWith': return `${left}.StartsWith(${p})`
            case 'EndsWith': return `${left}.EndsWith(${p})`
            default: return `${left} == ${p}`
        }
    })
    return `.Where(e => ${exprs.join(' && ')})`
}

function selAnonymous(cols) {
    if (!cols.length) return '.Select(e => e)'
    const inits = cols.map(c => `${toAlias(c)} = ${toSel(c)}`).join(', ')
    return `.Select(e => new { ${inits} })`
}
function selDto(cols, dtoName) {
    const dto = dtoName?.trim() || 'SomeDto'
    if (!cols.length) return `.Select(e => new ${dto}())`
    const inits = cols.map(c => `${toAlias(c)} = ${toSel(c)}`).join(', ')
    return `.Select(e => new ${dto} { ${inits} })`
}
function exprCode(cols, entity, dtoName) {
    const ent = entity?.trim() || 'Entity'
    const dto = dtoName?.trim() || 'SomeDto'
    const body = cols.length
        ? `new ${dto} { ${cols.map(c => `${toAlias(c)} = ${toSel(c)}`).join(', ')} }`
        : `new ${dto}()`
    return [
        `Expression<Func<${ent}, ${dto}>> selectExpr = e => ${body};`,
        `var list = await db.Set<${ent}>()`,
        `    /* optional Include/ThenInclude here */`,
        `    /* optional Where(...) appended below */`,
        `    .Select(selectExpr)`,
        `    .ToListAsync();`
    ].join('\n')
}
function automapperCode(entity, dtoName) {
    const ent = entity?.trim() || 'Entity'
    const dto = dtoName?.trim() || 'SomeDto'
    return [
        `// AutoMapper profile (once):`,
        `// CreateMap<${ent}, ${dto}>();`,
        ``,
        `var list = await db.Set<${ent}>()`,
        `    /* optional Include/ThenInclude here */`,
        `    /* optional Where(...) appended below */`,
        `    .ProjectTo<${dto}>(_mapper.ConfigurationProvider)`,
        `    .ToListAsync();`
    ].join('\n')
}

export default function ProjectionBuilder({ entityName, dtoName: dtoDefault, dashboard }) {
    const [mode, setMode] = useState('anonymous') // anonymous | dto | expression | automapper
    const [dtoName, setDtoName] = useState(safeStr(dtoDefault))
    const [dbSetEntity, setDbSetEntity] = useState(safeStr(entityName))
    const [selected, setSelected] = useState({})  // { "Customer.Name": true }
    const [conds, setConds] = useState([])        // [{ fieldPath, op, param }]

    // Early no-entity guard — prevents crashes / blank screens
    if (!safeStr(entityName)) {
        return (
            <div className="codepanel">
                <div className="empty">Pick an entity on the left to use Projection Builder.</div>
            </div>
        )
    }

    const { rootScalars, navScalars, rootMissing } = useMemo(
        () => collectFields(entityName, dashboard),
        [entityName, dashboard]
    )

    // If metadata for the picked entity is missing, show a friendly message
    if (rootMissing) {
        return (
            <div className="codepanel">
                <div className="empty">No metadata found for “{entityName}”. Check your Dashboard API.</div>
            </div>
        )
    }

    const allFields = [...asArr(rootScalars), ...asArr(navScalars)]
    const cols = useMemo(() => Object.keys(selected).filter(k => selected[k]), [selected])
    const whereLine = useMemo(() => buildWhere(conds), [conds])

    // Build code defensively
    const code = useMemo(() => {
        try {
            const header = `var query = db.Set<${dbSetEntity || entityName}>()` + (whereLine ? `\n    ${whereLine}` : '')
            if (mode === 'anonymous') {
                return [header, `var list = await query`, `    ${selAnonymous(cols)}`, `    .ToListAsync();`].join('\n')
            }
            if (mode === 'dto') {
                const sel = selDto(cols, dtoName)
                const stub = [
                    '',
                    `// DTO placeholder`,
                    `// public sealed class ${dtoName || 'SomeDto'} {`,
                    cols.length
                        ? `//   ${cols.map(c => `public /*type*/ ${toAlias(c)} { get; set; }`).join('\n//   ')}`
                        : `//   // add members`,
                    `// }`
                ].join('\n')
                return [header, `var list = await query`, `    ${sel}`, `    .ToListAsync();`, stub].join('\n')
            }
            if (mode === 'expression') {
                const ex = exprCode(cols, dbSetEntity || entityName, dtoName)
                return whereLine ? ex.replace('/* optional Where(...) appended below */', whereLine.trim()) : ex
            }
            // automapper
            const am = automapperCode(dbSetEntity || entityName, dtoName)
            return whereLine ? am.replace('/* optional Where(...) appended below */', whereLine.trim()) : am
        } catch (e) {
            return `// Generation error: ${String(e)}`
        }
    }, [mode, cols, dtoName, whereLine, entityName, dbSetEntity])

    const toggle = k => setSelected(s => ({ ...s, [k]: !s[k] }))
    const addCond = () => {
        const defaultField = allFields[0]?.path || rootScalars[0]?.path || 'Id'
        setConds(cs => [...cs, { fieldPath: defaultField, op: '==', param: 'value' }])
    }
    const updateCond = (i, patch) => setConds(cs => cs.map((c, idx) => (idx === i ? { ...c, ...patch } : c)))
    const removeCond = i => setConds(cs => cs.filter((_, idx) => idx !== i))

    return (
        <div className="codepanel">
            <div className="codebar">
                <div className="title">Projection Builder</div>
                <div className="grow" />
                <label style={{ marginRight: 8 }}>
                    <input type="radio" name="mode" checked={mode === 'anonymous'} onChange={() => setMode('anonymous')} /> Anonymous
                </label>
                <label style={{ marginRight: 8 }}>
                    <input type="radio" name="mode" checked={mode === 'dto'} onChange={() => setMode('dto')} /> DTO
                </label>
                <label style={{ marginRight: 8 }}>
                    <input type="radio" name="mode" checked={mode === 'expression'} onChange={() => setMode('expression')} /> Expression
                </label>
                <label style={{ marginRight: 8 }}>
                    <input type="radio" name="mode" checked={mode === 'automapper'} onChange={() => setMode('automapper')} /> AutoMapper
                </label>
                <button className="btn" onClick={() => navigator.clipboard.writeText(code)}>Copy</button>
            </div>

            <div className="wrap controls" style={{ padding: '8px 12px' }}>
                <input className="input" placeholder="DbSet entity (e.g., Order)" value={dbSetEntity} onChange={e => setDbSetEntity(e.target.value)} />
                <input className="input" placeholder="DTO type (e.g., OrderDto)" value={dtoName} onChange={e => setDtoName(e.target.value)} />
            </div>

            <div className="wrap" style={{ gap: 16, padding: '0 12px 8px' }}>
                <div className="box">
                    <div className="subtitle">Columns</div>
                    <div className="tree">
                        <div style={{ fontWeight: 700 }}>Root</div>
                        {asArr(rootScalars).map(f => (
                            <label key={f.path}>
                                <input type="checkbox" checked={!!selected[f.path]} onChange={() => toggle(f.path)} /> {f.label}
                            </label>
                        ))}
                        {!!asArr(navScalars).length && (
                            <>
                                <div style={{ fontWeight: 700, marginTop: 6 }}>Level 1 Navigations</div>
                                {asArr(navScalars).map(f => (
                                    <label key={f.path}>
                                        <input type="checkbox" checked={!!selected[f.path]} onChange={() => toggle(f.path)} /> {f.label}
                                    </label>
                                ))}
                            </>
                        )}
                    </div>
                </div>

                <div className="box">
                    <div className="subtitle">Where (filters)</div>
                    {!conds.length && <div className="empty">No filters. Add one.</div>}
                    {conds.map((c, i) => (
                        <div key={i} className="controls" style={{ marginTop: 6 }}>
                            <select className="select" value={c.fieldPath} onChange={e => updateCond(i, { fieldPath: e.target.value })}>
                                {allFields.map(f => <option key={f.path} value={f.path}>{f.label}</option>)}
                            </select>
                            <select className="select" value={c.op} onChange={e => updateCond(i, { op: e.target.value })}>
                                <option>==</option><option>!=</option><option>{'>'}</option><option>{'>='}</option>
                                <option>{'<'}</option><option>{'<='}</option><option>Contains</option>
                                <option>StartsWith</option><option>EndsWith</option>
                            </select>
                            <input className="input" placeholder="param (e.g., minAmt)" value={c.param} onChange={e => updateCond(i, { param: e.target.value })} />
                            <button className="btn" onClick={() => removeCond(i)}>Del</button>
                        </div>
                    ))}
                    <div style={{ marginTop: 8 }}>
                        <button className="btn" onClick={addCond}>Add filter</button>
                    </div>
                </div>
            </div>

            <pre className="code" style={{ marginTop: 8 }}>{code}</pre>
            {mode === 'automapper' && (
                <div className="empty" style={{ textAlign: 'left' }}>
                    Tip: <b>ProjectTo</b> pulls only members mapped on <i>{dtoName || 'YourDto'}</i>. Trim your DTO to limit columns.
                </div>
            )}
        </div>
    )
}
