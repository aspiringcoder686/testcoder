import React, { useMemo, useState } from 'react'

function normalizeRow(r) {
    const entityPath =
        r?.entityPath ?? r?.entitySide?.name ?? r?.entitySide?.prop ?? ''
    const entityType =
        r?.entityType ?? r?.entitySide?.type ?? r?.entitySide?.clrType ?? ''
    const domainPath =
        r?.domainPath ?? r?.domainSide?.name ?? r?.domainSide?.prop ?? ''
    const domainType =
        r?.domainType ?? r?.domainSide?.type ?? r?.domainSide?.clrType ?? ''

    const includeSuggestion = (r?.includeSuggestion || '').trim()
    const isEntityNav =
        includeSuggestion.length > 0 || (typeof r?.match === 'number' && r.match === 0)

    return {
        ...r,
        entityPath,
        entityType,
        domainPath,
        domainType,
        includeSuggestion: includeSuggestion || (isEntityNav ? entityPath : ''),
        isEntityNav,
    }
}

export default function SplitTable({
    rows = [],
    filter = '',
    onSelectEntityIncludes = () => { },
    onSelectDomainIncludes = () => { },
}) {
    const [pickedEntity, setPickedEntity] = useState(new Set())
    const [pickedDomain, setPickedDomain] = useState(new Set())

    const normalized = useMemo(() => rows.map(normalizeRow), [rows])

    // Build unique lists for each side (no matching)
    const { entityItems, domainItems } = useMemo(() => {
        const t = (filter || '').toLowerCase()
        const eMap = new Map()
        const dMap = new Map()

        const add = (map, key, val) => {
            const k = String(key || '').toLowerCase()
            if (!k) return
            if (!map.has(k)) map.set(k, val)
        }

        for (const r of normalized) {
            if (r.entityPath) {
                const hay = (r.entityPath + ' ' + (r.entityType || '')).toLowerCase()
                if (!t || hay.includes(t)) {
                    add(eMap, r.entityPath, {
                        path: r.entityPath,
                        type: r.entityType,
                        include: r.isEntityNav ? (r.includeSuggestion || r.entityPath) : '',
                        isNav: !!r.isEntityNav,
                        keyType: r.keyType,
                        navTargetTable: r.navTargetTable,
                    })
                }
            }
            if (r.domainPath) {
                const hay = (r.domainPath + ' ' + (r.domainType || '')).toLowerCase()
                if (!t || hay.includes(t)) {
                    add(dMap, r.domainPath, {
                        path: r.domainPath,
                        type: r.domainType,
                        include: r.domainPath, // independent list; no relation to entity includes
                    })
                }
            }
        }

        return {
            entityItems: Array.from(eMap.values()),
            domainItems: Array.from(dMap.values()),
        }
    }, [normalized, filter])

    // ---- entity picks
    const setEntityAndNotify = (next) => {
        setPickedEntity(next)
        onSelectEntityIncludes(Array.from(next))
    }
    const toggleEntity = (incl) => {
        if (!incl) return
        const next = new Set(pickedEntity)
        next.has(incl) ? next.delete(incl) : next.add(incl)
        setEntityAndNotify(next)
    }
    const selectAllEntityNavs = () => {
        const all = entityItems.filter(x => x.include).map(x => x.include)
        setEntityAndNotify(new Set(all))
    }
    const clearEntity = () => setEntityAndNotify(new Set())

    // ---- domain picks
    const setDomainAndNotify = (next) => {
        setPickedDomain(next)
        onSelectDomainIncludes(Array.from(next))
    }
    const toggleDomain = (incl) => {
        if (!incl) return
        const next = new Set(pickedDomain)
        next.has(incl) ? next.delete(incl) : next.add(incl)
        setDomainAndNotify(next)
    }
    const selectAllDomain = () => {
        const all = domainItems.map(x => x.include).filter(Boolean)
        setDomainAndNotify(new Set(all))
    }
    const clearDomain = () => setDomainAndNotify(new Set())

    return (
        <div className="card" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {/* ENTITY PANEL */}
            <div>
                <div className="title">Entity</div>

                <div className="toolbar" style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '8px 0' }}>
                    <button className="btn" onClick={selectAllEntityNavs}>Select all navigations</button>
                    <button className="btn" onClick={clearEntity}>Clear</button>
                </div>

                <div className="list" style={{ border: '1px solid #ddd', borderRadius: 8, padding: 8, maxHeight: 450, overflowY: 'auto' }}>
                    {entityItems.length === 0 && <div className="muted">No entity items</div>}
                    {entityItems.map((it, i) => {
                        const picked = it.include && pickedEntity.has(it.include)
                        return (
                            <div key={i} className="row" style={{ display: 'grid', gridTemplateColumns: '1fr 140px 1fr', gap: 12, alignItems: 'center', padding: '6px 0' }}>
                                <div>
                                    <div className="path">{it.path}</div>
                                    <div className="type muted">{it.type || '�'}</div>
                                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 6 }}>
                                        {it.keyType && <span className="chip">{it.keyType}</span>}
                                        {it.navTargetTable && <span className="muted small">Table: {it.navTargetTable}</span>}
                                    </div>
                                </div>
                                <div>{it.isNav ? <span className="chip chip-green">Navigation</span> : <span className="chip chip-blue">Property</span>}</div>
                                <div>
                                    {it.include ? (
                                        <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                                            <input type="checkbox" checked={picked} onChange={() => toggleEntity(it.include)} />
                                            <code>{it.include}</code>
                                        </label>
                                    ) : <span className="muted small">(no include)</span>}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>

            {/* DOMAIN PANEL */}
            <div>
                <div className="title">Domain</div>

                <div className="toolbar" style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '8px 0' }}>
                    <button className="btn" onClick={selectAllDomain}>Select all</button>
                    <button className="btn" onClick={clearDomain}>Clear</button>
                </div>

                <div className="list" style={{ border: '1px solid #ddd', borderRadius: 8, padding: 8, maxHeight: 450, overflowY: 'auto' }}>
                    {domainItems.length === 0 && <div className="muted">No domain items</div>}
                    {domainItems.map((it, i) => {
                        const picked = it.include && pickedDomain.has(it.include)
                        return (
                            <div key={i} className="row" style={{ display: 'grid', gridTemplateColumns: '1fr 140px 1fr', gap: 12, alignItems: 'center', padding: '6px 0' }}>
                                <div>
                                    <div className="path">{it.path}</div>
                                    <div className="type muted">{it.type || '�'}</div>
                                </div>
                                <div><span className="chip">Field</span></div>
                                <div>
                                    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                                        <input type="checkbox" checked={picked} onChange={() => toggleDomain(it.include)} />
                                        <code>{it.include}</code>
                                    </label>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    )
}
