import React, { useEffect, useMemo, useState } from 'react'

// Helpers
const S = v => (typeof v === 'string' ? v : (v == null ? '' : String(v)))
const lc = v => S(v).toLowerCase()
const A = v => (Array.isArray(v) ? v : (v ? [v] : []))

const isNav = r => lc(r?.match) === 'navigation'
const isProp = r => lc(r?.match) === 'property'
const incPathOf = r => S(r?.includeSuggestion || r?.entityPath || '')
const hasDotPath = r => S(r?.entityPath).includes('.')

function Chips({ r }) {
    const chips = []
    if (isNav(r)) chips.push(<span key="nav" className="chip nav">NAV</span>)
    if (isProp(r)) chips.push(<span key="prop" className="chip prop">PROP</span>)
    if (r?.keyType === 'PK' || r?.keyType === 'PKC') chips.push(<span key="pk" className="chip">PK</span>)
    if (r?.keyType === 'FK') chips.push(<span key="fk" className="chip">FK</span>)
    return <>{chips}</>
}

export default function EntityTable({ rows, filter = '', onFilterChange, onSelectEntityIncludes }) {
    // includes are navigation paths only
    const [includes, setIncludes] = useState([])
    const includesSet = useMemo(() => new Set(includes), [includes])

    // toggle: show properties of navigation objects (Customer.Address.City, etc.)
    const [showNavProps, setShowNavProps] = useState(() => {
        try { return localStorage.getItem('et.showNavProps') === '1' } catch { return false }
    })
    useEffect(() => {
        try { localStorage.setItem('et.showNavProps', showNavProps ? '1' : '0') } catch { }
    }, [showNavProps])

    // reset includes when rows change (switch entity)
    useEffect(() => { setIncludes([]) }, [rows])

    // emit selected nav paths upwards
    useEffect(() => {
        const navOnly = rows
            .filter(isNav)
            .map(incPathOf)
            .filter(p => includesSet.has(p))
        onSelectEntityIncludes?.(navOnly)
    }, [includesSet, rows, onSelectEntityIncludes])

    function toggleInclude(path) {
        if (!path) return
        setIncludes(prev => prev.includes(path)
            ? prev.filter(p => p !== path)
            : [...prev, path]
        )
    }

    // Build list:
    //  - ALWAYS show root properties (no dot path)
    //  - ALWAYS show navigation rows
    //  - ONLY show properties under navigations (have dot path) when showNavProps = true
    const baseList = useMemo(() => {
        return rows.filter(r =>
            isNav(r) ||
            (isProp(r) && (!hasDotPath(r) || showNavProps)) // keep root props; gated nav props
        )
    }, [rows, showNavProps])

    // Apply text filter
    const filtered = useMemo(() => {
        const q = lc(filter)
        if (!q) return baseList
        return baseList.filter(r => {
            const hay = [
                S(r?.entityPath),
                S(r?.entitySide?.name),
                S(r?.entitySide?.type),
                S(r?.navTargetTable),
                S(r?.keyType),
                S(r?.match)
            ].join(' ').toLowerCase()
            return hay.includes(q)
        })
    }, [baseList, filter])

    return (
        <div className="table">
            <div className="title-row">
                <div className="title"></div>
                <div className="filter-box">
                    <input
                        type="text"
                        placeholder="Filter�"
                        value={filter}
                        onChange={e => onFilterChange?.(e.target.value)}
                    />
                </div>
            </div>
            <div className="tablebar">
                <div className="left">
                    <span className="inline">Showing <b>{filtered.length}</b> of {baseList.length}</span>
                </div>
                <div className="right">
                    <label className="pick">
                        <input
                            type="checkbox"
                            checked={showNavProps}
                            onChange={e => setShowNavProps(e.target.checked)}
                        />
                        Show properties of navigations
                    </label>
                </div>
            </div>

            <div className="thead row">
                <div className="th">Entity</div>
                <div className="th">Kind / Keys</div>
                <div className="th">Target / Table</div>
                <div className="th">Include</div>
            </div>

            {filtered.length === 0 && (
                <div className="row">
                    <div className="td empty">No rows</div>
                </div>
            )}

            {filtered.map((r, idx) => {
                const path = S(r?.entityPath)
                const type = S(r?.entitySide?.type)
                const tgt = S(r?.navTargetTable)
                const incPath = incPathOf(r)
                const checked = includesSet.has(incPath)

                return (
                    <div className="row" key={idx}>
                        {/* Entity cell */}
                        <div className="td">
                            <div className="cell-title">{path}</div>
                            {type && <div className="sub">{type}</div>}
                        </div>

                        {/* Kind / Keys */}
                        <div className="td">
                            <Chips r={r} />
                        </div>

                        {/* Target / Table */}
                        <div className="td">
                            {isNav(r)
                                ? (tgt ? <span className="chip">{tgt}</span> : <span className="muted placeholder">None</span>)
                                : <span className="muted placeholder">None</span>}
                        </div>

                        {/* Include checkbox ONLY for navigations */}
                        <div className="td inc-cell">
                            {isNav(r) ? (
                                <input
                                    type="checkbox"
                                    checked={checked}
                                    onChange={() => toggleInclude(incPath)}
                                    aria-label={`Include ${incPath}`}
                                />
                            ) : (
                                <span className="muted placeholder">None</span>
                            )}
                        </div>
                    </div>
                )
            })}
        </div>
    )
}
