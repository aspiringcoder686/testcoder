﻿import React, { useState, useEffect } from 'react'
import { getTemplateQueries } from '../api'

export default function TemplateQueriesPanel() {
    const [templates, setTemplates] = useState('')
    const [err, setErr] = useState('')

    async function loadTemplates() {
        try {
            const txt = await getTemplateQueries()   // 👈 call API helper
            setTemplates(txt)
        } catch (e) {
            setErr(String(e))
        }
    }

    useEffect(() => {
        loadTemplates()
    }, [])

    return (
        <div className="pad">
            <div className="title">Template Queries</div>
            <button className="btn" onClick={loadTemplates}>Load Templates</button>
            <pre className="code">
                {templates || (err ? err : '(no template queries loaded)')}
            </pre>
        </div>
    )
}