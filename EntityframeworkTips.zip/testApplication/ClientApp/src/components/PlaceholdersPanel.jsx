﻿import React, { useMemo } from 'react'

// tiny helpers
const S = v => (typeof v === 'string' ? v : (v == null ? '' : String(v)))
const lc = v => S(v).toLowerCase()
const A = v => (Array.isArray(v) ? v : [])
const normalize = (s) =>
    S(s)
        .replace(/dto$|model$|entity$|view$/i, '')
        .replace(/^am|^dm/i, '')
        .replace(/[^a-z0-9]/gi, '')
        .toLowerCase()

function fuzzyPick(defs, name) {
    if (!name) return null
    const rn = normalize(name)
    let best = null, score = -1
    for (const d of A(defs)) {
        const dn = normalize(d?.name)
        let s = 0
        if (rn === dn) s = 100
        else if (rn.endsWith(dn) || dn.endsWith(rn)) s = 80
        else if (rn.includes(dn) || dn.includes(rn)) s = 60
        if (s > score) { best = d; score = s }
    }
    return best
}

export default function PlaceholdersPanel({ pair, dashboard }) {
    const entityName = pair?.entity || pair?.name || ''
    const def = useMemo(() => fuzzyPick(dashboard, entityName), [dashboard, entityName])

    const pk = useMemo(() => {
        const props = A(def?.properties)
        const byPrimary = props.find(p => p.isPrimary)
        if (byPrimary) return byPrimary.name
        const byId = props.find(p => lc(p.name) === 'id')
        return byId?.name || props[0]?.name || 'Id'
    }, [def])

    const sampleProps = useMemo(() => {
        const props = A(def?.properties).map(p => p.name).filter(Boolean)
        const noPk = props.filter(n => n !== pk)
        const picks = (noPk.length >= 2 ? [pk, noPk[0], noPk[1]] : props.slice(0, 3))
        return picks.length ? picks : ['Id', 'Name']
    }, [def, pk])

    // pick one or two example includes (depth up to 2 if available)
    const includeExamples = useMemo(() => {
        const one = A(def?.relationships)[0]
        if (!one) return []
        const tgt = A(dashboard).find(d => lc(d?.name) === lc(one.class))
        const two = A(tgt?.relationships)[0]
        const a = `.Include(e => e.${one.name})`
        const b = two ? `\n    .ThenInclude(x => x.${two.name})` : ''
        return [a + b]
    }, [def, dashboard])

    const dtoName = useMemo(() => (entityName ? `${entityName}Dto` : 'MyDto'), [entityName])

    const code = useMemo(() => {
        if (!entityName || !def) {
            return `// Pick an entity to generate placeholders

// Tip: select an entity from the sidebar.
// This panel will auto-generate EF Core snippets for it.`
        }

        const [p1, p2, p3] = sampleProps
        const inc = includeExamples[0] || '// (no navigations found)'

        return `// ─────────────────────────────────────────────
// EF Core placeholders for ${def.name}
// ─────────────────────────────────────────────
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

// 1) Include (with optional ThenInclude)
var list1 = await db.Set<${def.name}>()
    ${inc}
    .ToListAsync();

// 2) Where (by primary key and optional text match)
var id = /* ${pk} value */;
var text = /* search text */;
var list2 = await db.Set<${def.name}>()
    .Where(e => e.${pk} == id${p2 ? ` || EF.Functions.Like(e.${p2}, "%" + text + "%")` : ''
            })
    .ToListAsync();

// 3) Anonymous projection
var list3 = await db.Set<${def.name}>()
    .Select(e => new { e.${p1}${p2 ? `, e.${p2}` : ''}${p3 ? `, e.${p3}` : ''} })
    .ToListAsync();

// 4) DTO projection
var list4 = await db.Set<${def.name}>()
    .Select(e => new ${dtoName}
    {
        ${p1} = e.${p1}${p2 ? `,\n        ${p2} = e.${p2}` : ''
            }${p3 ? `,\n        ${p3} = e.${p3}` : ''
            }
    })
    .ToListAsync();

// 5) ProjectTo (AutoMapper)
using AutoMapper.QueryableExtensions;
var list5 = await db.Set<${def.name}>()
    .ProjectTo<${dtoName}>(mapper.ConfigurationProvider)
    .ToListAsync();

// 6) Query options
var list6 = await db.Set<${def.name}>()
    .AsNoTracking()
    .AsSplitQuery()
    .ToListAsync();

// 7) Expression (reusable predicate)
Expression<Func<${def.name}, bool>> predicate =
    e => e.${pk} == id${p2 ? ` || EF.Functions.Like(e.${p2}, "%" + text + "%")` : ''};

var list7 = await db.Set<${def.name}>()
    .Where(predicate)
    .ToListAsync();
`
    }, [entityName, def, pk, sampleProps, dtoName, includeExamples])

    return (
        <div className="pad">
            <div className="title">Placeholders — {entityName || 'pick an entity'}</div>
            <pre className="code">{code}</pre>
        </div>
    )
}
