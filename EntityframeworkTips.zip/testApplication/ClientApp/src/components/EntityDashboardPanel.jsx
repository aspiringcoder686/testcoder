﻿import React from 'react'

export default function EntityDashboardPanel({ pair, dashboard }) {
    if (!pair?.entity) {
        return <div className="muted">Pick an entity to view its dashboard.</div>
    }

    const lc = s => (s || '').toLowerCase()
    const def = dashboard.find(
        d => lc(d.name) === lc(pair.entity) || lc(d.name) === lc(pair.name)
    )

    if (!def) {
        return <div className="muted">No dashboard info for {pair.entity}.</div>
    }

    return (
        <div className="dash-card">
            <div className="dash-head">
                <div>
                    <div className="title">{def.name}</div>
                    <div className="sub">Table: {def.table}</div>
                </div>
                <div className="chips">
                    <span className="chip">Props: {def.properties?.length || 0}</span>
                    <span className="chip">Rels: {def.relationships?.length || 0}</span>
                    <span className="chip">Components: {def.components?.length || 0}</span>
                    <span className="chip">Queries: {def.queries?.length || 0}</span>
                </div>
            </div>

            {/* Properties */}
            <h4>Properties</h4>
            <ul>
                {def.properties?.map((p, i) => (
                    <li key={i}>
                        {p.name} ({p.type}) [col: {p.column}]
                    </li>
                ))}
            </ul>

            {/* Navigation */}
            <h4>Navigation</h4>
            <ul>
                {def.relationships?.map((r, i) => (
                    <li key={i}>
                        {r.name} → {r.class} ({r.type})
                        {r.sourceColumn && r.destinationColumn && (
                            <> [FK: {r.sourceColumn} → {r.destinationColumn}]</>
                        )}
                    </li>
                ))}
            </ul>

            {/* Components */}
            {def.components?.length > 0 && (
                <>
                    <h4>Components</h4>
                    <ul>
                        {def.components.map((c, i) => (
                            <li key={i}>{c.name} ({c.class})</li>
                        ))}
                    </ul>
                </>
            )}

            {/* Queries */}
            {def.queries?.length > 0 && (
                <>
                    <h4>Queries</h4>
                    <ul>
                        {def.queries.map((q, i) => (
                            <li key={i}>
                                {q.name} — {q.queryType || 'SQL'}
                                {q.sql && <pre className="code slim">{q.sql}</pre>}
                            </li>
                        ))}
                    </ul>
                </>
            )}
        </div>
    )
}