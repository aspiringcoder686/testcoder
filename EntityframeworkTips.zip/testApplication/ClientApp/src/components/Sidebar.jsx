﻿import React, { useMemo, useState } from 'react'

function keyOf(e) {
    const n = (e?.name ?? '').trim()
    const en = (e?.entityName ?? '').trim()
    return `${en}||${n}`.toLowerCase()
}

function labelOf(e) {
    const n = (e?.name ?? '').trim()
    const en = (e?.entityName ?? '').trim()
    return `${en} vs ${n}`
}

export default function Sidebar({ entities = [], selectedKey = '', onPick }) {
    const [q, setQ] = useState('')

    const list = useMemo(() => {
        const needle = q.trim().toLowerCase()
        if (!needle) return entities
        return entities.filter(e => {
            const n = (e?.name ?? '').toLowerCase()
            const en = (e?.entityName ?? '').toLowerCase()
            return n.includes(needle) || en.includes(needle)
        })
    }, [entities, q])

    return (
        <div className="nav">
            {/* Header with H logo */}
            <div className="nav-header">
                <div className="logo-circle">H</div>
                <div className="nav-title">Entity Analyzer</div>
            </div>

            {/* Search */}
            <div className="search">
                <input
                    type="search"
                    placeholder="Filter entities…"
                    value={q}
                    onChange={e => setQ(e.target.value)}
                />
                {q && (
                    <button className="xbtn" onClick={() => setQ('')} aria-label="Clear">
                        ✕
                    </button>
                )}
            </div>

            {/* List */}
            <div className="elist">
                {list.map((e, i) => {
                    const k = keyOf(e)
                    const isActive = selectedKey && k === selectedKey.toLowerCase()
                    return (
                        <button
                            key={k || i}
                            className={`eitem${isActive ? ' active' : ''}`}
                            title={labelOf(e)}
                            onClick={() => onPick?.(e)}
                        >
                            {labelOf(e)}
                        </button>
                    )
                })}
                {!list.length && <div className="empty">No matches</div>}
            </div>
        </div>
    )
}
