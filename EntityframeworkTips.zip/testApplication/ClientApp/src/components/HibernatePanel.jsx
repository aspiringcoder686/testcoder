﻿import React, { useEffect, useState } from 'react'
import { getHibernate } from '../api'

export default function HibernatePanel({ name, setName, dashboard }) {
    const [hbm, setHbm] = useState('')
    const [err, setErr] = useState('')
    const [loading, setLoading] = useState(false)
    const [tab, setTab] = useState('xml') // 'xml' | 'metrics'

    async function openHibernateFile() {
        if (!name) return
        setLoading(true)
        try {
            const xml = await getHibernate(name)
            setHbm(xml || '')
        } catch (e) {
            setErr(String(e))
        } finally {
            setLoading(false)
        }
    }

    // auto-load whenever the name changes
    useEffect(() => {
        if (name) openHibernateFile()
    }, [name])

    const def = (dashboard || []).find(d => (d?.name || '').toLowerCase() === (name || '').toLowerCase())

    return (
        <div className="pad">
            <div className="title">{name ? `${name}.hbm.xml` : 'Hibernate (.hbm.xml)'}</div>

            <div className="tabs" style={{ marginTop: 10 }}>
                <button className={'tab' + (tab === 'xml' ? ' active' : '')} onClick={() => setTab('xml')}>XML</button>
                <button className={'tab' + (tab === 'metrics' ? ' active' : '')} onClick={() => setTab('metrics')}>Metrics</button>
            </div>

            {tab === 'xml' && (
                <>
                    <form
                        onSubmit={(e) => { e.preventDefault(); openHibernateFile() }}
                        style={{ display: 'flex', gap: 8, margin: '10px 0' }}
                    >
                        <input
                            type="text"
                            placeholder="Enter type (e.g., Customer)"
                            value={name || ''}
                            onChange={e => setName(e.target.value)}   // 👈 typing works now
                            className="wh-val"
                            style={{ flex: 1 }}
                        />
                        <button type="submit" className="btn">Open</button>
                    </form>

                    {loading ? <div>Loading...</div> : (
                        <pre className="code">{hbm || (err ? String(err) : '(empty)')}</pre>
                    )}
                </>
            )}

            {tab === 'metrics' && (
                <div className="dash">
                    {!def && <div className="muted">No metrics available.</div>}
                    {def && (
                        <div className="dash-card">
                            <div className="dash-head">
                                <div>
                                    <div className="title">{def.name}</div>
                                    <div className="sub">Table: {def.table}</div>
                                </div>
                            </div>

                            <h4>Properties</h4>
                            <ul>{(def.properties || []).map((p, i) => (
                                <li key={i}>{p.name} ({p.type}) [col: {p.column}]</li>
                            ))}</ul>

                            <h4>Relationships</h4>
                            <ul>{(def.relationships || []).map((r, i) => (
                                <li key={i}>{r.name} → {r.class} ({r.type})</li>
                            ))}</ul>

                            <h4>Components</h4>
                            <ul>{(def.components || []).map((c, i) => (
                                <li key={i}>{c.name} ({c.class})</li>
                            ))}</ul>

                            <h4>Queries</h4>
                            <ul>{(def.queries || []).map((q, i) => (
                                <li key={i}>{q.name} — {q.queryType}</li>
                            ))}</ul>
                        </div>
                    )}
                </div>
            )}
        </div>
    )
}