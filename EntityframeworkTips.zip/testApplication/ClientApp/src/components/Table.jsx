import React, { useEffect, useMemo, useState } from 'react'

function kindFromMatch(r) {
    if (typeof r.match === 'number') {
        switch (r.match) {
            case 0: return 'Navigation'
            case 1: return 'Property'
            default: return 'Missing'
        }
    }
    const s = String(r.match || '').toLowerCase()
    if (s.startsWith('nav')) return 'Navigation'
    if (s.startsWith('prop')) return 'Property'
    return 'Missing'
}

export default function Table({ rows, filter = '', onSelectIncludes }) {
    const [navOnly, setNavOnly] = useState(false)
    const [picked, setPicked] = useState(() => new Set())

    const filtered = useMemo(() => {
        const t = filter.toLowerCase()
        return rows.filter(r => {
            const hay = [
                r.entityPath, r.entityType,
                r.domainPath, r.domainType,
                r.notes, r.includeSuggestion,
                r.navTargetTable || ''
            ].join(' ').toLowerCase()

            let kind = kindFromMatch(r)
            if ((r.includeSuggestion ?? '').trim().length > 0) { kind = 'Navigation' }

            const okText = !t || hay.includes(t)
            const okKind = !navOnly || kind === 'Navigation'
            return okText && okKind
        })
    }, [rows, filter, navOnly])

    useEffect(() => {
        if (onSelectIncludes) onSelectIncludes(Array.from(picked))
    }, [picked, onSelectIncludes])

    const togglePick = (incl) => {
        const s = new Set(picked)
        if (s.has(incl)) s.delete(incl); else s.add(incl)
        setPicked(s)
    }

    const selectAllNavs = () => {
        const s = new Set(picked)
        for (const r of filtered) {
            if ((r.includeSuggestion ?? '').trim().length > 0) s.add(r.includeSuggestion)
        }
        setPicked(s)
    }

    const clearPicks = () => setPicked(new Set())

    return (
        <div className="table">
            <div className="tablebar">
                <div className="left">
                    <button className="btn" onClick={selectAllNavs}>Select all navs</button>
                    <button className="btn" onClick={clearPicks}>Clear</button>
                </div>
                <label className="inline">
                    <input
                        type="checkbox"
                        checked={navOnly}
                        onChange={e => setNavOnly(e.target.checked)}
                    />
                    <span>Navigations only</span>
                </label>
            </div>

            <div className="thead">
                <div className="th">Entity</div>
                <div className="th">Match</div>
                <div className="th">Domain</div>
                <div className="th">Include</div>
            </div>

            <div>
                {filtered.map((r, i) => {
                    let kind = kindFromMatch(r)
                    if ((r.includeSuggestion ?? '').trim().length > 0) { kind = 'Navigation' }
                    const chipClass =
                        kind === 'Navigation' ? 'chip nav' :
                            kind === 'Property' ? 'chip prop' : 'chip miss'

                    const incl = r.includeSuggestion
                    const isPickable = (incl ?? '').trim().length > 0
                    const isPicked = isPickable && picked.has(incl)

                    const keyLabel =
                        r.keyType === 'PKC' ? 'PK (composite)' :
                            r.keyType === 'PK' ? 'PK' :
                                r.keyType === 'FK' ? 'FK' : null

                    return (
                        <div className="row" key={i}>
                            <div className="td">
                                <div className="cell-title">
                                    {r.entityPath}
                                    {keyLabel && <span className="chip" style={{ marginLeft: 6 }}>{keyLabel}</span>}
                                </div>
                                <div className="sub">{r.entityType}</div>
                                {r.navTargetTable && <div className="sub">Table: {r.navTargetTable}</div>}
                            </div>
                            <div className="td">
                                <span className={chipClass}>{kind}</span>
                                {r.notes && <div className="sub">{r.notes}</div>}
                            </div>
                            <div className="td">
                                <div className="cell-title">{r.domainPath}</div>
                                <div className="sub">{r.domainType}</div>
                            </div>
                            <div className="td">
                                {isPickable ? (
                                    <label className="pick">
                                        <input
                                            type="checkbox"
                                            checked={isPicked}
                                            onChange={() => togglePick(incl)}
                                        />
                                        <code>{incl}</code>
                                    </label>
                                ) : (
                                    <span className="empty">(none)</span>
                                )}
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}