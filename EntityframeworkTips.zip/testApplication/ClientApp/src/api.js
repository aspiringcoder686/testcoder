﻿export async function getEntities() {
    const res = await fetch('/api/comparison/entities')
    if (!res.ok) throw new Error('Failed to load entities')
    return res.json()
}

export async function compare(entity, domain, depth = 5) {
    const q = new URLSearchParams({ entity, domain, depth })
    const res = await fetch('/api/comparison/compare?' + q.toString())
    if (!res.ok) throw new Error('Failed to load comparison')
    return res.json()
}

export async function getDashboard() {
    const res = await fetch('/api/comparison/dashboard')
    if (!res.ok) throw new Error('Failed to load dashboard')
    return res.json()
}

// NEW
export async function getSqlScript() {
    const res = await fetch('/api/comparison/sql')
    if (!res.ok) throw new Error('Failed to load SQL script')
    return res.text()
}

// NEW
export async function getHibernate(entity) {
    const q = new URLSearchParams({ entity })
    const res = await fetch('/api/comparison/hibernate?' + q.toString())
    if (!res.ok) throw new Error('Failed to load HBM')
    return res.text()
}

export async function getTemplateQueries() {
    const res = await fetch('/api/comparison/templates') // 👈 backend endpoint
    if (!res.ok) throw new Error(await res.text())
    return await res.text()
}