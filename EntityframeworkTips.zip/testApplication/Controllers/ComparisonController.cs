using ComparatorWeb.Core;
using ComparatorWeb.Data;
using ComparatorWeb.Services;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace ComparatorWeb.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ComparisonController : ControllerBase
{
    private readonly AppDb _db;
    private static readonly Assembly[] _assemblies = new[] { Assembly.GetExecutingAssembly() };

    public ComparisonController(AppDb db) => _db = db;

    [HttpGet("entities")]
    public IActionResult Entities()
    {
        var defs = EntityDefinitionLoader.Load();

        var result = defs
            .Select(d => new
            {
                name = d.Name,
                entityName = string.IsNullOrWhiteSpace(d.EntityName)
                    ? d.Name // fallback if EntityName wasn�t set
                    : d.EntityName
            })
            .OrderBy(x => x.name, StringComparer.OrdinalIgnoreCase)
            .ToList();

        return Ok(result);
    }

    [HttpGet("compare")]
    public IActionResult Compare(string entity, string? domain = null, int depth = 5)
    {
        domain ??= entity + "Dto";
        var rows = DomainEntityComparer.Compare(_db, domain, entity, _assemblies, maxDepth: depth);
        return Ok(rows);
    }

    [HttpGet("dashboard")]
    public IActionResult Dashboard()
    {
        var defs = EntityDefinitionLoader.Load();
        return Ok(defs);
    }

    // NEW: return a single SQL file (text) for all known tables
    [HttpGet("sql")]
    public IActionResult Sql()
        => Content(SqlScaffolder.GenerateSingleScript(), "text/plain");

    // NEW: return HBM XML for a specific entity
    [HttpGet("hibernate")]
    public IActionResult Hibernate(string entity)
    {
        var xml = Renderer.HBMRender(entity);
        return Content(xml, "application/xml");
    }

    [HttpGet("templates")]
    public IActionResult GetTemplateQueries()
    {
        var content = Renderer.TemplateQueries();
        return Content(content, "text/plain");
    }

}
