using Microsoft.EntityFrameworkCore;

namespace ComparatorWeb.Data;

public class AppDb : DbContext
{
    public AppDb(DbContextOptions<AppDb> options) : base(options) { }

    public DbSet<AMOrder> Orders => Set<AMOrder>();
    public DbSet<AMCustomer> Customers => Set<AMCustomer>();
    public DbSet<AMAddress> Addresses => Set<AMAddress>();
    public DbSet<AMOrderItem> OrderItems => Set<AMOrderItem>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<AMCustomer>()
          .HasOne(c => c.Address)
          .WithOne()
          .HasForeignKey<AMAddress>(a => a.Id);

        mb.Entity<AMOrder>()
          .HasOne(o => o.Customer)
          .WithMany(c => c.Orders)
          .HasForeignKey(o => o.CustomerId);

        mb.Entity<AMOrder>()
          .HasMany(o => o.Items)
          .WithOne(i => i.Order)
          .HasForeignKey(i => i.OrderId);
    }
}
