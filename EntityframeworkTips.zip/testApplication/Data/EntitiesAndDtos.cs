namespace ComparatorWeb.Data;

public class AMOrder
{
    public int Id { get; set; }
    public DateTime OrderedAt { get; set; }
    public int CustomerId { get; set; }
    public AMCustomer Customer { get; set; } = null!;
    public List<AMOrderItem> Items { get; set; } = new();
}

public class AMCustomer
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public AMAddress Address { get; set; } = null!;
    public List<AMOrder> Orders { get; set; } = new();
}

public class AMAddress
{
    public int Id { get; set; }
    public string City { get; set; } = "";
    public string Line1 { get; set; } = "";
}

public class AMOrderItem
{
    public int Id { get; set; }
    public string Sku { get; set; } = "";
    public decimal Price { get; set; }
    public int OrderId { get; set; }
    public AMOrder Order { get; set; } = null!;
}

// DTOs
public class Order
{
    public int Id { get; set; }
    public DateTime OrderedAt { get; set; }
    public Customer Customer { get; set; } = null!;
    public List<OrderItem> Items { get; set; } = new();
}

public class Customer
{
    public string Name { get; set; } = "";
    public Address Address { get; set; } = null!;
}

public class Address
{
    public string City { get; set; } = "";
    public string Line1 { get; set; } = "";
}

public class OrderItem
{
    public string Sku { get; set; } = "";
    public decimal Price { get; set; }
}
