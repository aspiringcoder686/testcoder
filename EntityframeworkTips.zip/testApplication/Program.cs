using ComparatorWeb.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Allow CORS for Vite dev server (optional for dev)
builder.Services.AddCors(options =>
{
    options.AddPolicy("DevCors", p =>
        p.WithOrigins("http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:5174")
         .AllowAnyHeader()
         .AllowAnyMethod());
});

builder.Services.AddControllers().AddJsonOptions(o =>
{
    o.JsonSerializerOptions.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter());
});


builder.Services.AddDbContext<AppDb>(opt => opt.UseInMemoryDatabase("demo"));

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("DevCors"); // safe for dev; remove if not needed

// Serve React build from wwwroot (Vite build outputs here)
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();

// Fallback to index.html for SPA routes
app.MapFallbackToFile("index.html");

app.Run();
