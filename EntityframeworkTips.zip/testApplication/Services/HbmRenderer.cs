﻿using System.Text;
using System.Xml.Linq;

namespace ComparatorWeb.Services;

public static class Renderer
{
    private static readonly string ResourceFolder = Path.Combine(AppContext.BaseDirectory, "Resources");

    public static string HBMRender(string domain)
    {
        
      
        // Assume filenames are like "Order.hbm.xml" or "{EntityName}.hbm.xml"
        var fileName = $"{domain}.hbm.xml";
        var fullPath = Path.Combine(ResourceFolder,"Mapping", fileName);

        if (!File.Exists(fullPath))
            return $"<!-- mapping file not found: {fullPath} -->";

        try
        {
            // Load and pretty-print the XML
            var doc = XDocument.Load(fullPath, LoadOptions.PreserveWhitespace);
            return doc.ToString(SaveOptions.DisableFormatting); // or SaveOptions.None for formatted
        }
        catch (Exception ex)
        {
            return $"<!-- error loading {fileName}: {ex.Message} -->";
        }
    }


    public static string TemplateQueries()
    {
        string filePath = Path.Combine(ResourceFolder, "TemplateQueries.txt");
        return System.IO.File.ReadAllText(filePath);
    }
    public static string Render(string domain)
    {


        // Assume filenames are like "Order.hbm.xml" or "{EntityName}.hbm.xml"
        var fileName = $"{domain}.hbm.xml";
        var fullPath = Path.Combine(ResourceFolder, fileName);

        if (!File.Exists(fullPath))
            return $"<!-- mapping file not found: {fullPath} -->";

        try
        {
            // Load and pretty-print the XML
            var doc = XDocument.Load(fullPath, LoadOptions.PreserveWhitespace);
            return doc.ToString(SaveOptions.DisableFormatting); // or SaveOptions.None for formatted
        }
        catch (Exception ex)
        {
            return $"<!-- error loading {fileName}: {ex.Message} -->";
        }
    }



    private static string Xml(string? s) =>
        (s ?? string.Empty).Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
}
