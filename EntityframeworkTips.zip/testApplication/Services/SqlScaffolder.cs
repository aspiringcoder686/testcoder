﻿using System.Text;

namespace ComparatorWeb.Services;

public static class SqlScaffolder
{
    public static string GenerateSingleScript()
    {
        // Matches the model you’re using (shared PK for Address, composite PK for OrderItems)
        var sb = new StringBuilder();
        sb.AppendLine("/* Single script: Customers, Addresses, Orders, OrderItems (composite PK) */");
        sb.AppendLine("SET NOCOUNT ON;");
        sb.AppendLine("SET XACT_ABORT ON;");
        sb.AppendLine("BEGIN TRY");
        sb.AppendLine("    BEGIN TRAN;");
        sb.AppendLine("    IF OBJECT_ID('dbo.OrderItems','U') IS NOT NULL DROP TABLE dbo.OrderItems;");
        sb.AppendLine("    IF OBJECT_ID('dbo.Orders','U')     IS NOT NULL DROP TABLE dbo.Orders;");
        sb.AppendLine("    IF OBJECT_ID('dbo.Addresses','U')  IS NOT NULL DROP TABLE dbo.Addresses;");
        sb.AppendLine("    IF OBJECT_ID('dbo.Customers','U')  IS NOT NULL DROP TABLE dbo.Customers;");
        sb.AppendLine();
        sb.AppendLine("    CREATE TABLE dbo.Customers (");
        sb.AppendLine("        Id   INT IDENTITY(1,1) NOT NULL,");
        sb.AppendLine("        Name NVARCHAR(200)     NOT NULL,");
        sb.AppendLine("        CONSTRAINT PK_Customers PRIMARY KEY CLUSTERED (Id)");
        sb.AppendLine("    );");
        sb.AppendLine();
        sb.AppendLine("    CREATE TABLE dbo.Addresses (");
        sb.AppendLine("        Id    INT            NOT NULL,");
        sb.AppendLine("        City  NVARCHAR(100)  NOT NULL,");
        sb.AppendLine("        Line1 NVARCHAR(200)  NOT NULL,");
        sb.AppendLine("        CONSTRAINT PK_Addresses PRIMARY KEY CLUSTERED (Id),");
        sb.AppendLine("        CONSTRAINT FK_Addresses_Customers_Id FOREIGN KEY (Id) REFERENCES dbo.Customers(Id) ON DELETE CASCADE ON UPDATE NO ACTION");
        sb.AppendLine("    );");
        sb.AppendLine();
        sb.AppendLine("    CREATE TABLE dbo.Orders (");
        sb.AppendLine("        Id         INT           IDENTITY(1,1) NOT NULL,");
        sb.AppendLine("        OrderedAt  DATETIME2(7)  NOT NULL,");
        sb.AppendLine("        CustomerId INT           NOT NULL,");
        sb.AppendLine("        CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED (Id),");
        sb.AppendLine("        CONSTRAINT FK_Orders_Customers_CustomerId FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(Id) ON DELETE NO ACTION ON UPDATE NO ACTION");
        sb.AppendLine("    );");
        sb.AppendLine("    CREATE NONCLUSTERED INDEX IX_Orders_CustomerId ON dbo.Orders(CustomerId);");
        sb.AppendLine();
        sb.AppendLine("    CREATE TABLE dbo.OrderItems (");
        sb.AppendLine("        OrderId INT           NOT NULL,");
        sb.AppendLine("        Sku     NVARCHAR(64)  NOT NULL,");
        sb.AppendLine("        Price   DECIMAL(18,2) NOT NULL,");
        sb.AppendLine("        CONSTRAINT PK_OrderItems PRIMARY KEY CLUSTERED (OrderId, Sku),");
        sb.AppendLine("        CONSTRAINT FK_OrderItems_Orders_OrderId FOREIGN KEY (OrderId) REFERENCES dbo.Orders(Id) ON DELETE CASCADE ON UPDATE NO ACTION");
        sb.AppendLine("    );");
        sb.AppendLine("    CREATE NONCLUSTERED INDEX IX_OrderItems_Sku ON dbo.OrderItems(Sku);");
        sb.AppendLine();
        sb.AppendLine("    COMMIT TRAN;");
        sb.AppendLine("END TRY");
        sb.AppendLine("BEGIN CATCH");
        sb.AppendLine("    IF @@TRANCOUNT > 0 ROLLBACK TRAN;");
        sb.AppendLine("    DECLARE @err nvarchar(4000) = ERROR_MESSAGE();");
        sb.AppendLine("    RAISERROR('Table creation failed: %s', 16, 1, @err);");
        sb.AppendLine("END CATCH;");
        return sb.ToString();
    }
}
