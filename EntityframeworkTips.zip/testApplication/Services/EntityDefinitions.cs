using System.Text;

namespace ComparatorWeb.Services;

public class EntityDefinition
{
    public string Name { get; set; } = "";

    public string EntityName { get; set; } = "";

    public string hbmfILES { get; set; } = "";
    public string Table { get; set; } = "";
    public string Namespace { get; set; } = "";
    public string IdColumn { get; set; } = "";
    public List<PropertyDefinition> Properties { get; set; } = new();
    public List<CompositeKeyDefinition> CompositeKey { get; set; } = new();
    public List<ComponentDefinition> Components { get; set; } = new();
    public List<RelationshipDefinition> Relationships { get; set; } = new();
    public List<QueryDefinition> Queries { get; set; } = new();
}

public class PropertyDefinition
{
    public string Name { get; set; } = "";
    public string Column { get; set; } = "";
    public string Type { get; set; } = "";
    public bool IsPrimary { get; set; }
}

public class RelationshipDefinition
{
    public string Name { get; set; } = "";
    public string Type { get; set; } = "";  // bag, many-to-one, etc.
    public string InnerType { get; set; } = "";
    public string Class { get; set; } = "";
    public string? SourceColumn { get; set; }
    public string? DestinationColumn { get; set; }
    public bool Lazy { get; set; }
    public string? Cascade { get; set; }
    public bool Inverse { get; set; }
    public string? PropertyRef { get; set; }
    public string? NotFound { get; set; }
}

public class QueryDefinition
{
    public string Name { get; set; } = "";
    public string Sql { get; set; } = "";
    public bool? Cacheable { get; set; }
    public string QueryType { get; set; } = "";
}

public class CompositeKeyDefinition
{
    public string Name { get; set; } = "";
    public string Column { get; set; } = "";
    public string Type { get; set; } = ""; // "string" or "many-to-one"
    public string Class { get; set; } = ""; // only for many-to-one
}

public class ComponentDefinition
{
    public string Name { get; set; } = "";
    public string Class { get; set; } = "";
    public List<PropertyDefinition> Properties { get; set; } = new();
    public List<RelationshipDefinition> Relationships { get; set; } = new();
    public string? Insert { get; set; }
    public string? Update { get; set; }
}

public static class EntityDefinitionLoader
{
    public static List<EntityDefinition> Load()
    {
        var list = new List<EntityDefinition>
    {
        new EntityDefinition
        {
            Name = "Order",
            EntityName = "AMOrder",
            Namespace = "ComparatorWeb.Data",
            Table = "Orders",
            IdColumn = "Id",
            Properties = new List<PropertyDefinition>
            {
                new PropertyDefinition { Name = "Id", Column = "Id", Type = "int", IsPrimary = true },
                new PropertyDefinition { Name = "OrderedAt", Column = "OrderedAt", Type = "DateTime" }
            },
            Relationships = new List<RelationshipDefinition>
            {
                new RelationshipDefinition { Name = "Customer", Type = "many-to-one", Class = "Customer", SourceColumn="CustomerId", DestinationColumn="Id" },
                new RelationshipDefinition { Name = "Items", Type = "bag", Class = "OrderItem", SourceColumn="Id", DestinationColumn="OrderId" }
            }
        },
        new EntityDefinition
        {
            Name = "Customer",
            EntityName = "AMCustomer",
            Namespace = "ComparatorWeb.Data",
            Table = "Customers",
            IdColumn = "Id",
            Properties = new List<PropertyDefinition>
            {
                new PropertyDefinition { Name = "Id", Column = "Id", Type = "int", IsPrimary = true },
                new PropertyDefinition { Name = "Name", Column = "Name", Type = "string" }
            },
            Relationships = new List<RelationshipDefinition>
            {
                new RelationshipDefinition { Name = "Orders", Type = "bag", Class = "Order", SourceColumn="Id", DestinationColumn="CustomerId" },
                new RelationshipDefinition { Name = "Address", Type = "many-to-one", Class = "Address", SourceColumn="AddressId", DestinationColumn="Id" }
            }
        },
        new EntityDefinition
        {
            Name = "Address",
            EntityName = "AMAddress",
            Namespace = "ComparatorWeb.Data",
            Table = "Addresses",
            IdColumn = "Id",
            Properties = new List<PropertyDefinition>
            {
                new PropertyDefinition { Name = "Id", Column = "Id", Type = "int", IsPrimary = true },
                new PropertyDefinition { Name = "City", Column = "City", Type = "string" },
                new PropertyDefinition { Name = "Line1", Column = "Line1", Type = "string" }
            }
        },
        new EntityDefinition
        {
            Name = "OrderItem",
            EntityName = "AMOrderItem",
            Namespace = "ComparatorWeb.Data",
            Table = "OrderItems",
            IdColumn = "Id",
            Properties = new List<PropertyDefinition>
            {
                new PropertyDefinition { Name = "Id", Column = "Id", Type = "int", IsPrimary = true },
                new PropertyDefinition { Name = "Sku", Column = "Sku", Type = "string" },
                new PropertyDefinition { Name = "Price", Column = "Price", Type = "decimal" }
            },
            Relationships = new List<RelationshipDefinition>
            {
                new RelationshipDefinition { Name = "Order", Type = "many-to-one", Class = "Order", SourceColumn="OrderId", DestinationColumn="Id" }
            }
        }
    };


        return list;
    }

}

public static class EntityTableMapper
{
    public static IReadOnlyDictionary<string, string> BuildTypeToTableMap(IEnumerable<EntityDefinition> defs)
    {
        var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var d in defs)
        {
            if (!string.IsNullOrWhiteSpace(d.Namespace) && !string.IsNullOrWhiteSpace(d.Name))
            {
                var full = $"{d.Namespace}.{d.Name}";
                if (!dict.ContainsKey(full) && !string.IsNullOrWhiteSpace(d.Table))
                    dict[full] = d.Table;
            }
            if (!string.IsNullOrWhiteSpace(d.Name) && !dict.ContainsKey(d.Name) && !string.IsNullOrWhiteSpace(d.Table))
            {
                dict[d.Name] = d.Table;
            }
        }
        return dict;
    }

    public static string? ResolveTable(string? entityTypeName, IReadOnlyDictionary<string, string>? map)
    {
        if (string.IsNullOrWhiteSpace(entityTypeName) || map == null) return null;
        if (map.TryGetValue(entityTypeName, out var table)) return table;

        var cleaned = entityTypeName;
        var tick = cleaned.IndexOf('<');
        if (tick >= 0) cleaned = cleaned.Substring(0, tick);
        if (map.TryGetValue(cleaned, out table)) return table;

        var lastDot = cleaned.LastIndexOf('.');
        if (lastDot >= 0)
        {
            var simple = cleaned[(lastDot + 1)..];
            if (map.TryGetValue(simple, out table)) return table;
        }

        return null;
    }
}

public static class EntityDashboardRenderer
{
    public static string Render(List<EntityDefinition> entities)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<h3>Entity Dashboard</h3>");
        sb.AppendLine("<ul>");
        foreach (var e in entities)
        {
            sb.AppendLine($"<li><b>{Html(e.Name)}</b> — Table: {Html(e.Table)} — Props: {e.Properties.Count} — Rels: {e.Relationships.Count}</li>");
        }
        sb.AppendLine("</ul>");
        return sb.ToString();
    }

    private static string Html(string? s)
    {
        if (string.IsNullOrEmpty(s)) return "";
        return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
    }
}
