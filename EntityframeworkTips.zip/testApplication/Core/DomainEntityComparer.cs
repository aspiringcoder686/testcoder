using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System.Reflection;

namespace ComparatorWeb.Core;

public static class DomainEntityComparer
{
    private static readonly HashSet<Type> Scalar = new()
    {
        typeof(string), typeof(bool), typeof(byte), typeof(sbyte),
        typeof(short), typeof(ushort), typeof(int), typeof(uint),
        typeof(long), typeof(ulong), typeof(float), typeof(double),
        typeof(decimal), typeof(DateTime), typeof(DateOnly), typeof(TimeOnly),
        typeof(Guid)
    };

    // Compare by Type objects
    public static List<CompareRow> Compare(
        DbContext db,
        Type domainType,
        Type entityClrType,
        int maxDepth = 2,
        IDictionary<string, string>? nameMap = null,
        Func<PropertyInfo, bool>? domainPropFilter = null)
    {
        var entityType = db.Model.FindEntityType(entityClrType)
            ?? throw new InvalidOperationException($"Entity type {entityClrType.FullName} not found in EF model.");

        var rows = new List<CompareRow>();
        WalkDomain(db, domainType, entityType, "", "", 1, maxDepth, nameMap, domainPropFilter, rows);
        return rows;
    }

    // Compare by names + assemblies
    public static List<CompareRow> Compare(
        DbContext db,
        string domainTypeName,
        string entityTypeName,
        IEnumerable<Assembly> searchAssemblies,
        int maxDepth = 2,
        IDictionary<string, string>? nameMap = null,
        Func<PropertyInfo, bool>? domainPropFilter = null)
    {
        var domainType = ResolveTypeOrThrow(domainTypeName, searchAssemblies);
        var entityClrType = ResolveTypeOrThrow(entityTypeName, searchAssemblies);
        return Compare(db, domainType, entityClrType, maxDepth, nameMap, domainPropFilter);
    }

    private static void WalkDomain(
        DbContext db,
        Type domType,
        IEntityType currentEntity,
        string domPrefix,
        string entPrefix,
        int depth,
        int maxDepth,
        IDictionary<string, string>? nameMap,
        Func<PropertyInfo, bool>? domainPropFilter,
        List<CompareRow> rows)
    {
        if (depth > maxDepth) return;

        var navsByName = currentEntity.GetNavigations()
            .GroupBy(n => n.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

        var propsByName = currentEntity.GetProperties()
            .GroupBy(p => p.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

        foreach (var dp in domType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            if (domainPropFilter != null && !domainPropFilter(dp)) continue;

            var domName = dp.Name;
            var mappedName = nameMap != null && nameMap.TryGetValue(domName, out var nn) ? nn : domName;

            var dType = Nullable.GetUnderlyingType(dp.PropertyType) ?? dp.PropertyType;
            var dIsScalar = IsScalarType(dType);
            var dIsCollection = IsEnumerableButNotString(dType);
            var dElemType = dIsCollection ? GetEnumerableElementType(dType) : null;

            var domainPath = Join(domPrefix, domName);
            var entityPathCandidate = Join(entPrefix, mappedName);

            if (navsByName.TryGetValue(mappedName, out var nav))
            {
                rows.Add(new CompareRow
                {
                    DomainPath = domainPath,
                    DomainType = TypeName(dType),
                    EntityPath = entityPathCandidate,
                    EntityType = nav.TargetEntityType.ClrType.Name,
                    Match = MatchKind.Navigation,
                    IncludeSuggestion = entityPathCandidate,
                    Notes = dIsCollection ? "Collection navigation" : "Navigation"
                });

                var nextDomType = dIsCollection ? (dElemType ?? dType) : dType;
                if (!IsScalarType(nextDomType))
                {
                    WalkDomain(db, nextDomType, nav.TargetEntityType, domainPath, entityPathCandidate,
                        depth + 1, maxDepth, nameMap, domainPropFilter, rows);
                }
                continue;
            }

            if (propsByName.TryGetValue(mappedName, out var ep))
            {
                rows.Add(new CompareRow
                {
                    DomainPath = domainPath,
                    DomainType = TypeName(dType),
                    EntityPath = entityPathCandidate,
                    EntityType = TypeName(ep.ClrType),
                    Match = MatchKind.Property,
                    IncludeSuggestion = null,
                    Notes = "Scalar property; no Include needed"
                });
                continue;
            }

            rows.Add(new CompareRow
            {
                DomainPath = domainPath,
                DomainType = TypeName(dType),
                EntityPath = entityPathCandidate,
                EntityType = "",
                Match = MatchKind.Missing,
                IncludeSuggestion = null,
                Notes = "No matching navigation or property on entity"
            });

            if (!dIsScalar && !dIsCollection)
            {
                WalkDomain(db, dType, currentEntity, domainPath, entityPathCandidate,
                    depth + 1, maxDepth, nameMap, domainPropFilter, rows);
            }
        }
    }

    private static bool IsScalarType(Type t)
    {
        t = Nullable.GetUnderlyingType(t) ?? t;
        return t.IsEnum || Scalar.Contains(t);
    }

    private static bool IsEnumerableButNotString(Type t)
    {
        if (t == typeof(string)) return false;
        return typeof(System.Collections.IEnumerable).IsAssignableFrom(t);
    }

    private static string TypeName(Type t)
    {
        t = Nullable.GetUnderlyingType(t) ?? t;
        if (t.IsGenericType)
        {
            var name = t.Name.Contains('`') ? t.Name[..t.Name.IndexOf('`')] : t.Name;
            var args = string.Join(",", t.GetGenericArguments().Select(TypeName));
            return $"{name}<{args}>";
        }
        return t.Name;
    }

    private static Type? GetEnumerableElementType(Type t)
    {
        if (t.IsArray) return t.GetElementType();
        var ienum = t.GetInterfaces().Append(t)
            .FirstOrDefault(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IEnumerable<>));
        return ienum?.GetGenericArguments()[0];
    }

    private static string Join(string prefix, string segment)
        => string.IsNullOrEmpty(prefix) ? segment : $"{prefix}.{segment}";

    private static Type ResolveTypeOrThrow(string typeName, IEnumerable<Assembly> searchAssemblies)
    {
        var t = Type.GetType(typeName, throwOnError: false);
        if (t != null) return t;

        foreach (var asm in searchAssemblies)
        {
            t = asm.GetType(typeName, throwOnError: false);
            if (t != null) return t;

            t = asm.GetTypes().FirstOrDefault(x =>
                string.Equals(x.FullName, typeName, StringComparison.Ordinal) ||
                string.Equals(x.Name, typeName, StringComparison.Ordinal));
            if (t != null) return t;
        }

        throw new InvalidOperationException($"Could not resolve type '{typeName}'. Provide fully-qualified name or add its assembly to searchAssemblies.");
    }
}
