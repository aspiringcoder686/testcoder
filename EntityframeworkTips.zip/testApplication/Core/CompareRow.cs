namespace ComparatorWeb.Core;

public enum MatchKind { Navigation, Property, Missing }

public sealed class CompareRow
{
    public string DomainPath { get; init; } = "";
    public string DomainType { get; init; } = "";
    public string EntityPath { get; init; } = "";
    public string EntityType { get; init; } = "";
    public MatchKind Match { get; init; }
    public string? IncludeSuggestion { get; init; }
    public string Notes { get; init; } = "";
}
