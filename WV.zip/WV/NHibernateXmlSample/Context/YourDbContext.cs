﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using NHibernateXmlSample.Models;

namespace NHibernateXmlSample.Context;

public partial class YourDbContext : DbContext
{
    public YourDbContext()
    {
    }

    public YourDbContext(DbContextOptions<YourDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Attachment> Attachments { get; set; }

    public virtual DbSet<Call> Calls { get; set; }

    public virtual DbSet<CallAction> CallActions { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Department1> Departments1 { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Employee1> Employees1 { get; set; }

    public virtual DbSet<Logtable> Logtables { get; set; }

    public virtual DbSet<MaintenanceGroup> MaintenanceGroups { get; set; }

    public virtual DbSet<MaintenanceGroupMap> MaintenanceGroupMaps { get; set; }

    public virtual DbSet<MaintenanceGroupType> MaintenanceGroupTypes { get; set; }

    public virtual DbSet<Site> Sites { get; set; }

    public virtual DbSet<Status> Statuses { get; set; }

    public virtual DbSet<Supplier> Suppliers { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<VwAspuser> VwAspusers { get; set; }

    public virtual DbSet<VwCallDetail> VwCallDetails { get; set; }

    public virtual DbSet<VwRegion> VwRegions { get; set; }

    public virtual DbSet<VwRegionSite> VwRegionSites { get; set; }

    public virtual DbSet<VwSite> VwSites { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=localhost\\SQLEXPRESS;Initial Catalog=testme;Integrated Security=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Attachment>(entity =>
        {
            entity.HasKey(e => e.AttachmentId).HasName("PK_Attachments_AttachmentId");

            entity.Property(e => e.FileDescription)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.FileName)
                .HasMaxLength(255)
                .IsUnicode(false);

            entity.HasOne(d => d.Call).WithMany(p => p.Attachments)
                .HasForeignKey(d => d.CallId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Attachments_CallId_Calls_CallId");
        });

        modelBuilder.Entity<Call>(entity =>
        {
            entity.HasKey(e => e.CallId).HasName("PK_Calls_CallId");

            entity.Property(e => e.CallNumber)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.CcuserId).HasColumnName("CCUserId");
            entity.Property(e => e.Cost).HasColumnType("money");
            entity.Property(e => e.DateTimeOfCall)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ProblemDescription)
                .HasMaxLength(2000)
                .IsUnicode(false);
            entity.Property(e => e.SiteCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Solution)
                .HasMaxLength(1796)
                .IsUnicode(false);
            entity.Property(e => e.StatusDateTime)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasDefaultValue(1);
            entity.Property(e => e.StatusUserId).HasColumnName("StatusUserID");

            entity.HasOne(d => d.AssignedToUser).WithMany(p => p.CallAssignedToUsers)
                .HasForeignKey(d => d.AssignedToUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_AssignedToUserId_Users_UserId");

            entity.HasOne(d => d.Category).WithMany(p => p.Calls)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_CategoryId_Categories_CategoryId");

            entity.HasOne(d => d.Ccuser).WithMany(p => p.CallCcusers)
                .HasForeignKey(d => d.CcuserId)
                .HasConstraintName("FK_Calls_CCUserId_Users_UserId");

            entity.HasOne(d => d.LoggedByUser).WithMany(p => p.CallLoggedByUsers)
                .HasForeignKey(d => d.LoggedByUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_LoggedByUserId_Users_UserId");

            entity.HasOne(d => d.MaintenanceGroup).WithMany(p => p.Calls)
                .HasForeignKey(d => d.MaintenanceGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_MaintenanceGroupId_MaintenanceGroups_MaintenanceGroupId");

            entity.HasOne(d => d.MaintenanceGroupType).WithMany(p => p.Calls)
                .HasForeignKey(d => d.MaintenanceGroupTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_MaintenanceGroupTypeId_MaintenanceGroupTypes_MaintenanceGroupTypeId");

            entity.HasOne(d => d.Status).WithMany(p => p.Calls)
                .HasForeignKey(d => d.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_StatusId_Status_StatusId");

            entity.HasOne(d => d.StatusUser).WithMany(p => p.CallStatusUsers)
                .HasForeignKey(d => d.StatusUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_StatusUserId_Users_UserId");

            entity.HasOne(d => d.Supplier).WithMany(p => p.Calls)
                .HasForeignKey(d => d.SupplierId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Calls_SupplierId_Suppliers_SupplierId");
        });

        modelBuilder.Entity<CallAction>(entity =>
        {
            entity.HasKey(e => e.CallActionId).HasName("PK_CallActions_CallActionId");

            entity.Property(e => e.ActionDescription)
                .HasMaxLength(4000)
                .IsUnicode(false);
            entity.Property(e => e.DateTimeOfAction)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Call).WithMany(p => p.CallActions)
                .HasForeignKey(d => d.CallId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CallActions_CallId_Calls_CallId");

            entity.HasOne(d => d.User).WithMany(p => p.CallActions)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CallActions_UserId_Users_UserId");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.CategoryId).HasName("PK_Categories_CategoryId");

            entity.HasIndex(e => new { e.MaintenanceGroupTypeId, e.CategoryName }, "UK_Categories_CategoryName").IsUnique();

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.CategoryName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.InsertDateTime).HasColumnType("datetime");
            entity.Property(e => e.UpdateDateTime).HasColumnType("datetime");

            entity.HasOne(d => d.MaintenanceGroupType).WithMany(p => p.Categories)
                .HasForeignKey(d => d.MaintenanceGroupTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Categories_MaintenanceGroupTypes");
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Departme__3214EC0746B55129");

            entity.ToTable("Department");

            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<Department1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Departme__3214EC07E9FC1DFE");

            entity.ToTable("Departments");

            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Employee__3214EC07371BCF21");

            entity.ToTable("Employee");

            entity.Property(e => e.Name).HasMaxLength(100);

            entity.HasOne(d => d.Department).WithMany(p => p.Employees)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK__Employee__Depart__28ED12D1");
        });

        modelBuilder.Entity<Employee1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Employee__3214EC074CBD0C6D");

            entity.ToTable("Employees");

            entity.Property(e => e.Name).HasMaxLength(100);

            entity.HasOne(d => d.Department).WithMany(p => p.Employee1s)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK__Employees__Depar__2CBDA3B5");
        });

        modelBuilder.Entity<Logtable>(entity =>
        {
            entity.ToTable("logtable");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Insertdatetime)
                .HasColumnType("datetime")
                .HasColumnName("insertdatetime");
            entity.Property(e => e.Message).HasColumnName("message");
            entity.Property(e => e.Parametervalue1).HasColumnName("parametervalue1");
            entity.Property(e => e.Parametervalue2).HasColumnName("parametervalue2");
            entity.Property(e => e.Parametervalue3).HasColumnName("parametervalue3");
            entity.Property(e => e.Parametervalue4)
                .HasColumnType("datetime")
                .HasColumnName("parametervalue4");
            entity.Property(e => e.Parametervalue5)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("parametervalue5");
            entity.Property(e => e.Parametervalue6).HasColumnName("parametervalue6");
            entity.Property(e => e.Parametervalue7).HasColumnName("parametervalue7");
            entity.Property(e => e.Procedurename)
                .HasMaxLength(200)
                .HasColumnName("procedurename");
        });

        modelBuilder.Entity<MaintenanceGroup>(entity =>
        {
            entity.HasKey(e => e.MaintenanceGroupId).HasName("PK_MaintenanceGroups_MaintenanceGroupId");

            entity.HasIndex(e => e.MaintenanceGroupName, "UK_MaintenanceGroups_MaintenanceGroupName").IsUnique();

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.InsertDateTime).HasColumnType("datetime");
            entity.Property(e => e.MaintenanceGroupName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.UpdateDateTime).HasColumnType("datetime");
        });

        modelBuilder.Entity<MaintenanceGroupMap>(entity =>
        {
            entity.HasKey(e => e.MapId);

            entity.ToTable("MaintenanceGroupMap");

            entity.HasIndex(e => new { e.SiteCode, e.MaintenanceGroupId, e.MaintenanceGroupTypeId }, "UK_MaintenanceGroupMap").IsUnique();

            entity.Property(e => e.CcuserId).HasColumnName("CCUserId");
            entity.Property(e => e.SiteCode)
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.HasOne(d => d.Ccuser).WithMany(p => p.MaintenanceGroupMapCcusers)
                .HasForeignKey(d => d.CcuserId)
                .HasConstraintName("FK_MaintenanceGroupMap_CCUsers");

            entity.HasOne(d => d.MaintenanceGroup).WithMany(p => p.MaintenanceGroupMaps)
                .HasForeignKey(d => d.MaintenanceGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MaintenanceGroupMap_MaintenanceGroups");

            entity.HasOne(d => d.MaintenanceGroupType).WithMany(p => p.MaintenanceGroupMaps)
                .HasForeignKey(d => d.MaintenanceGroupTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MaintenanceGroupMap_MaintenanceGroupTypes");

            entity.HasOne(d => d.Supplier).WithMany(p => p.MaintenanceGroupMaps)
                .HasForeignKey(d => d.SupplierId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MaintenanceGroupMap_Suppliers");

            entity.HasOne(d => d.User).WithMany(p => p.MaintenanceGroupMapUsers)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MaintenanceGroupMap_Users");
        });

        modelBuilder.Entity<MaintenanceGroupType>(entity =>
        {
            entity.HasKey(e => e.MaintenanceGroupTypeId).HasName("PK_MaintenanceGroupTypes_MaintenanceGroupTypeId");

            entity.HasIndex(e => new { e.MaintenanceGroupId, e.MaintenanceGroupTypeName }, "UK_MaintenanceGroupTypes_MaintenanceGroupTypeName").IsUnique();

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.InsertDateTime).HasColumnType("datetime");
            entity.Property(e => e.MaintenanceGroupTypeName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.UpdateDateTime).HasColumnType("datetime");

            entity.HasOne(d => d.MaintenanceGroup).WithMany(p => p.MaintenanceGroupTypes)
                .HasForeignKey(d => d.MaintenanceGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MaintenanceGroupTypes_MaintenanceGroups");
        });

        modelBuilder.Entity<Site>(entity =>
        {
            entity.HasKey(e => e.SiteId)
                .HasName("PK_Sites_SiteId")
                .HasFillFactor(90);

            entity.Property(e => e.Ntuser)
                .HasMaxLength(128)
                .IsUnicode(false)
                .HasColumnName("NTUser");
            entity.Property(e => e.Region)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.RegionCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.SiteCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.SiteInactive).HasDefaultValue(true);
            entity.Property(e => e.SiteName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
        });

        modelBuilder.Entity<Status>(entity =>
        {
            entity.HasKey(e => e.StatusId).HasName("PK_Status_StatusId");

            entity.ToTable("Status");

            entity.Property(e => e.StatusId)
                .ValueGeneratedNever()
                .HasColumnName("StatusID");
            entity.Property(e => e.CssClass)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Supplier>(entity =>
        {
            entity.HasKey(e => e.SupplierId).HasName("PK_Suppliers_SupplierId");

            entity.HasIndex(e => e.SupplierName, "UK_Suppliers_SupplierName").IsUnique();

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.ContactEmail)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.InsertDateTime).HasColumnType("datetime");
            entity.Property(e => e.SupplierName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdateDateTime).HasColumnType("datetime");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK_Users_UserId");

            entity.HasIndex(e => e.Ntlogin, "UK_Users_NTLogin").IsUnique();

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.Email)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Ntlogin)
                .HasMaxLength(128)
                .IsUnicode(false)
                .HasColumnName("NTLogin");
            entity.Property(e => e.Surname)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwAspuser>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwASPUsers");

            entity.Property(e => e.Ntlogin)
                .HasMaxLength(256)
                .HasColumnName("NTLOGIN");
            entity.Property(e => e.RoleName).HasMaxLength(256);
        });

        modelBuilder.Entity<VwCallDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCallDetail");

            entity.Property(e => e.AssignedToUserName)
                .HasMaxLength(101)
                .IsUnicode(false);
            entity.Property(e => e.AssignedUserEmail)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CallNumber)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.CategoryName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CcuserEmail)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("CCUserEmail");
            entity.Property(e => e.CcuserName)
                .HasMaxLength(101)
                .IsUnicode(false)
                .HasColumnName("CCUserName");
            entity.Property(e => e.Cost).HasColumnType("money");
            entity.Property(e => e.DateTimeOfCall).HasColumnType("datetime");
            entity.Property(e => e.DepartmentName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.LoggedByUserId).HasColumnName("LoggedByUserID");
            entity.Property(e => e.LoggedByUserName)
                .HasMaxLength(101)
                .IsUnicode(false);
            entity.Property(e => e.LoggedByUserNtlogin)
                .HasMaxLength(128)
                .IsUnicode(false)
                .HasColumnName("LoggedByUserNTLogin");
            entity.Property(e => e.MaintenanceGroupName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.MaintenanceGroupTypeName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.ProblemDescription)
                .HasMaxLength(2000)
                .IsUnicode(false);
            entity.Property(e => e.RegionCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.RegionDescription)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.SiteCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.SiteName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Solution)
                .HasMaxLength(1796)
                .IsUnicode(false);
            entity.Property(e => e.StatusCssClass)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusDateTime).HasColumnType("datetime");
            entity.Property(e => e.StatusDescription)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.StatusUserName)
                .HasMaxLength(101)
                .IsUnicode(false);
            entity.Property(e => e.SupplierName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwRegion>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwRegions");

            entity.Property(e => e.RegionCode).HasMaxLength(50);
            entity.Property(e => e.RegionDescription).HasMaxLength(200);
        });

        modelBuilder.Entity<VwRegionSite>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwRegionSite");

            entity.Property(e => e.RegionCode)
                .HasMaxLength(3)
                .IsUnicode(false);
            entity.Property(e => e.RegionDescription)
                .HasMaxLength(16)
                .IsUnicode(false);
            entity.Property(e => e.SiteCode)
                .HasMaxLength(7)
                .IsUnicode(false);
            entity.Property(e => e.SiteDescription)
                .HasMaxLength(14)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwSite>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwSites");

            entity.Property(e => e.RegionCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.RegionDescription)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.SiteCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.SiteDescription)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
