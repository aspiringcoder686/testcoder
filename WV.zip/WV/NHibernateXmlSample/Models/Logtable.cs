﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class Logtable
{
    public int Id { get; set; }

    public string? Procedurename { get; set; }

    public string? Parametervalue1 { get; set; }

    public string? Parametervalue2 { get; set; }

    public bool? Parametervalue3 { get; set; }

    public DateTime? Parametervalue4 { get; set; }

    public decimal? Parametervalue5 { get; set; }

    public int? Parametervalue6 { get; set; }

    public int? Parametervalue7 { get; set; }

    public DateTime? Insertdatetime { get; set; }

    public string? Message { get; set; }
}
