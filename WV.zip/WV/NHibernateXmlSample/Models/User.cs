﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class User
{
    public int UserId { get; set; }

    public string FirstName { get; set; } = null!;

    public string Surname { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Ntlogin { get; set; } = null!;

    public bool Active { get; set; }

    public virtual ICollection<CallAction> CallActions { get; set; } = new List<CallAction>();

    public virtual ICollection<Call> CallAssignedToUsers { get; set; } = new List<Call>();

    public virtual ICollection<Call> CallCcusers { get; set; } = new List<Call>();

    public virtual ICollection<Call> CallLoggedByUsers { get; set; } = new List<Call>();

    public virtual ICollection<Call> CallStatusUsers { get; set; } = new List<Call>();

    public virtual ICollection<MaintenanceGroupMap> MaintenanceGroupMapCcusers { get; set; } = new List<MaintenanceGroupMap>();

    public virtual ICollection<MaintenanceGroupMap> MaintenanceGroupMapUsers { get; set; } = new List<MaintenanceGroupMap>();
}
