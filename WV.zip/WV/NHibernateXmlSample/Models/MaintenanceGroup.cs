﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class MaintenanceGroup
{
    public int MaintenanceGroupId { get; set; }

    public string MaintenanceGroupName { get; set; } = null!;

    public bool Active { get; set; }

    public int? InsertedBy { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? InsertDateTime { get; set; }

    public DateTime? UpdateDateTime { get; set; }

    public virtual ICollection<Call> Calls { get; set; } = new List<Call>();

    public virtual ICollection<MaintenanceGroupMap> MaintenanceGroupMaps { get; set; } = new List<MaintenanceGroupMap>();

    public virtual ICollection<MaintenanceGroupType> MaintenanceGroupTypes { get; set; } = new List<MaintenanceGroupType>();
}
