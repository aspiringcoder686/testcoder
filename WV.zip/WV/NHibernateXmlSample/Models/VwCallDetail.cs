﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class VwCallDetail
{
    public int CallId { get; set; }

    public string CallNumber { get; set; } = null!;

    public int AssignedToUserId { get; set; }

    public string AssignedToUserName { get; set; } = null!;

    public string AssignedUserEmail { get; set; } = null!;

    public string? RegionCode { get; set; }

    public string RegionDescription { get; set; } = null!;

    public string SiteCode { get; set; } = null!;

    public string SiteName { get; set; } = null!;

    public int SupplierId { get; set; }

    public string SupplierName { get; set; } = null!;

    public int MaintenanceGroupId { get; set; }

    public string MaintenanceGroupName { get; set; } = null!;

    public string MaintenanceGroupTypeName { get; set; } = null!;

    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;

    public string ProblemDescription { get; set; } = null!;

    public DateTime DateTimeOfCall { get; set; }

    public int? LoggedByUserId { get; set; }

    public string? LoggedByUserNtlogin { get; set; }

    public string? LoggedByUserName { get; set; }

    public int StatusId { get; set; }

    public string StatusDescription { get; set; } = null!;

    public string StatusCssClass { get; set; } = null!;

    public DateTime StatusDateTime { get; set; }

    public string StatusUserName { get; set; } = null!;

    public string? Solution { get; set; }

    public string CcuserName { get; set; } = null!;

    public string CcuserEmail { get; set; } = null!;

    public bool Closed { get; set; }

    public decimal? Cost { get; set; }

    public short? ResolveTimeHours { get; set; }

    public short? ResolveTimeMinutes { get; set; }

    public int? DepartmentId { get; set; }

    public string? DepartmentName { get; set; }
}
