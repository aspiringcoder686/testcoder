﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class VwSite
{
    public string? SiteCode { get; set; }

    public string SiteDescription { get; set; } = null!;

    public int SiteInactive { get; set; }

    public string? RegionCode { get; set; }

    public string RegionDescription { get; set; } = null!;

    public int RegionInactive { get; set; }
}
