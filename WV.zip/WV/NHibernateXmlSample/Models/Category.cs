﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class Category
{
    public int CategoryId { get; set; }

    public int MaintenanceGroupTypeId { get; set; }

    public string CategoryName { get; set; } = null!;

    public bool Active { get; set; }

    public int? InsertedBy { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? InsertDateTime { get; set; }

    public DateTime? UpdateDateTime { get; set; }

    public virtual ICollection<Call> Calls { get; set; } = new List<Call>();

    public virtual MaintenanceGroupType MaintenanceGroupType { get; set; } = null!;
}
