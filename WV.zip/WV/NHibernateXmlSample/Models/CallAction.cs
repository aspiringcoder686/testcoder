﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class CallAction
{
    public int CallActionId { get; set; }

    public int CallId { get; set; }

    public DateTime DateTimeOfAction { get; set; }

    public int UserId { get; set; }

    public string ActionDescription { get; set; } = null!;

    public bool IsInternal { get; set; }

    public virtual Call Call { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
