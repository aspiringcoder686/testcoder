﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class Attachment
{
    public int AttachmentId { get; set; }

    public int CallId { get; set; }

    public string FileDescription { get; set; } = null!;

    public string FileName { get; set; } = null!;

    public virtual Call Call { get; set; } = null!;
}
