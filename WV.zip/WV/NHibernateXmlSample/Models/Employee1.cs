﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class Employee1
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public int? DepartmentId { get; set; }

    public virtual Department1? Department { get; set; }
}
