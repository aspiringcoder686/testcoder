﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class MaintenanceGroupType
{
    public int MaintenanceGroupTypeId { get; set; }

    public int MaintenanceGroupId { get; set; }

    public string MaintenanceGroupTypeName { get; set; } = null!;

    public bool Active { get; set; }

    public int? InsertedBy { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? InsertDateTime { get; set; }

    public DateTime? UpdateDateTime { get; set; }

    public virtual ICollection<Call> Calls { get; set; } = new List<Call>();

    public virtual ICollection<Category> Categories { get; set; } = new List<Category>();

    public virtual MaintenanceGroup MaintenanceGroup { get; set; } = null!;

    public virtual ICollection<MaintenanceGroupMap> MaintenanceGroupMaps { get; set; } = new List<MaintenanceGroupMap>();
}
