﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class MaintenanceGroupMap
{
    public int MapId { get; set; }

    public string SiteCode { get; set; } = null!;

    public int MaintenanceGroupId { get; set; }

    public int MaintenanceGroupTypeId { get; set; }

    public int SupplierId { get; set; }

    public int UserId { get; set; }

    public int? CcuserId { get; set; }

    public virtual User? Ccuser { get; set; }

    public virtual MaintenanceGroup MaintenanceGroup { get; set; } = null!;

    public virtual MaintenanceGroupType MaintenanceGroupType { get; set; } = null!;

    public virtual Supplier Supplier { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
