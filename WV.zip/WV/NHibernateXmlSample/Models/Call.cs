﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class Call
{
    public int CallId { get; set; }

    public string CallNumber { get; set; } = null!;

    public int AssignedToUserId { get; set; }

    public string SiteCode { get; set; } = null!;

    public int SupplierId { get; set; }

    public int MaintenanceGroupId { get; set; }

    public int MaintenanceGroupTypeId { get; set; }

    public int CategoryId { get; set; }

    public string ProblemDescription { get; set; } = null!;

    public DateTime DateTimeOfCall { get; set; }

    public int LoggedByUserId { get; set; }

    public bool Closed { get; set; }

    public int StatusId { get; set; }

    public DateTime StatusDateTime { get; set; }

    public int StatusUserId { get; set; }

    public string? Solution { get; set; }

    public int? CcuserId { get; set; }

    public decimal? Cost { get; set; }

    public short? ResolveTimeHours { get; set; }

    public short? ResolveTimeMinutes { get; set; }

    public int? DepartmentId { get; set; }

    public virtual User AssignedToUser { get; set; } = null!;

    public virtual ICollection<Attachment> Attachments { get; set; } = new List<Attachment>();

    public virtual ICollection<CallAction> CallActions { get; set; } = new List<CallAction>();

    public virtual Category Category { get; set; } = null!;

    public virtual User? Ccuser { get; set; }

    public virtual User LoggedByUser { get; set; } = null!;

    public virtual MaintenanceGroup MaintenanceGroup { get; set; } = null!;

    public virtual MaintenanceGroupType MaintenanceGroupType { get; set; } = null!;

    public virtual Status Status { get; set; } = null!;

    public virtual User StatusUser { get; set; } = null!;

    public virtual Supplier Supplier { get; set; } = null!;
}
