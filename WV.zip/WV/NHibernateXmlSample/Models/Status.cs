﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class Status
{
    public int StatusId { get; set; }

    public string Description { get; set; } = null!;

    public string CssClass { get; set; } = null!;

    public virtual ICollection<Call> Calls { get; set; } = new List<Call>();
}
