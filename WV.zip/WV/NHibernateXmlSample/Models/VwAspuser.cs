﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class VwAspuser
{
    public string Ntlogin { get; set; } = null!;

    public string RoleName { get; set; } = null!;
}
