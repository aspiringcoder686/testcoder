﻿using System;
using System.Collections.Generic;

namespace NHibernateXmlSample.Models;

public partial class VwRegionSite
{
    public string RegionCode { get; set; } = null!;

    public string RegionDescription { get; set; } = null!;

    public int RegionInactive { get; set; }

    public string SiteCode { get; set; } = null!;

    public string SiteDescription { get; set; } = null!;

    public int SiteInactive { get; set; }
}
