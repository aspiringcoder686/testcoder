using NHibernateXmlSample;
using NHibernateXmlSample.Entities;

Console.WriteLine("Connecting to DB...");

using var session = NHibernateHelper.OpenSession();
using var tx = session.BeginTransaction();

var emp = new Employee
{
    Name = "Rajar",
    Department = "Architecture"
};

session.Save(emp);
tx.Commit();

Console.WriteLine($"Employee Saved. ID: {emp.Id}");
