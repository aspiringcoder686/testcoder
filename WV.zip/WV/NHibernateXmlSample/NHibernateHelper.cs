using NHibernate;
using NHibernate.Cfg;

namespace NHibernateXmlSample;

public static class NHibernateHelper
{
    private static ISessionFactory _sessionFactory;

    public static ISessionFactory SessionFactory
    {
        get
        {
            if (_sessionFactory == null)
            {
                var cfg = new Configuration();
                //cfg.Configure(); // Loads hibernate.cfg.xml
                cfg.Configure(typeof(Program).Assembly, "NHibernateXmlSample.hibernate.cfg.xml"); // ? looks for embedded resource

                _sessionFactory = cfg.BuildSessionFactory();
            }
            return _sessionFactory;
        }
    }

    public static ISession OpenSession() => SessionFactory.OpenSession();
}
