﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;


var config = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .Build();


