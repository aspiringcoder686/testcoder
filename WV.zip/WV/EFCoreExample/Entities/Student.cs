using System.ComponentModel.DataAnnotations;

namespace EfCoreRelationshipsDemo.Entities;

public class Student
{
    [Key]
    public int Id { get; set; }
    public string Name { get; set; } = "";

    public List<Course> Courses { get; set; } = new();
}
