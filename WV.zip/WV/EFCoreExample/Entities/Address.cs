using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EfCoreRelationshipsDemo.Entities;

public class Address
{
    [Key, ForeignKey("Employee")]
    public int Id { get; set; }
    public string City { get; set; } = "";
    public Employee Employee { get; set; }
}
