using System.ComponentModel.DataAnnotations;

namespace EfCoreRelationshipsDemo.Entities;

public class Course
{
    [Key]
    public int Id { get; set; }
    public string Title { get; set; } = "";

    public List<Student> Students { get; set; } = new();
}
