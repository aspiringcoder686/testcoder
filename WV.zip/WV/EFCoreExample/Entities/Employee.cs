using System.ComponentModel.DataAnnotations;

namespace EfCoreRelationshipsDemo.Entities;

public class Employee
{
    [Key]
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public Address Address { get; set; }

    public int DepartmentId { get; set; }
    public Department Department { get; set; }
}
