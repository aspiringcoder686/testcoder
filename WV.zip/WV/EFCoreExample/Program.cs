using EfCoreRelationshipsDemo;
using EfCoreRelationshipsDemo.Entities;
using Microsoft.EntityFrameworkCore;

using var context = new AppDbContext();
context.Database.OpenConnection();
context.Database.EnsureCreated();

// One-to-One
var employee = new Employee { Name = "Rajar", DepartmentId = 1 };
var address = new Address { City = "Chennai", Employee = employee };

// One-to-Many
var dept1 = new Department { Name = "IT", Employees = new List<Employee> { employee } };

// Many-to-Many
var student = new Student { Name = "Alice" };
var course = new Course { Title = "Maths", Students = new List<Student> { student } };

context.Departments.Add(dept1);
context.Employees.Add(employee);
context.Addresses.Add(address);
context.Students.Add(student);
context.Courses.Add(course);

context.SaveChanges();

// Output
Console.WriteLine("Data seeded:");

foreach (var emp in context.Employees.Include(e => e.Address).Include(e => e.Department))
{
    Console.WriteLine($"Employee: {emp.Name}, City: {emp.Address?.City}, Dept: {emp.Department?.Name}");
}

foreach (var stud in context.Students.Include(s => s.Courses))
{
    foreach (var crs in stud.Courses)
        Console.WriteLine($"Student: {stud.Name}, Enrolled in: {crs.Title}");
}

//Linq 

var employeeQuery =
    from emp2 in context.Employees
    select new
    {
        emp2.Name,
        City = emp2.Address != null ? emp2.Address.City : null,
        DeptName = emp2.Department != null ? emp2.Department.Name : null
    };

foreach (var e in employeeQuery)
{
    Console.WriteLine($"Employee: {e.Name}, City: {e.City}, Dept: {e.DeptName}");
}




/*
Lazy loading loads data on demand, not during initial query.
Avoid lazy loading in performance-critical or bulk scenarios (use .Include() instead).
Lazy loading does not work with DTOs or projections (select new { ... }), because proxies can't override anonymous types.
 */

//Mutable
var emp = context.Employees.AsNoTracking().FirstOrDefault();






Console.ReadLine();
