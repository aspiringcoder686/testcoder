using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace HibernateHbmHtmlExporter_v3
{
    /// <summary>
    /// Scans *.hbm.xml files, computes per-entity metrics & complexity,
    /// writes metrics.json, and emits a filterable dashboard index.html.
    /// Includes HQL and SQL query DETAILS per file/entity.
    /// </summary>
    public static class HbmMetricsDashboard
    {
        public static void Generate(string hbmRoot, string outRoot)
        {
            var files = Directory.EnumerateFiles(hbmRoot, "*.hbm.xml", SearchOption.AllDirectories).ToList();
            var entities = new List<EntityMetric>();
            var skipped = new List<string>();

            foreach (var file in files)
            {
                var doc = TryLoad(file);
                if (doc is null) { skipped.Add(Path.GetFileName(file)); continue; }
                var root = doc.Root;
                if (root is null) { skipped.Add(Path.GetFileName(file)); continue; }

                // File-level named queries
                var fileHql = root.Elements().Where(e => e.Name.LocalName == "query").ToList();
                var fileSql = root.Elements().Where(e => e.Name.LocalName == "sql-query").ToList();

                // Classes
                var classes = root.Descendants().Where(e =>
                    e.Name.LocalName == "class" ||
                    e.Name.LocalName == "subclass" ||
                    e.Name.LocalName == "joined-subclass" ||
                    e.Name.LocalName == "union-subclass");

                foreach (var cls in classes)
                {
                    var metric = BuildEntityMetric(file, cls, fileHql, fileSql);
                    if (metric != null) entities.Add(metric);
                }
            }



            // thresholds & bands
            var comps = entities.Select(e => e.Complexity).OrderBy(x => x).ToList();
            var th = ComputeThresholds(comps);
            foreach (var e in entities) e.Band = BandOf(e.Complexity, th);

            // summary
            var summary = new Summary
            {
                Entities = entities.Count,
                MinComplexity = entities.Count > 0 ? entities.Min(e => e.Complexity) : 0,
                MaxComplexity = entities.Count > 0 ? entities.Max(e => e.Complexity) : 0,
                AvgComplexity = entities.Count > 0 ? Math.Round(entities.Average(e => e.Complexity), 2) : 0,
                Thresholds = th,
                Bands = entities.GroupBy(e => e.Band).ToDictionary(g => g.Key, g => g.Count()),
                SkippedFiles = skipped
            };

            

            Directory.CreateDirectory(outRoot);
            var metrics = new MetricsRoot { Summary = summary, Entities = entities };
            var jsonPath = Path.Combine(outRoot, "metrics.json");
            var opts = new JsonSerializerOptions { WriteIndented = true, DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull, PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
            var jsonText = JsonSerializer.Serialize(metrics, opts);
            File.WriteAllText(jsonPath, jsonText, new UTF8Encoding(false));

            // Dashboard with inline fallback
            var htmlPath = Path.Combine(outRoot, "index.html");
            var html = DashboardHtml(jsonText).Replace("__INLINE__", jsonText.Replace("\\", "\\\\").Replace("</", "<\\/"));
            File.WriteAllText(htmlPath, html, new UTF8Encoding(false));
        }

        private static XDocument? TryLoad(string path)
        {
            try { return XDocument.Load(path, LoadOptions.PreserveWhitespace | LoadOptions.SetLineInfo); }
            catch { return null; }
        }

        private static string? Attr(XElement? e, string name) => e?.Attribute(name)?.Value;

        private static string InnerText(XElement e) => e?.Value.Trim() ?? "";

        private static EntityMetric? BuildEntityMetric(string file, XElement cls, List<XElement> fileHql, List<XElement> fileSql)
        {
            var counts = new MetricCounts();
            counts.Properties = Count(cls, "property");
            counts.ManyToOne = Count(cls, "many-to-one");
            counts.OneToOne = Count(cls, "one-to-one");
            counts.Collections = Count(cls, "set") + Count(cls, "bag") + Count(cls, "list") + Count(cls, "map") + Count(cls, "idbag");
            counts.ManyToMany = Count(cls, "many-to-many");
            counts.Components = Count(cls, "component") + Count(cls, "dynamic-component") + Count(cls, "composite-element");
            counts.HasCompositeId = Any(cls, "composite-id");
            counts.HasVersion = Any(cls, "version");
            counts.HasNaturalId = Any(cls, "natural-id");
            counts.FormulaCount = CountAttr(cls, "formula");
            counts.IndexedCount = CountAttr(cls, "index", v => !string.IsNullOrWhiteSpace(v));
            counts.NotnullCount = CountAttr(cls, "not-null", v => v.Equals("true", StringComparison.OrdinalIgnoreCase));
            counts.UniqueCount = CountAttr(cls, "unique", v => v.Equals("true", StringComparison.OrdinalIgnoreCase));
            counts.IdCount = Count(cls, "id");

            // Cascades
            var relElems = cls.Descendants().Where(e =>
                e.Name.LocalName == "many-to-one" ||
                e.Name.LocalName == "one-to-one" ||
                e.Name.LocalName == "many-to-many" ||
                e.Name.LocalName == "set" || e.Name.LocalName == "bag" || e.Name.LocalName == "list" || e.Name.LocalName == "map" || e.Name.LocalName == "idbag");
            foreach (var r in relElems)
            {
                var c = (Attr(r, "cascade") ?? "").ToLowerInvariant();
                if (c.Contains("delete-orphan")) counts.CascadeHard++;
                else if (c.Contains("all") || c.Contains("save-update") || c.Contains("delete")) counts.CascadeSoft++;
            }

            counts.RelationshipsTotal = counts.ManyToOne + counts.OneToOne + counts.ManyToMany + counts.Collections;
            counts.AttributesTotal = counts.Properties + counts.Components;

            // Metadata
            string entity = Attr(cls, "name") ?? Attr(cls, "entity-name") ?? "";
            string table = Attr(cls, "table") ?? Attr(cls, "table-name") ?? "";
            string schema = Attr(cls, "schema") ?? "";
            string where = Attr(cls, "where") ?? "";
            string lazy = Attr(cls, "lazy") ?? "";
            string kind = cls.Name.LocalName;

            // Queries
            var classHql = cls.Descendants().Where(e => e.Name.LocalName == "query").ToList();
            var classSql = cls.Descendants().Where(e => e.Name.LocalName == "sql-query").ToList();

            var hql = new List<QueryDef>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var q in classHql.Concat(fileHql))
            {
                var nm = Attr(q, "name") ?? "";
                if (seen.Add(nm))
                    hql.Add(new QueryDef { Name = nm, Text = InnerText(q) });
            }

            var sql = new List<QueryDef>();
            seen.Clear();
            foreach (var q in classSql.Concat(fileSql))
            {
                var nm = Attr(q, "name") ?? "";
                if (seen.Add(nm))
                    sql.Add(new QueryDef { Name = nm, Text = InnerText(q) });
            }

            counts.QueryCount = hql.Count;
            counts.SqlQueryCount = sql.Count;

            // Complexity
            double complexity = 0;
            complexity += counts.Properties * 1.0;
            complexity += counts.ManyToOne * 2.0;
            complexity += counts.OneToOne * 3.0;
            complexity += counts.Collections * 3.0;
            complexity += counts.ManyToMany * 4.0;
            complexity += counts.Components * 2.5;
            complexity += (counts.HasCompositeId ? 1 : 0) * 5.0;
            complexity += (counts.HasVersion ? 1 : 0) * 1.0;
            complexity += (counts.HasNaturalId ? 1 : 0) * 2.0;
            complexity += counts.FormulaCount * 1.0;
            complexity += counts.IndexedCount * 0.5;
            complexity += counts.NotnullCount * 0.25;
            complexity += counts.UniqueCount * 0.5;
            complexity += counts.IdCount * 0.5;
            complexity += counts.CascadeHard * 3.0;
            complexity += counts.CascadeSoft * 1.0;
            complexity = Math.Round(complexity, 2);

            string resultMode = counts.RelationshipsTotal > 3 ? "Projection" : "Automapper";
            return new EntityMetric
            {
                Entity = entity,
                Table = table,
                Schema = schema,
                Lazy = lazy,
                Where = where,
                File = Path.GetFileName(file),
                Counts = counts,
                Complexity = complexity,
                Kind = kind,
                HqlQueries = hql,
                SqlQueries = sql,
                ResultMode = resultMode   // NEW
            };
        }

        private static int Count(XElement root, string name) => root.Descendants().Count(e => e.Name.LocalName == name);
        private static bool Any(XElement root, string name) => root.Descendants().Any(e => e.Name.LocalName == name);
        private static int CountAttr(XElement root, string attr, Func<string, bool>? pred = null)
        {
            int total = 0;
            foreach (var e in root.Descendants())
            {
                var val = e.Attribute(attr)?.Value;
                if (val == null) continue;
                if (pred == null || pred(val)) total++;
            }
            return total;
        }

        private static Thresholds ComputeThresholds(List<double> vals)
        {
            if (vals == null || vals.Count == 0) return new Thresholds();
            vals.Sort();
            double P(int p)
            {
                int n = vals.Count;
                int rank = (int)Math.Ceiling((p / 100.0) * n);
                rank = Math.Clamp(rank, 1, n);
                return vals[rank - 1];
            }
            return new Thresholds { LowMax = (int)Math.Ceiling(P(50)), MedMax = (int)Math.Ceiling(P(75)), HighMax = (int)Math.Ceiling(P(90)) };
        }

        private static string BandOf(double c, Thresholds th)
        {
            if (c <= th.LowMax) return "Low";
            if (c <= th.MedMax) return "Medium";
            if (c <= th.HighMax) return "High";
            return "Very High";
        }

        // ---------- HTML/JS template ----------
        private static string DashboardHtml(string inlineJson) => @"
<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""utf-8"" />
  <meta name=""viewport"" content=""width=device-width, initial-scale=1"" />
  <title>NHibernate Mapping Dashboard</title>
  <style>
    body{font-family:system-ui,Arial;margin:0;background:#0f172a;color:#e5e7eb}
    .container{max-width:1200px;margin:0 auto;padding:20px}
    .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px}
    .card{background:#111827;border:1px solid #1f2937;border-radius:12px;padding:14px}
    .metric{background:#0b1220;border:1px solid #1f2937;border-radius:8px;padding:6px;margin:4px;font-size:12px}
    details pre{background:#0b1220;border:1px solid #1f2937;padding:10px;border-radius:8px;overflow:auto}
    details summary{cursor:pointer;margin:8px 0;font-weight:600}
  </style>
</head>
<body>
  <script>window.__INLINE_METRICS__ = __INLINE__;</script>
  <div class=""container"">
    <h1>NHibernate Mapping Dashboard</h1>
    <div id=""cards""></div>
  </div>
  <script>
    const DATA = window.__INLINE_METRICS__;
    const ENTITIES = DATA.entities||[];
    function metric(k,v){return `<div class='metric'><b>${k}:</b> ${v}</div>`}
    function card(e){
      const c=e.counts;
      const hql=e.hqlQueries||[];
      const sql=e.sqlQueries||[];
      return `<div class='card'>
        <h2>${e.entity}</h2>
        <div>Table: ${e.table||''}</div>
        <div>Complexity: ${e.complexity} (${e.band})</div>
        ${metric('Properties',c.properties)}
        ${metric('Relations',c.relationshipsTotal)}
        ${metric('HQL Queries',hql.length)}
        ${metric('SQL Queries',sql.length)}
        ${(hql.length||sql.length)?`<details><summary>Queries</summary>
          ${hql.map(q=>`<h4>${q.name}</h4><pre><code>${q.text}</code></pre>`).join('')}
          ${sql.map(q=>`<h4>${q.name}</h4><pre><code>${q.text}</code></pre>`).join('')}
        </details>`:''}
      </div>`;
    }
    document.getElementById('cards').innerHTML=ENTITIES.map(card).join('');
  </script>
</body>
</html>";
        // ---------- models ----------
        public sealed class MetricsRoot { public Summary Summary { get; set; } = new(); public List<EntityMetric> Entities { get; set; } = new(); }
        public sealed class Summary { public int Entities { get; set; } public double MinComplexity { get; set; } public double MaxComplexity { get; set; } public double AvgComplexity { get; set; } public Dictionary<string, int> Bands { get; set; } = new(); public Thresholds Thresholds { get; set; } = new(); public List<string> SkippedFiles { get; set; } = new(); }
        public sealed class Thresholds { public int LowMax { get; set; } public int MedMax { get; set; } public int HighMax { get; set; } }
        public sealed class EntityMetric
        {
            [JsonPropertyName("entity")] public string? Entity { get; set; }
            [JsonPropertyName("table")] public string? Table { get; set; }
            [JsonPropertyName("schema")] public string? Schema { get; set; }
            [JsonPropertyName("lazy")] public string? Lazy { get; set; }
            [JsonPropertyName("where")] public string? Where { get; set; }
            [JsonPropertyName("file")] public string? File { get; set; }
            [JsonPropertyName("kind")] public string? Kind { get; set; }
            [JsonPropertyName("complexity")] public double Complexity { get; set; }
            [JsonPropertyName("band")] public string? Band { get; set; }
            [JsonPropertyName("counts")] public MetricCounts Counts { get; set; } = new();
            [JsonPropertyName("hqlQueries")] public List<QueryDef> HqlQueries { get; set; } = new();
            [JsonPropertyName("sqlQueries")] public List<QueryDef> SqlQueries { get; set; } = new();

            // NEW
            [JsonPropertyName("resultMode")] public string? ResultMode { get; set; }
        }

        public sealed class MetricCounts { public int Properties { get; set; } public int ManyToOne { get; set; } public int OneToOne { get; set; } public int Collections { get; set; } public int ManyToMany { get; set; } public int Components { get; set; } public bool HasCompositeId { get; set; } public bool HasVersion { get; set; } public bool HasNaturalId { get; set; } public int FormulaCount { get; set; } public int IndexedCount { get; set; } public int NotnullCount { get; set; } public int UniqueCount { get; set; } public int IdCount { get; set; } public int CascadeHard { get; set; } public int CascadeSoft { get; set; } public int RelationshipsTotal { get; set; } public int AttributesTotal { get; set; } public int QueryCount { get; set; } public int SqlQueryCount { get; set; } }
        public sealed class QueryDef { public string? Name { get; set; } public string? Text { get; set; } }
    }
}
