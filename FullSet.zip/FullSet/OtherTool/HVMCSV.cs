using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Globalization;

namespace HibernatePerFileExporter
{
    public class HVMCSV
    {
        // Header schema (superset)
        private static readonly string[] Header = new[] {
            "sno","hibernate","domain","tablename","namespace","type","sub_type",
            "domain_column_name","databasecolumnname","classname",
            "relationship_classname","relationship_column_name","relationship_databasecolumnname",
            "relationship_constrained","relationship_property_ref",
            "table","keycolumn","keycolumn_property_ref","many_to_many_class","manymany_column",
            "key_property_name","key_property_column","key_property_type",
            "key_many_to_one_name","key_many_to_one_column","key_many_to_one_class",
            "columnname"
        };

        public static int Main1(string[] args)
        {
            // Usage:
            // dotnet run -- "<hbmRoot>" "<outputFolder>"
            var hbmRoot = args.Length > 0 ? args[0] : Directory.GetCurrentDirectory();
            hbmRoot = "D:\\0-AMS\\nHibernate_Generator\\HibernateFiles";
            var outputRoot = args.Length > 1 ? args[1] : Path.Combine(hbmRoot, "HbmPerFileCSVs");
            Directory.CreateDirectory(outputRoot);

            var files = Directory.EnumerateFiles(hbmRoot, "*.hbm.xml", SearchOption.AllDirectories).ToList();
            foreach (var file in files)
            {
                var rows = ParseFile(file);
                var outPath = Path.Combine(outputRoot, Path.GetFileName(file) + ".csv");
                using var sw = new StreamWriter(outPath, false, new UTF8Encoding(false));
                // write header
                sw.WriteLine(string.Join(",", Header));
                int sno = 1;
                foreach (var row in rows)
                {
                    var dict = new Dictionary<string,string>(row, StringComparer.OrdinalIgnoreCase);
                    dict["sno"] = sno.ToString(CultureInfo.InvariantCulture);
                    var cells = Header.Select(h => Csv(dict.TryGetValue(h, out var v) ? v ?? "" : ""));
                    sw.WriteLine(string.Join(",", cells));
                    sno++;
                }
            }

            Console.WriteLine($"Generated {files.Count} per-file CSVs under: {outputRoot}");
            return 0;
        }

        private static IEnumerable<Dictionary<string,string>> ParseFile(string file)
        {
            string text;
            try { text = File.ReadAllText(file); } catch { yield break; }

            // Strip DTDs and default namespaces for simpler parsing
            text = Regex.Replace(text, "<!DOCTYPE[^>]*>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            text = Regex.Replace(text, "xmlns=\"[^\"]+\"", "", RegexOptions.Singleline);

            XDocument? doc = null;
            try { doc = XDocument.Parse(text, LoadOptions.PreserveWhitespace); }
            catch { yield break; }
            if (doc?.Root is null) yield break;

            string hibernate = Path.GetFileName(file);
            var root = doc.Root;

            foreach (var cls in root.Descendants().Where(e => e.Name.LocalName is "class" or "joined-subclass" or "subclass" or "union-subclass"))
            {
                string domain = Attr(cls, "name") ?? Attr(cls, "entity-name") ?? "";
                var (ns, _short) = SplitNamespace(domain);
                string schema = Attr(cls, "schema") ?? "";
                string table = Attr(cls, "table") ?? "";
                string tablename = (!string.IsNullOrWhiteSpace(schema) && !string.IsNullOrWhiteSpace(table)) ? $"{schema}.{table}" : (table ?? schema);

                // PRIMARY (simple id)
                var idNode = cls.Descendants().FirstOrDefault(e => e.Name.LocalName == "id");
                if (idNode is not null)
                {
                    string col = Attr(idNode, "column") ?? "";
                    if (string.IsNullOrWhiteSpace(col))
                    {
                        var colEl = idNode.Descendants().FirstOrDefault(e => e.Name.LocalName == "column");
                        if (colEl is not null) col = Attr(colEl, "name") ?? "";
                    }
                    yield return Row(hibernate, domain, tablename, ns, "primarykey", "primarykey", ("columnname", col));
                }

                // COMPOSITE-ID (primary summary + detailed keys)
                var compId = cls.Descendants().FirstOrDefault(e => e.Name.LocalName == "composite-id");
                if (compId is not null)
                {
                    yield return Row(hibernate, domain, tablename, ns, "primarykey", "compositekey");
                    foreach (var kp in compId.Descendants().Where(e => e.Name.LocalName == "key-property"))
                    {
                        yield return Row(hibernate, domain, tablename, ns, "compositekey", "key-property",
                            ("key_property_name", Attr(kp, "name")),
                            ("key_property_column", Attr(kp, "column")),
                            ("key_property_type", Attr(kp, "type"))
                        );
                    }
                    foreach (var km in compId.Descendants().Where(e => e.Name.LocalName == "key-many-to-one"))
                    {
                        yield return Row(hibernate, domain, tablename, ns, "compositekey", "key-many-to-one",
                            ("key_many_to_one_name", Attr(km, "name")),
                            ("key_many_to_one_column", Attr(km, "column")),
                            ("key_many_to_one_class", Attr(km, "class"))
                        );
                    }
                }

                // PROPERTY
                foreach (var prop in cls.Descendants().Where(e => e.Name.LocalName == "property"))
                {
                    yield return Row(hibernate, domain, tablename, ns, "property", "",
                        ("domain_column_name", Attr(prop, "name")),
                        ("databasecolumnname", Attr(prop, "column")),
                        ("classname", Attr(prop, "type"))
                    );
                }

                // MANY-TO-ONE
                foreach (var mto in cls.Descendants().Where(e => e.Name.LocalName == "many-to-one"))
                {
                    string col = Attr(mto, "column") ?? "";
                    if (string.IsNullOrWhiteSpace(col))
                    {
                        var colEl = mto.Descendants().FirstOrDefault(e => e.Name.LocalName == "column");
                        if (colEl is not null) col = Attr(colEl, "name") ?? "";
                    }
                    yield return Row(hibernate, domain, tablename, ns, "many_to_one", "",
                        ("relationship_classname", Attr(mto, "class")),
                        ("relationship_column_name", Attr(mto, "name")),
                        ("relationship_databasecolumnname", col)
                    );
                }

                // ONE-TO-ONE
                foreach (var oto in cls.Descendants().Where(e => e.Name.LocalName == "one-to-one"))
                {
                    yield return Row(hibernate, domain, tablename, ns, "one_to_one", "",
                        ("relationship_classname", Attr(oto, "class")),
                        ("relationship_constrained", Attr(oto, "constrained")),
                        ("relationship_property_ref", Attr(oto, "property-ref"))
                    );
                }

                // BAG
                foreach (var bag in cls.Descendants().Where(e => e.Name.LocalName == "bag"))
                {
                    string bagName = Attr(bag, "name") ?? "";
                    string bagTable = Attr(bag, "table") ?? "";
                    var key = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "key");
                    string keyCol = key is null ? "" : Attr(key, "column") ?? "";
                    string keyPropRef = key is null ? "" : Attr(key, "property-ref") ?? "";

                    var mtm = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "many-to-many");
                    if (mtm is not null)
                    {
                        string manyManyCol = Attr(mtm, "column") ?? "";
                        if (string.IsNullOrWhiteSpace(manyManyCol))
                        {
                            var colEl = mtm.Descendants().FirstOrDefault(e => e.Name.LocalName == "column");
                            if (colEl is not null) manyManyCol = Attr(colEl, "name") ?? "";
                        }
                        yield return Row(hibernate, domain, tablename, ns, "bag_manytomany", "many_to_many",
                            ("classname", bagName),
                            ("table", bagTable),
                            ("keycolumn", keyCol),
                            ("keycolumn_property_ref", keyPropRef),
                            ("many_to_many_class", Attr(mtm, "class")),
                            ("manymany_column", manyManyCol)
                        );
                    }

                    var otm = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "one-to-many");
                    if (otm is not null)
                    {
                        yield return Row(hibernate, domain, tablename, ns, "bag_onetomany", "one_to_many",
                            ("classname", bagName),
                            ("table", bagTable),
                            ("keycolumn", keyCol)
                        );
                    }
                }

                // COMPONENT
                foreach (var comp in cls.Descendants().Where(e => e.Name.LocalName == "component"))
                {
                    string compName = Attr(comp, "name") ?? "";
                    string compClass = Attr(comp, "class") ?? "";
                    yield return Row(hibernate, domain, tablename, ns, "component", "",
                        ("classname", string.IsNullOrWhiteSpace(compClass) ? compName : compClass)
                    );
                    // Also emit component properties with sub_type marker
                    foreach (var prop in comp.Descendants().Where(e => e.Name.LocalName == "property"))
                    {
                        yield return Row(hibernate, domain, tablename, ns, "property", "component_property",
                            ("domain_column_name", $"{compName}.{Attr(prop, "name")}"),
                            ("databasecolumnname", Attr(prop, "column")),
                            ("classname", Attr(prop, "type"))
                        );
                    }
                }
            }
        }

        private static (string ns, string shortName) SplitNamespace(string fullname)
        {
            if (string.IsNullOrWhiteSpace(fullname) || !fullname.Contains('.'))
                return ("", fullname ?? "");
            var idx = fullname.LastIndexOf('.');
            return (fullname.Substring(0, idx), fullname.Substring(idx+1));
        }

        private static string? Attr(XElement e, string name) => e.Attribute(name)?.Value;
        private static string Csv(string s) => s?.Replace("\"", "\"\"") is string t ? $"\"{t}\"" : "\"\"";

        private static Dictionary<string,string> Row(string hbm, string domain, string tablename, string ns, string type, string subtype, params (string key, string? val)[] pairs)
        {
            var d = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase)
            {
                ["hibernate"] = hbm, ["domain"] = domain, ["tablename"] = tablename, ["namespace"] = ns, ["type"] = type, ["sub_type"] = subtype
            };
            foreach (var (k,v) in pairs) d[k] = v ?? "";
            return d;
        }
    }
}
