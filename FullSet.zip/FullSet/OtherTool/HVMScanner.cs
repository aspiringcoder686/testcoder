using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace HibernateHbmScanner_v3
{
    public class HVMScanner
    {
        public static int Main1(string[] args)
        {
            // Usage: dotnet run -- "<hbmRoot>" "<outputCsvPath>" "<optionalEntityRoot>"
            var hbmRoot = args.Length > 0 ? args[0] : Directory.GetCurrentDirectory();
            var output = args.Length > 1 ? args[1] : Path.Combine(hbmRoot, "hibernate_audit_v3.csv");
            var entityRoot = args.Length > 2 ? args[2] : null;

            // Build entity class index for table->class matching
            var classNameIndex = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!string.IsNullOrWhiteSpace(entityRoot) && Directory.Exists(entityRoot))
            {
                foreach (var cs in Directory.EnumerateFiles(entityRoot, "*.cs", SearchOption.AllDirectories))
                {
                    string text;
                    try { text = File.ReadAllText(cs); } catch { continue; }
                    foreach (var name in ClassNames(text))
                        classNameIndex.Add(name);
                }
            }

            var rows = new List<Row>();
            var files = Directory.EnumerateFiles(hbmRoot, "*.hbm.xml", SearchOption.AllDirectories).ToList();
            foreach (var file in files)
            {
                rows.AddRange(ParseFile(file, classNameIndex));
            }

            using var sw = new StreamWriter(output, false, new UTF8Encoding(false));
            sw.WriteLine("sno,hibernatefile,domain,entityname,tablename,id,relationship_count,property_count,bag_onetomany_count,bag_manytomany_count,many_to_one_count,many_to_many_count,one_to_many_count,set_count,join_count,query_count,sqlquery_count,compositekey_count,component_count,complexity");
            int sno = 1;
            foreach (var r in rows)
            {
                sw.WriteLine($"{sno},{Csv(r.HibernateFile)},{Csv(r.Domain)},{Csv(r.EntityName)},{Csv(r.TableName)},{Csv(r.Id)},{r.RelationshipCount},{r.PropertyCount},{r.BagOneToManyCount},{r.BagManyToManyCount},{r.ManyToOneCount},{r.ManyToManyCount},{r.OneToManyCount},{r.SetCount},{r.JoinCount},{r.QueryCount},{r.SqlQueryCount},{r.CompositeKeyCount},{r.ComponentCount},{r.Complexity}");
                sno++;
            }

            Console.WriteLine($"Scanned {files.Count} hbm files -> {rows.Count} class mappings");
            Console.WriteLine($"CSV: {output}");
            return 0;
        }

        private static IEnumerable<Row> ParseFile(string file, HashSet<string> entityClassNames)
        {
            string text;
            try { text = File.ReadAllText(file); } catch { yield break; }

            // Strip DTDs & default namespaces for easier parsing
            text = Regex.Replace(text, "<!DOCTYPE[^>]*>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            text = Regex.Replace(text, "xmlns=\"[^\"]+\"", "", RegexOptions.Singleline);

            XDocument? doc = null;
            try { doc = XDocument.Parse(text, LoadOptions.PreserveWhitespace); }
            catch { yield break; }
            if (doc?.Root is null) yield break;

            var root = doc.Root;

            // File-level named queries (fallback when class has none)
            int fileQuery = root.Descendants().Count(e => e.Name.LocalName == "query");
            int fileSqlQuery = root.Descendants().Count(e => e.Name.LocalName == "sql-query");

            foreach (var cls in root.Descendants().Where(e => e.Name.LocalName is "class" or "joined-subclass" or "subclass" or "union-subclass"))
            {
                string domainFull = Attr(cls, "name") ?? Attr(cls, "entity-name") ?? "";
                string schema = Attr(cls, "schema") ?? "";
                string table = Attr(cls, "table") ?? "";
                string tableName = (!string.IsNullOrWhiteSpace(schema) && !string.IsNullOrWhiteSpace(table)) ? $"{schema}.{table}" : (table ?? schema);

                // ID
                string id = "";
                int compositeKeyCount = 0;
                var idNode = cls.Descendants().FirstOrDefault(e => e.Name.LocalName == "id");
                var compId = cls.Descendants().FirstOrDefault(e => e.Name.LocalName == "composite-id");
                if (idNode is not null)
                {
                    id = Attr(idNode, "name") ?? Attr(idNode, "column") ?? "";
                }
                else if (compId is not null)
                {
                    var keys = compId.Descendants().Where(e => e.Name.LocalName == "key-property" || e.Name.LocalName == "key-many-to-one")
                                                 .Select(e => Attr(e, "name"))
                                                 .Where(n => !string.IsNullOrWhiteSpace(n))
                                                 .ToList();
                    id = keys.Count > 0 ? string.Join(" + ", keys!) : "composite";
                    compositeKeyCount = keys.Count;
                }

                // counts
                int propertyCount = cls.Descendants().Count(e => e.Name.LocalName == "property");
                int manyToOneCount = cls.Descendants().Count(e => e.Name.LocalName == "many-to-one");
                int manyToManyCount = cls.Descendants().Count(e => e.Name.LocalName == "many-to-many");
                int oneToManyCount = cls.Descendants().Count(e => e.Name.LocalName == "one-to-many");
                int setCount = cls.Descendants().Count(e => e.Name.LocalName == "set");
                int joinCount = cls.Descendants().Count(e => e.Name.LocalName == "join");

                int bagOneToManyCount = 0;
                int bagManyToManyCount = 0;
                foreach (var bag in cls.Descendants().Where(e => e.Name.LocalName == "bag"))
                {
                    if (bag.Descendants().Any(e => e.Name.LocalName == "one-to-many")) bagOneToManyCount++;
                    if (bag.Descendants().Any(e => e.Name.LocalName == "many-to-many")) bagManyToManyCount++;
                }

                int queryCount = cls.Descendants().Count(e => e.Name.LocalName == "query");
                int sqlQueryCount = cls.Descendants().Count(e => e.Name.LocalName == "sql-query");
                if (queryCount == 0 && sqlQueryCount == 0) { queryCount = fileQuery; sqlQueryCount = fileSqlQuery; }

                int componentCount = cls.Descendants().Count(e => e.Name.LocalName == "component" || e.Name.LocalName == "dynamic-component" || e.Name.LocalName == "composite-element");

                int relationshipCount = manyToOneCount + manyToManyCount + oneToManyCount + bagOneToManyCount + bagManyToManyCount + setCount;

                // entity match
                string entityName = "";
                if (!string.IsNullOrWhiteSpace(table))
                {
                    var norm = Normalize(table);
                    entityName = entityClassNames.FirstOrDefault(n => Normalize(n) == norm) ?? "";
                }

                // complexity
                int score = propertyCount*1 + manyToOneCount*2 + oneToManyCount*3 + manyToManyCount*4 + bagOneToManyCount*2 + bagManyToManyCount*3 + setCount*2 + joinCount*1 + compositeKeyCount*2 + componentCount*1 + queryCount*2 + sqlQueryCount*3;
                string complexity = score <= 5 ? "Low" : score <= 15 ? "Medium" : score <= 30 ? "High" : "VeryHigh";

                yield return new Row
                {
                    HibernateFile = Path.GetFileName(file),
                    Domain = domainFull,
                    EntityName = entityName,
                    TableName = tableName ?? "",
                    Id = id,
                    RelationshipCount = relationshipCount,
                    PropertyCount = propertyCount,
                    BagOneToManyCount = bagOneToManyCount,
                    BagManyToManyCount = bagManyToManyCount,
                    ManyToOneCount = manyToOneCount,
                    ManyToManyCount = manyToManyCount,
                    OneToManyCount = oneToManyCount,
                    SetCount = setCount,
                    JoinCount = joinCount,
                    QueryCount = queryCount,
                    SqlQueryCount = sqlQueryCount,
                    CompositeKeyCount = compositeKeyCount,
                    ComponentCount = componentCount,
                    Complexity = complexity
                };
            }
        }

        private static string? Attr(XElement e, string name) => e.Attribute(name)?.Value;
        private static string Normalize(string s) => Regex.Replace(s.ToLowerInvariant(), "[^a-z0-9]", "");

        private static IEnumerable<string> ClassNames(string text)
        {
            var rx = new Regex(@"\b(public|internal)?\s*(partial\s+)?(class|record|struct)\s+([A-Za-z_][A-Za-z0-9_]*)\b");
            foreach (Match m in rx.Matches(text))
                yield return m.Groups[4].Value;
        }

        private static string Csv(string s) => s?.Replace("\"", "\"\"") is string t ? $"\"{t}\"" : "\"\"";

        private sealed class Row
        {
            public string HibernateFile { get; init; } = "";
            public string Domain { get; init; } = "";
            public string EntityName { get; init; } = "";
            public string TableName { get; init; } = "";
            public string Id { get; init; } = "";
            public int RelationshipCount { get; init; }
            public int PropertyCount { get; init; }
            public int BagOneToManyCount { get; init; }
            public int BagManyToManyCount { get; init; }
            public int ManyToOneCount { get; init; }
            public int ManyToManyCount { get; init; }
            public int OneToManyCount { get; init; }
            public int SetCount { get; init; }
            public int JoinCount { get; init; }
            public int QueryCount { get; init; }
            public int SqlQueryCount { get; init; }
            public int CompositeKeyCount { get; init; }
            public int ComponentCount { get; init; }
            public string Complexity { get; init; } = "Low";
        }
    }
}
