using System.Text;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using NowBet.AMS.AdminAPI.Repositories.Models;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Automation.Common.Utility.Generators
{
    /// <summary>
    /// Generates per-entity projection helpers:
    /// 1) ProjectToDomain(...)  -> uses AutoMapper's ProjectTo (best for nested/navs)
    /// 2) Expression property   -> a raw LINQ expression with logic rules (Y/N→bool, code→object)
    ///
    /// Output: "<EntityName>Projection.cs.txt" under outputDir.
    /// </summary>
    public static class ProjectionGenerator
    {
        public static void Generate_old(List<EntityDefinition> entities, string outputDir, string efEntitiesFolder)
        {
            Directory.CreateDirectory(outputDir);
            var domainSet = new HashSet<string> { "Asset" };
            foreach (var entity in entities)
            {
                if (!domainSet.Contains(entity.Name))
                    continue;
                // Resolve EF entity class name from table (AM_* → Am*, strip underscores)
                string entityClass = MakePascalCase(efEntitiesFolder, entity.Table);
                entity.EntityClassName = entityClass;

                string domainClass = entity.Name;                            // e.g., "Asset"
                string projectionClassName = $"{entity.Name}Projection";     // e.g., "AssetProjection"
                string efEntityPath = Path.Combine(efEntitiesFolder, entityClass + ".cs");

                var sb = new StringBuilder();
                sb.AppendLine("using System;");
                sb.AppendLine("using System.Linq;");
                sb.AppendLine("using System.Linq.Expressions;");
                sb.AppendLine("using AutoMapper;");
                sb.AppendLine("using AutoMapper.QueryableExtensions;");
                sb.AppendLine("using NowBet.AMS.DataAccess.Entities;");
                sb.AppendLine($"using NowBet.AMS.Domain.{domainClass};");
                sb.AppendLine();
                sb.AppendLine("namespace NowBet.AMS.Shared.Repository.Projections");
                sb.AppendLine("{");
                sb.AppendLine($"    public static class {projectionClassName}");
                sb.AppendLine("    {");
                sb.AppendLine("        /// <summary>");
                sb.AppendLine($"        /// Uses AutoMapper configuration to translate IQueryable<{entityClass}> to IQueryable<Domain.{domainClass}.{domainClass}> via ProjectTo.");
                sb.AppendLine("        /// This preserves server-side translation and works for nested navigation mappings.");
                sb.AppendLine("        /// </summary>");
                sb.AppendLine($"        public static IQueryable<Domain.{domainClass}.{domainClass}> ProjectToDomain(this IQueryable<{entityClass}> query, IConfigurationProvider mapperConfig)");
                sb.AppendLine("        {");
                sb.AppendLine($"            return query.ProjectTo<Domain.{domainClass}.{domainClass}>(mapperConfig);");
                sb.AppendLine("        }");
                sb.AppendLine();
                sb.AppendLine("        /// <summary>");
                sb.AppendLine("        /// Raw LINQ projection Expression with built-in logic: string-flag→bool, code→object (DestType { Code = src.Field }), and name mismatches.");
                sb.AppendLine("        /// Suitable when you want an explicit Select(...) without AutoMapper. Customize placeholders as needed.");
                sb.AppendLine("        /// </summary>");
                sb.AppendLine($"        public static Expression<Func<{entityClass}, Domain.{domainClass}.{domainClass}>> Expression => src => new Domain.{domainClass}.{domainClass}");
                sb.AppendLine("        {");

                // ---- Scalar property mappings (apply logic rules) ----
                for (int i = 0; i < entity.Properties.Count; i++)
                {
                    var prop = entity.Properties[i];
                    string destProp = prop.Name;                 // domain property name
                    string srcColumn = prop.Column;              // EF column name (may contain underscores)
                    string expectedSrcPropName = srcColumn.Replace("_", ""); // for lookup in EF class
                    string destType = prop.Type ?? string.Empty; // domain property type string
                    string? srcMatch = RoslynHelper.GetMatchingPropertyFromClass(efEntityPath, expectedSrcPropName, string.Empty);

                    // Rule: string flag → bool
                    if (string.Equals(destType, "bool", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(destType, "Boolean", StringComparison.OrdinalIgnoreCase))
                    {
sb.AppendLine($"            {destProp} = string.Equals(src.{srcColumn}, \"Y\", StringComparison.CurrentCultureIgnoreCase);");
                        continue;
                    }

                    // Rule: code string → object with Code property (heuristic: type name ends with 'Type' or 'Category')
                    if (destType.EndsWith("Type", StringComparison.OrdinalIgnoreCase) ||
                        destType.EndsWith("Category", StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine($"            {destProp} = new {destType} {{ Code = src.{srcColumn} }},");
                        continue;
                    }

                    // Name mismatch → try find matching EF property (prefer stripped underscore)
                    if (!string.Equals(destProp, srcColumn, StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(srcMatch))
                    {
                        sb.AppendLine($"            {destProp} = src.{srcMatch},");
                        continue;
                    }

                    // Default direct map
                    sb.AppendLine($"            {destProp} = src.{srcColumn},");
                }

                // ---- Relationship mappings (emit placeholders to be safe on type mismatches) ----
                //if (entity.Relationships != null && entity.Relationships.Count > 0)
                //{
                //    sb.AppendLine();
                //    sb.AppendLine("            // Relationships (manualize as needed):");
                //    foreach (var rel in entity.Relationships)
                //    {
                //        // We attempt to find a nav property name on the EF entity that best matches
                //        string? navMatch = RoslynHelper.GetMatchingPropertyFromClass(efEntityPath, rel.Name, rel.Class?.Split('.').Last() ?? string.Empty, preferTypeMatch: true);
                //        if (!string.IsNullOrEmpty(navMatch))
                //        {
                //            sb.AppendLine($"            // {rel.Name} = src.{navMatch},  // If Domain type matches EF nav type; otherwise map fields here");
                //        }
                //        else
                //        {
                //            sb.AppendLine($"            // {rel.Name} = /* src.<navigation> or src.<join>.Select(x => x.<target>) */,");
                //        }
                //    }
                //}

                if (entity.Relationships != null && entity.Relationships.Count > 0)
                {
                    sb.AppendLine();
                    sb.AppendLine("            // Relationships:");
                    foreach (var rel in entity.Relationships)
                    {
                        // Step 1: Resolve related entity
                        string relEntityName = rel.Class?.Split('.').Last() ?? "";
                        var relatedEntity = entities.FirstOrDefault(e => e.Name == relEntityName);
                        if (relatedEntity == null) continue;

                        // Step 2: Get EF class name
                        string relEntityClass = MakePascalCase(efEntitiesFolder, relatedEntity.Table);

                        // Step 3: Nav property name on source (e.g., AreaUnitNavigation)
                        string? navMatch = RoslynHelper.GetMatchingPropertyFromClass(
                            efEntityPath, rel.Name, relEntityClass, preferTypeMatch: true);

                        if (string.IsNullOrEmpty(navMatch))
                        {
                            sb.AppendLine($"            // {rel.Name} = /* src.<navigation> */ ,");
                            continue;
                        }

                        // Step 4: Build nested projection (depth = 1, scalar props only)
                        sb.AppendLine($"            {rel.Name} = src.{navMatch} == null ? null : new Domain.{relEntityName}.{relEntityName}");
                        sb.AppendLine("            {");

                        foreach (var p in relatedEntity.Properties)
                        {
                            sb.AppendLine($"                {p.Name} = src.{navMatch}.{p.Column.Replace("_","")},");
                        }

                        sb.AppendLine("            },");
                    }
                }


                sb.AppendLine("        };");

                sb.AppendLine("    }");
                sb.AppendLine("}");

                File.WriteAllText(Path.Combine(outputDir, $"{projectionClassName}.cs.txt"), sb.ToString());
            }
        }


        public static void Generate(List<EntityDefinition> entities, string outputDir, string efEntitiesFolder)
        {
            Directory.CreateDirectory(outputDir);
            var domainSet = new HashSet<string> { "Asset" };
            foreach (var entity in entities)
            {
                if (!domainSet.Contains(entity.Name))
                    continue;
                // Resolve EF entity class name from table (AM_* → Am*, strip underscores)
                string entityClass = MakePascalCase(efEntitiesFolder, entity.Table);
                entity.EntityClassName = entityClass;

                string domainClass = entity.Name;                            // e.g., "Asset"
                string projectionClassName = $"{entity.Name}Projection";     // e.g., "AssetProjection"
                string efEntityPath = Path.Combine(efEntitiesFolder, entityClass + ".cs");

                var sb = new StringBuilder();
                sb.AppendLine("using System;");
                sb.AppendLine("using System.Linq;");
                sb.AppendLine("using System.Linq.Expressions;");
                sb.AppendLine("using AutoMapper;");
                sb.AppendLine("using AutoMapper.QueryableExtensions;");
                sb.AppendLine("using NowBet.AMS.DataAccess.Entities;");
                sb.AppendLine($"using NowBet.AMS.Domain.{domainClass};");
                sb.AppendLine();
                sb.AppendLine("namespace NowBet.AMS.Shared.Repository.Projections");
                sb.AppendLine("{");
                sb.AppendLine($"    public static class {projectionClassName}");
                sb.AppendLine("    {");
                sb.AppendLine("        /// <summary>");
                sb.AppendLine($"        /// Uses AutoMapper configuration to translate IQueryable<{entityClass}> to IQueryable<Domain.{domainClass}.{domainClass}> via ProjectTo.");
                sb.AppendLine("        /// This preserves server-side translation and works for nested navigation mappings.");
                sb.AppendLine("        /// </summary>");
                sb.AppendLine($"        public static IQueryable<Domain.{domainClass}.{domainClass}> ProjectToDomain(this IQueryable<{entityClass}> query, IConfigurationProvider mapperConfig)");
                sb.AppendLine("        {");
                sb.AppendLine($"            return query.ProjectTo<Domain.{domainClass}.{domainClass}>(mapperConfig);");
                sb.AppendLine("        }");
                sb.AppendLine();
                sb.AppendLine("        /// <summary>");
                sb.AppendLine("        /// Raw LINQ projection Expression with built-in logic: string-flag→bool, code→object (DestType { Code = src.Field }), and name mismatches.");
                sb.AppendLine("        /// Suitable when you want an explicit Select(...) without AutoMapper. Customize placeholders as needed.");
                sb.AppendLine("        /// </summary>");
                sb.AppendLine($"        public static Expression<Func<{entityClass}, Domain.{domainClass}.{domainClass}>> Expression => src => new Domain.{domainClass}.{domainClass}");
                sb.AppendLine("        {");

                WriteEntityProjection(
    sb,
    entity,
    "src",
    "            ",
    entities,
    efEntitiesFolder,
    depth: 0,
    maxDepth: 1 // default: one-level navigation expansion
);


                sb.AppendLine("}");

                File.WriteAllText(Path.Combine(outputDir, $"{projectionClassName}.cs.txt"), sb.ToString());
            }
        }
        private static void WriteEntityProjection_old(
    StringBuilder sb,
    EntityDefinition entity,
    string srcVar,
    string indent,
    List<EntityDefinition> allEntities,
    string efEntitiesFolder,
    int depth,
    int maxDepth)
        {
            // 1. Scalars
            foreach (var prop in entity.Properties)
            {
                sb.AppendLine($"{indent}{prop.Name} = {srcVar}.{prop.Column},");
            }

            // 2. Navigation properties (stop if max depth reached)
            if (depth >= maxDepth) return;

            foreach (var rel in entity.Relationships)
            {
                var relatedEntityName = rel.Class?.Split('.').Last();
                var relatedEntity = allEntities.FirstOrDefault(e => e.Name == relatedEntityName);
                if (relatedEntity == null) continue;

                string relEntityClass = MakePascalCase(efEntitiesFolder, relatedEntity.Table);
                string navVar = $"{srcVar}.{rel.Name}Navigation"; // EF nav assumption

                sb.AppendLine($"{indent}{rel.Name} = {navVar} == null ? null : new Domain.{relatedEntity.Name}.{relatedEntity.Name}");
                sb.AppendLine($"{indent}{{");

                // Recurse into child
                WriteEntityProjection(sb, relatedEntity, navVar, indent + "    ", allEntities, efEntitiesFolder, depth + 1, maxDepth);

                sb.AppendLine($"{indent}}},");
            }
        }


        private static void WriteEntityProjection(
   StringBuilder sb,
   EntityDefinition entity,
   string srcVar,
   string indent,
   List<EntityDefinition> allEntities,
   string efEntitiesFolder,
   int depth,
   int maxDepth)
        {
            // 1. Scalars
            foreach (var prop in entity.Properties)
            {
                sb.AppendLine($"{indent}{prop.Name} = {srcVar}.{prop.Column},");
            }

            // 2. Navigation properties (stop if max depth reached)
            if (depth >= maxDepth) return;

            foreach (var rel in entity.Relationships)
            {
                var relatedEntityName = rel.Class?.Split('.').Last();
                var relatedEntity = allEntities.FirstOrDefault(e => e.Name == relatedEntityName);
                if (relatedEntity == null) continue;

                string relEntityClass = MakePascalCase(efEntitiesFolder, relatedEntity.Table);

                bool isCollection =
    rel.Type == "one-to-many" ||
    rel.Type == "many-to-many" ||
    (rel.Type == "bag" &&
     (rel.InnerType == "many-to-many" || rel.InnerType == "one-to-many"));

                if (isCollection)
                {
                    // Collection navigation: use .Select() + .ToList()
                    sb.AppendLine($"{indent}{rel.Name} = {srcVar}.{relEntityClass} == null ? null");
                    sb.AppendLine($"{indent}    : {srcVar}.{relEntityClass}.Select(a => new Domain.{relatedEntity.Name}.{relatedEntity.Name.Replace("_","")}");
                    sb.AppendLine($"{indent}    {{");
                    WriteEntityProjection(sb, relatedEntity, "a", indent + "        ", allEntities, efEntitiesFolder, depth + 1, maxDepth);
                    sb.AppendLine($"{indent}    }}).ToList(),");
                }
                else
                {
                    // Reference navigation: use null-check + new …
                    string navVar = $"{srcVar}.{rel.Name}Navigation";
                    sb.AppendLine($"{indent}{rel.Name} = {navVar} == null ? null : new Domain.{relatedEntity.Name}.{relatedEntity.Name.Replace("_", "")}");
                    sb.AppendLine($"{indent}{{");
                    WriteEntityProjection(sb, relatedEntity, navVar, indent + "    ", allEntities, efEntitiesFolder, depth + 1, maxDepth);
                    sb.AppendLine($"{indent}}},");
                }
            }

        }
        private static string MakePascalCase(string filePath, string tableName)
        {
            if (!string.IsNullOrEmpty(tableName))
            {
                if (tableName.StartsWith("AM_", StringComparison.OrdinalIgnoreCase))
                {
                    tableName = "Am" + tableName.Substring(3);  // AM_ → Am
                }
                tableName = tableName.Replace("_", "");
                tableName = FindFileNameIgnoreCase(filePath, tableName);
                tableName = tableName.Replace(".cs", "");
            }
            return tableName;
        }

        public static string? FindFileNameIgnoreCase(string folder, string name)
        {
            string target = name + ".cs";
            foreach (var file in Directory.GetFiles(folder, "*.cs"))
            {
                if (string.Equals(Path.GetFileName(file), target, StringComparison.OrdinalIgnoreCase))
                    return Path.GetFileName(file);
            }
            return name;
        }
    }

    
}
