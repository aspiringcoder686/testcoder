using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace EfIncludeScanner
{
    public class includeReviewer
    {
        public static int Main1(string[] args)
        {
            // Args: <rootDir> [outputCsvPath]
            //var root = args.Length > 0 ? args[0] : Directory.GetCurrentDirectory();
            var root = "D:\\0-AMS\\include_identifier";
            var outputCsv = args.Length > 1 ? args[1] : Path.Combine(root, "include_method_report2.csv");
            var entityOutDir = Path.Combine(Path.GetDirectoryName(outputCsv) ?? root, "EntityQueries");

            if (!Directory.Exists(root))
            {
                Console.Error.WriteLine($"Root directory not found: {root}");
                return 1;
            }

            var scanner = new IncludeScanner();
            var results = scanner.Scan(root);

            Directory.CreateDirectory(Path.GetDirectoryName(outputCsv)!);

            // Write CSV
            using (var sw = new StreamWriter(outputCsv, false, new UTF8Encoding(false)))
            {
                sw.WriteLine("sno,class,methodname,entity,noofinclude,totallines");
                int sno = 1;
                foreach (var r in results)
                {
                    sw.WriteLine($"{sno},{Csv(r.Class)},{Csv(r.MethodName)},{Csv(r.Entity)},{r.NoOfInclude},{r.TotalLines}");
                    sno++;
                }
            }

            // Write per-entity files
            Directory.CreateDirectory(entityOutDir);
            var grouped = results.Where(r => r.HasIncludeOrThenInclude)
                                 .GroupBy(r => r.Entity);
            foreach (var g in grouped)
            {
                var filePath = Path.Combine(entityOutDir, $"{SanitizeFileName(g.Key)}.cs");
                using var fw = new StreamWriter(filePath, false, new UTF8Encoding(false));
                foreach (var r in g)
                {
                    fw.WriteLine($"Class : {r.Class}");
                    fw.WriteLine($"Method name : {r.MethodName}");
                    fw.WriteLine($"No of Lines : {r.TotalLines}");
                    fw.WriteLine("Query : ");
                    fw.WriteLine(r.StatementText.Trim());
                    fw.WriteLine();
                }
            }

            Console.WriteLine($"Wrote {results.Count} rows to {outputCsv}");
            Console.WriteLine($"Wrote per-entity query files to {entityOutDir}");
            return 0;

            static string Csv(string s) => s?.Replace("\"", "\"\"") is string t ? $"\"{t}\"" : "\"\"";
            static string SanitizeFileName(string s)
            {
                foreach (var ch in Path.GetInvalidFileNameChars())
                    s = s.Replace(ch, '_');
                return s;
            }
        }
    }

    public sealed class IncludeScanner
    {
        private static readonly Regex MethodSig = new Regex(
            @"^\s*(public|private|protected|internal)\s+(?:static\s+|virtual\s+|override\s+|async\s+|sealed\s+|new\s+|partial\s+)*" +
            @"([A-Za-z0-9_<>,\[\]\.\(\)\s\?]+?)\s+([A-Za-z0-9_]+)\s*\(([^\)]*)\)\s*(\{|\=\>)",
            RegexOptions.Multiline | RegexOptions.Compiled);

        private static readonly Regex ClassDecl = new Regex(
            @"^\s*(?:public|internal|protected|private)?\s*(?:abstract\s+|sealed\s+|static\s+|partial\s+)?\s*(class|record|struct)\s+([A-Za-z0-9_]+)",
            RegexOptions.Multiline | RegexOptions.Compiled);

        private static readonly Regex Anchor = new Regex(
            @"\b([A-Za-z0-9_.]+)\s*\.\s*(FindAllAsync|FindAll|FindAsync|GetAll|GetAllAsync)\s*<\s*([A-Za-z0-9_<>,\.\s]+?)\s*>\s*\(",
            RegexOptions.Compiled);

        private const string IncludeToken = ".Include(";
        private const string ThenIncludeToken = ".ThenInclude(";

        public List<ResultRow> Scan(string rootDir)
        {
            var files = Directory.EnumerateFiles(rootDir, "*.cs", SearchOption.AllDirectories).ToList();
            var results = new List<ResultRow>();

            foreach (var file in files)
            {
                string text;
                try { text = File.ReadAllText(file); }
                catch { continue; }

                var methods = MethodBlocks(text);
                var classes = ClassBlocks(text);

                foreach (Match m in Anchor.Matches(text))
                {
                    var entity = m.Groups[3].Value.Trim().Replace("?", "");
                    int openParenIdx = m.Index + m.Length - 1;
                    var (parenSeg, lineCount) = ExtractParenSegment(text, openParenIdx);

                    // Only record items that actually have Include/ThenInclude in the lambda
                    bool hasInc = parenSeg.Contains(IncludeToken) || parenSeg.Contains(ThenIncludeToken);
                    if (!hasInc) continue;

                    var (stmtStart, stmtEnd) = FindStatementBounds(text, m.Index);
                    var statementText = text.Substring(stmtStart, stmtEnd - stmtStart);

                    string methodName = "UnknownMethod";
                    foreach (var mb in methods)
                    {
                        if (mb.Start <= m.Index && m.Index <= mb.End)
                        {
                            methodName = mb.Name;
                            break;
                        }
                    }

                    string className = "UnknownClass";
                    foreach (var cb in classes)
                    {
                        if (cb.Start <= m.Index && m.Index <= cb.End)
                        {
                            className = cb.Name;
                            break;
                        }
                    }

                    int noOfInclude = CountOccurrences(parenSeg, IncludeToken);

                    results.Add(new ResultRow
                    {
                        Class = className,
                        MethodName = methodName,
                        Entity = entity,
                        NoOfInclude = noOfInclude,
                        TotalLines = lineCount,
                        StatementText = statementText,
                        HasIncludeOrThenInclude = hasInc
                    });
                }
            }

            return results;
        }

        private static int CountOccurrences(string haystack, string needle)
        {
            if (string.IsNullOrEmpty(haystack) || string.IsNullOrEmpty(needle)) return 0;
            int count = 0, idx = 0;
            while ((idx = haystack.IndexOf(needle, idx, StringComparison.Ordinal)) >= 0)
            {
                count++;
                idx += needle.Length;
            }
            return count;
        }

        private static (int Start, int End) FindStatementBounds(string text, int indexInsideStatement)
        {
            var ok = CodeMask(text);
            int start = indexInsideStatement;
            while (start > 0)
            {
                if (text[start - 1] == '\n') break;
                if (ok[start - 1] && text[start - 1] == ';') break;
                start--;
            }
            // Move to first non-space of the line
            int ls = start;
            while (ls > 0 && text[ls - 1] != '\n') ls--;
            while (start > ls && char.IsWhiteSpace(text[start])) start++;

            int paren = 0, brack = 0, brace = 0;
            int end = indexInsideStatement;
            for (; end < text.Length; end++)
            {
                char ch = text[end];
                if (!ok[end]) continue;
                if (ch == '(') paren++;
                else if (ch == ')') { if (paren > 0) paren--; }
                else if (ch == '[') brack++;
                else if (ch == ']') { if (brack > 0) brack--; }
                else if (ch == '{') brace++;
                else if (ch == '}') { if (brace > 0) brace--; }
                else if (ch == ';' && paren == 0 && brack == 0)
                {
                    end++;
                    break;
                }
            }
            return (start, end);
        }

        private static (string Segment, int LineCount) ExtractParenSegment(string text, int openParenIndex)
        {
            var ok = CodeMask(text);
            int depth = 0;
            var sb = new StringBuilder();
            bool started = false;
            for (int i = openParenIndex; i < text.Length; i++)
            {
                char c = text[i];
                sb.Append(c);
                if (!ok[i]) continue;
                if (c == '(') { depth++; started = true; }
                else if (c == ')')
                {
                    depth--;
                    if (started && depth == 0) { i++; break; }
                }
            }
            var s = sb.ToString();
            int lines = 1 + s.Count(ch => ch == '\n');
            return (s, lines);
        }

        private static bool[] CodeMask(string text)
        {
            var ok = Enumerable.Repeat(true, text.Length).ToArray();
            bool inSL = false, inML = false, inStr = false; char strCh = '\0';
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                char nx = i + 1 < text.Length ? text[i + 1] : '\0';

                if (inSL)
                {
                    ok[i] = false;
                    if (ch == '\n') inSL = false;
                    continue;
                }
                if (inML)
                {
                    ok[i] = false;
                    if (ch == '*' && nx == '/')
                    {
                        ok[i + 1] = false; i++;
                        inML = false;
                    }
                    continue;
                }
                if (inStr)
                {
                    ok[i] = false;
                    if (ch == '\\') { if (i + 1 < text.Length) { ok[i + 1] = false; i++; } continue; }
                    if (ch == strCh) inStr = false;
                    continue;
                }

                if (ch == '/' && nx == '/') { ok[i] = ok[i + 1] = false; inSL = true; i++; continue; }
                if (ch == '/' && nx == '*') { ok[i] = ok[i + 1] = false; inML = true; i++; continue; }
                if (ch == '"' || ch == '\'') { ok[i] = false; inStr = true; strCh = ch; continue; }
            }
            return ok;
        }

        private static IEnumerable<Block> MethodBlocks(string text)
        {
            foreach (Match m in MethodSig.Matches(text))
            {
                string name = m.Groups[3].Value.Trim();
                string tail = m.Groups[5].Value;
                int start = m.Index;
                int end;

                if (tail == "{")
                {
                    end = FindBlockEnd(text, m.Index, '{', '}');
                    if (end < 0) end = m.Index + m.Length;
                }
                else
                {
                    var ok = CodeMask(text);
                    int j = m.Index + m.Length;
                    for (; j < text.Length; j++)
                    {
                        if (ok[j] && text[j] == ';') { break; }
                    }
                    end = j;
                }

                yield return new Block(name, start, end);
            }
        }

        private static IEnumerable<Block> ClassBlocks(string text)
        {
            foreach (Match m in ClassDecl.Matches(text))
            {
                string name = m.Groups[2].Value.Trim();
                int start = m.Index;
                int end = FindBlockEnd(text, m.Index, '{', '}');
                if (end < 0) end = m.Index + m.Length;
                yield return new Block(name, start, end);
            }
        }

        private static int FindBlockEnd(string text, int start, char open, char close)
        {
            var ok = CodeMask(text);
            // Find first open
            int i = text.IndexOf(open, start);
            if (i < 0) return -1;
            int depth = 0;
            for (int j = i; j < text.Length; j++)
            {
                if (!ok[j]) continue;
                char c = text[j];
                if (c == open) depth++;
                else if (c == close)
                {
                    depth--;
                    if (depth == 0) return j;
                }
            }
            return -1;
        }

        public class ResultRow
        {
            public string Class { get; set; } = "";
            public string MethodName { get; set; } = "";
            public string Entity { get; set; } = "";
            public int NoOfInclude { get; set; }
            public int TotalLines { get; set; }
            public string StatementText { get; set; } = "";
            public bool HasIncludeOrThenInclude { get; set; }
        }

        private readonly record struct Block(string Name, int Start, int End);
    }
}
