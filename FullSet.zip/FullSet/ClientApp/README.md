# NHibernate Dashboard (React + Vite)

A small React app that reads `metrics.json` and renders a searchable, filterable dashboard.
Each entity card links to the generated per-file HTML page (e.g., `Asset.hbm.xml.html`).

## Quick start
```bash
npm install
npm run dev
# open http://localhost:5173
```

## Where to put your files
- Place **your real `metrics.json`** in `public/metrics.json` (overwrite the sample).
- Copy all **generated mapping HTML files** (e.g., `*.hbm.xml.html`) into the same folder you will serve.
  - If you serve the React app directly (dev server or `npm run preview`), place them into `public/` so they’re available at runtime.
  - The app links using: `${import.meta.env.BASE_URL}${e.file}.html` → e.g., `Asset.hbm.xml.html`.

## Build for production
```bash
npm run build
# output in dist/
npm run preview
```

To serve along with your generated files, copy:
- `dist/*` to your export folder,
- `metrics.json` and all mapping `*.html` files next to it.

## Notes
- The app reads from `${import.meta.env.BASE_URL}metrics.json` so it works on subpaths too.
- Complexity bands and metrics are taken as-is from your JSON.
