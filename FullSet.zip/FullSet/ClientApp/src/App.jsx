import { useEffect, useMemo, useState } from 'react'

const BASE_HBM = import.meta.env.VITE_HBM_BASE || '/'

// utils
const num = (v) => (typeof v === 'number' ? v : v ? Number(v) : 0)

function splitDomain(entity) {
  if (!entity) return { domain: '', name: '' }
  const i = entity.lastIndexOf('.')
  return i >= 0
    ? { domain: entity.slice(0, i), name: entity.slice(i + 1) }
    : { domain: '', name: entity }
}

function toPascalFromTable(table) {
  if (!table) return ''
  const raw = table.includes('.') ? table.split('.').pop() : table
  return raw
    .split('_')
    .filter(Boolean)
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase())
    .join('')
}

function SummaryTile({ title, value }) {
  return (
    <div className="tile">
      <h3>{title}</h3>
      <div className="value">{value ?? '—'}</div>
    </div>
  )
}

function Metric({ k, v }) {
  return (
    <div className="metric">
      <div className="k">{k}</div>
      <div className="v">{typeof v === 'number' ? v.toLocaleString() : v}</div>
    </div>
  )
}

function Card({ e }) {
  const c = e.counts
  const link =
    (BASE_HBM.endsWith('/') ? BASE_HBM : BASE_HBM + '/') + `${e.file}.html`
  const derivedName =
    toPascalFromTable(e.table) || splitDomain(e.entity).name || e.entity
  const bandClass = e.band === 'Very High' ? 'Very' : e.band
  const navigate = (evt) => {
    evt.preventDefault()
    window.dispatchEvent(new CustomEvent('open-hbm', { detail: link }))
  }
  const resultMode = e.resultMode || e.ResultMode
  const hql = e.hqlQueries || e.HqlQueries || []
  const sql = e.sqlQueries || e.SqlQueries || []
  const qCount = c.query_count ?? c.queryCount ?? hql.length
  const sCount = c.sqlquery_count ?? c.sqlQueryCount ?? sql.length

  return (
    <article className="card">
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '10px',
        }}
      >
        <h2>{derivedName}</h2>
        <span className="band">
          <i className={'dot ' + bandClass} />
          {e.band}
        </span>
      </div>
      <div className="meta">
        table: <code>{e.table || ''}</code>
      </div>
      <div className="meta">
        Result Mode: <strong>{resultMode}</strong>
      </div>
      <div className="meta">
        file:{' '}
        <a href={link} onClick={navigate}>
          {e.file}
        </a>
      </div>
      <div className="metrics">
        <Metric k="Properties" v={c.properties} />
        <Metric
          k="Relations"
          v={
            c.relationshipsTotal ??
            c.relationships_total ??
            num(c.manyToOne) +
              num(c.manyToMany) +
              num(c.oneToOne) +
              num(c.collections)
          }
        />
        <Metric k="Collections" v={c.collections} />
        <Metric k="Components" v={c.components} />
        <Metric k="Composite Id" v={c.has_composite_id ? 'Yes' : 'No'} />
        <Metric k="Version" v={c.has_version ? 'Yes' : 'No'} />
        <Metric k="Indexed" v={c.indexed_count} />
        <Metric k="Not Null" v={c.notnull_count} />
        <Metric k="HQL Queries" v={qCount} />
        <Metric k="SQL Queries" v={sCount} />
      </div>
      {(hql.length || sql.length) && (
        <details>
          <summary>
            Queries ({hql.length} HQL / {sql.length} SQL)
          </summary>
          {hql.length > 0 && <h4>HQL</h4>}
          {hql.map((q) => (
            <div key={'h_' + (q.name || '')}>
              <strong>{q.name}</strong>
              <pre>
                <code>{q.text}</code>
              </pre>
            </div>
          ))}
          {sql.length > 0 && <h4>SQL</h4>}
          {sql.map((q) => (
            <div key={'s_' + (q.name || '')}>
              <strong>{q.name}</strong>
              <pre>
                <code>{q.text}</code>
              </pre>
            </div>
          ))}
        </details>
      )}
    </article>
  )
}

function buildRow(e) {
  const c = e.counts || {}
  const { domain, name: shortEntity } = splitDomain(e.entity)
  const derivedName =
    toPascalFromTable(e.table) || shortEntity || e.entity || ''
  const link =
    (BASE_HBM.endsWith('/') ? BASE_HBM : BASE_HBM + '/') + `${e.file}.html`

  return {
    __link: link,
    hibernatefile: e.file,
    domain,
    entityname: derivedName,
    tablename: e.table || '',
    id: num(c.id_count ?? c.idCount),
    relationship_count: num(
      c.relationshipsTotal ??
        c.relationships_total ??
        num(c.manyToOne) +
          num(c.manyToMany) +
          num(c.oneToOne) +
          num(c.collections)
    ),
    property_count: num(c.properties),
    bag_onetomany_count: num(c.bag_one_to_many ?? c.bag_onetomany_count),
    many_to_one_count: num(c.many_to_one ?? c.manyToOne),
    many_to_many_count: num(c.many_to_many ?? c.manyToMany),
    one_to_many_count: num(c.one_to_many ?? c.oneToOne),
    set_count: num(c.set_count),
    join_count: num(c.join_count),
    query_count: num(c.query_count ?? (e.hqlQueries?.length || 0)),
    sqlquery_count: num(c.sqlquery_count ?? (e.sqlQueries?.length || 0)),
    compositekey_count: num(
      c.compositekey_count ?? (c.has_composite_id ? 1 : 0)
    ),
    component_count: num(c.components),
    complexity: e.complexity,
    band: e.band,
    resultMode: e.resultMode || e.ResultMode,
  }
}

function TableView({ rows, onRowClick }) {
  const headers = [
    ['hibernatefile', 'Hibernate File'],
    ['domain', 'Domain'],
    ['entityname', 'Entity Name'],
    ['tablename', 'Table Name'],
    ['id', 'Id'],
    ['relationship_count', 'Relationships'],
    ['property_count', 'Properties'],
    ['many_to_one_count', 'ManyToOne'],
    ['one_to_many_count', 'OneToMany'],
    ['set_count', 'Set Count'],
    ['join_count', 'Join Count'],
    ['query_count', 'HQL Queries'],
    ['sqlquery_count', 'SQL Queries'],
    ['compositekey_count', 'Composite Key Count'],
    ['component_count', 'Components'],
    ['complexity', 'Complexity'],
    ['resultMode', 'Result Mode'],
  ]

  return (
    <div className="table-wrap">
      <table className="grid-table">
        <thead>
          <tr>
            {headers.map(([key, label]) => (
              <th key={key}>{label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx) => (
            <tr key={r.hibernatefile + '_' + idx} onClick={() => onRowClick(r)}>
              {headers.map(([key]) => (
                <td key={key}>{r[key] ?? ''}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function Modal({ isOpen, src, onClose }) {
  useEffect(() => {
    function onEsc(e) {
      if (e.key === 'Escape') onClose?.()
    }
    if (isOpen) window.addEventListener('keydown', onEsc)
    return () => window.removeEventListener('keydown', onEsc)
  }, [isOpen, onClose])

  if (!isOpen) return null
  const onBackdrop = (e) => {
    if (e.target === e.currentTarget) onClose?.()
  }
  return (
    <div className="modal-backdrop" onMouseDown={onBackdrop}>
      <div className="modal">
        <button className="modal-close" onClick={onClose} aria-label="Close">
          ×
        </button>
        <iframe
          className="modal-frame"
          src={src}
          title="Mapping preview"
        ></iframe>
      </div>
    </div>
  )
}

export default function App() {
  const [data, setData] = useState(null)

  // separate search boxes
  const [qEntity, setQEntity] = useState('')
  const [qName, setQName] = useState('')
  const [qHql, setQHql] = useState('')
  const [qSql, setQSql] = useState('')

  const [band, setBand] = useState('')
  const [sort, setSort] = useState('complexity-desc')
  const [extra, setExtra] = useState('')
  const [view, setView] = useState('cards')
  const [mode, setMode] = useState('')
  const [modalSrc, setModalSrc] = useState(null)

  useEffect(() => {
    fetch('/metrics.json')
      .then((r) => r.json())
      .then(setData)
      .catch((err) => {
        console.error('Failed to load metrics.json', err)
        alert('Failed to load metrics.json')
      })
  }, [])

  useEffect(() => {
    function onOpen(e) {
      setModalSrc(e.detail)
    }
    window.addEventListener('open-hbm', onOpen)
    return () => window.removeEventListener('open-hbm', onOpen)
  }, [])

  const list = useMemo(() => {
    if (!data) return []
    let arr = data.entities.slice()

    // entity/table filter
    if (qEntity.trim()) {
      const q = qEntity.toLowerCase()
      arr = arr.filter(
        (e) =>
          (e.entity || '').toLowerCase().includes(q) ||
          (e.table || '').toLowerCase().includes(q) ||
          (toPascalFromTable(e.table) || splitDomain(e.entity).name)
            .toLowerCase()
            .includes(q)
      )
    }

    // query name filter
    if (qName.trim()) {
      const q = qName.toLowerCase()
      arr = arr.filter((e) => {
        const hql = e.hqlQueries || e.HqlQueries || []
        const sql = e.sqlQueries || e.SqlQueries || []
        return (
          hql.some((x) => (x.name || '').toLowerCase().includes(q)) ||
          sql.some((x) => (x.name || '').toLowerCase().includes(q))
        )
      })
    }

    // HQL text filter
    if (qHql.trim()) {
      const q = qHql.toLowerCase()
      arr = arr.filter((e) =>
        (e.hqlQueries || e.HqlQueries || []).some((x) =>
          (x.text || '').toLowerCase().includes(q)
        )
      )
    }

    // SQL text filter
    if (qSql.trim()) {
      const q = qSql.toLowerCase()
      arr = arr.filter((e) =>
        (e.sqlQueries || e.SqlQueries || []).some((x) =>
          (x.text || '').toLowerCase().includes(q)
        )
      )
    }

    // existing filters
    if (band) arr = arr.filter((e) => e.band === band)
    if (mode)
      arr = arr.filter(
        (e) => (e.resultMode || e.ResultMode || '').toLowerCase() === mode
      )

    if (extra === 'heavy-relations')
      arr = arr.filter((e) => num((e.counts || {}).relationshipsTotal) >= 5)
    if (extra === 'composite-id')
      arr = arr.filter((e) => !!e.counts.has_composite_id)
    if (extra === 'has-hql')
      arr = arr.filter((e) => (e.hqlQueries?.length || 0) > 0)
    if (extra === 'has-sql')
      arr = arr.filter((e) => (e.sqlQueries?.length || 0) > 0)

    if (sort === 'complexity-desc')
      arr.sort((a, b) => b.complexity - a.complexity)
    if (sort === 'complexity-asc')
      arr.sort((a, b) => a.complexity - b.complexity)
    if (sort === 'name-asc')
      arr.sort((a, b) =>
        (
          toPascalFromTable(a.table) || splitDomain(a.entity).name
        ).localeCompare(
          toPascalFromTable(b.table) || splitDomain(b.entity).name
        )
      )
    if (sort === 'name-desc')
      arr.sort((a, b) =>
        (
          toPascalFromTable(b.table) || splitDomain(b.entity).name
        ).localeCompare(
          toPascalFromTable(a.table) || splitDomain(a.entity).name
        )
      )

    return arr
  }, [data, qEntity, qName, qHql, qSql, band, mode, sort, extra])

  const s = data?.summary
  const rows = useMemo(() => list.map(buildRow), [list])
  const openRow = (row) => setModalSrc(row.__link)

  return (
    <div className="container">
      <h1>NHibernate Mapping Dashboard</h1>

      <section className="summary">
        <SummaryTile title="Total" value={s?.entities} />
        <SummaryTile title="Low" value={s?.bands?.['Low'] || 0} />
        <SummaryTile title="Medium" value={s?.bands?.['Medium'] || 0} />
        <SummaryTile
          title="High / Very High"
          value={`${s?.bands?.['High'] || 0} / ${s?.bands?.['Very High'] || 0}`}
        />
      </section>

      <div className="filters">
        <input
          placeholder="Search entity / table…"
          value={qEntity}
          onChange={(e) => setQEntity(e.target.value)}
        />
        <input
          placeholder="Search query name…"
          value={qName}
          onChange={(e) => setQName(e.target.value)}
        />
        <input
          placeholder="Search HQL text…"
          value={qHql}
          onChange={(e) => setQHql(e.target.value)}
        />
        <input
          placeholder="Search SQL text…"
          value={qSql}
          onChange={(e) => setQSql(e.target.value)}
        />

        <select value={band} onChange={(e) => setBand(e.target.value)}>
          <option value="">All complexities</option>
          <option>Low</option>
          <option>Medium</option>
          <option>High</option>
          <option>Very High</option>
        </select>
        <select value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="">All modes</option>
          <option value="projection">Projection</option>
          <option value="automapper">Automapper</option>
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="complexity-desc">Sort: Complexity ↓</option>
          <option value="complexity-asc">Sort: Complexity ↑</option>
          <option value="name-asc">Sort: Name A→Z</option>
          <option value="name-desc">Sort: Name Z→A</option>
        </select>
        <div>
          <select value={extra} onChange={(e) => setExtra(e.target.value)}>
            <option value="">More filters…</option>
            <option value="heavy-relations">Heavy relations (≥5)</option>
            <option value="composite-id">Composite Id</option>
            <option value="has-hql">Has HQL query</option>
            <option value="has-sql">Has SQL query</option>
          </select>
        </div>
      </div>

      <div
        className="toolbar"
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <span>{list.length} result(s)</span>
        <div>
          <label style={{ marginRight: 8 }}>View:</label>
          <select value={view} onChange={(e) => setView(e.target.value)}>
            <option value="cards">Cards</option>
            <option value="table">Table</option>
          </select>
        </div>
      </div>

      {view === 'cards' ? (
        <section className="cards">
          {list.map((e) => (
            <Card key={(e.entity || '') + '_' + (e.file || '')} e={e} />
          ))}
        </section>
      ) : (
        <TableView rows={rows} onRowClick={openRow} />
      )}

      <Modal
        isOpen={!!modalSrc}
        src={modalSrc}
        onClose={() => setModalSrc(null)}
      />
    </div>
  )
}
