using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Xml.Linq;
using System.Collections.Generic;

namespace HibernateHbmHtmlExporter_v3
{
    public class Program
    {
        public static int Main(string[] args)
        {
            // Usage: dotnet run -- "<hbmRoot>" "<outputFolder>"
            var hbmRoot = args.Length > 0 ? args[0] : Directory.GetCurrentDirectory();
            hbmRoot = "D:\\0-AMS\\nHibernate_Generator\\HibernateFiles";
            var outRoot = args.Length > 1 ? args[1] : Path.Combine(hbmRoot, "HbmHtmlDocs_v3");
            Directory.CreateDirectory(outRoot);

            var files = Directory.EnumerateFiles(hbmRoot, "*.hbm.xml", SearchOption.AllDirectories).ToList();
            int count = 0;
            foreach (var file in files)
            {
                var html = BuildHtmlForFile(file);
                if (!string.IsNullOrWhiteSpace(html))
                {
                    var outPath = Path.Combine(outRoot, Path.GetFileName(file) + ".html");
                    File.WriteAllText(outPath, html!, new UTF8Encoding(false));
                    count++;
                }
            }

            // Index
            var idx = new StringBuilder();
            idx.Append($@"<!doctype html>
<html><head><meta charset=""utf-8""><title>HBM HTML Docs (v3)</title><style>{Css()}</style><script>{Js()}</script></head>
<body>
<h1>HBM HTML Docs (v3)</h1>
<p>{count} files</p>
<div class=""controls""><button onclick=""toggleAll(true)"">Expand all</button><button onclick=""toggleAll(false)"">Collapse all</button></div>
<ul>");
            foreach (var name in Directory.EnumerateFiles(outRoot, "*.html", SearchOption.TopDirectoryOnly).Select(Path.GetFileName).OrderBy(s => s))
            {
                idx.Append($@"<li><a href=""{Html(name)}"">{Html(name)}</a></li>");
            }
            idx.Append("</ul></body></html>");
            File.WriteAllText(Path.Combine(outRoot, "files.html"), idx.ToString(), new UTF8Encoding(false));

            
            // Build dashboard index.html + metrics.json
            HbmMetricsDashboard.Generate(hbmRoot, outRoot);
Console.WriteLine($"Generated {count} HTML files at: {outRoot}");
            return 0;
        }

        private static string? BuildHtmlForFile(string file)
        {
            string text;
            try { text = File.ReadAllText(file); } catch { return null; }

            // Keep namespaces intact; we'll match by LocalName
            text = System.Text.RegularExpressions.Regex.Replace(text, "<!DOCTYPE[^>]*>", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Singleline);

            XDocument? doc;
            try { doc = XDocument.Parse(text, LoadOptions.PreserveWhitespace); } catch { return null; }
            if (doc?.Root is null) return null;
            var root = doc.Root;

            // Class-like nodes by LocalName
            var classes = root!.Descendants().Where(e => e.Name.LocalName is "class" or "joined-subclass" or "subclass" or "union-subclass").ToList();

            // File-level queries (namespace-agnostic)
            var fileHql = root!.Descendants().Where(e => e.Name.LocalName == "query").ToList();
            var fileSql = root!.Descendants().Where(e => e.Name.LocalName == "sql-query").ToList();

            // Complexity across all classes
            int fileScore = classes.Sum(ComputeComplexity);
            var (label, cssc) = ComplexityLabel(fileScore);

            var title = Path.GetFileName(file);
            var sb = new StringBuilder();
            sb.Append($@"<!doctype html>
<html>
<head>
<meta charset=""utf-8"">
<title>{Html(title)} • Complexity: {fileScore} ({label})</title>
<style>{Css()}</style>
<script>{Js()}</script>
</head>
<body>
<h1>{Html(title)} <span class=""complexity {cssc}"">Complexity: {fileScore} ({label})</span></h1>
<div class=""controls""><button onclick=""toggleAll(true)"">Expand all</button> <button onclick=""toggleAll(false)"">Collapse all</button></div>
");

            // File summary with query counts
            sb.Append($@"<div class=""meta""><div><b>File:</b> {Html(title)}</div><div class=""small"">Classes {classes.Count}, file-level HQL queries {fileHql.Count}, file-level SQL queries {fileSql.Count}</div></div>");

            foreach (var cls in classes)
            {
                var domain = Attr(cls, "name") ?? Attr(cls, "entity-name") ?? "";
                var schema = Attr(cls, "schema") ?? "";
                var table  = Attr(cls, "table") ?? "";
                var tableName = (!string.IsNullOrWhiteSpace(schema) && !string.IsNullOrWhiteSpace(table)) ? $"{schema}.{table}" : (table ?? schema);

                var idNode = cls.Descendants().FirstOrDefault(e => e.Name.LocalName == "id");
                var comp   = cls.Descendants().FirstOrDefault(e => e.Name.LocalName == "composite-id");
                var props  = cls.Descendants().Where(e => e.Name.LocalName == "property").ToList();
                var mtos   = cls.Descendants().Where(e => e.Name.LocalName == "many-to-one").ToList();
                var otos   = cls.Descendants().Where(e => e.Name.LocalName == "one-to-one").ToList();
                var bags   = cls.Descendants().Where(e => e.Name.LocalName == "bag").ToList();
                var sets   = cls.Descendants().Where(e => e.Name.LocalName == "set").ToList();
                var joins  = cls.Descendants().Where(e => e.Name.LocalName == "join").ToList();
                var qCls   = cls.Descendants().Where(e => e.Name.LocalName == "query").ToList();
                var sqlCls = cls.Descendants().Where(e => e.Name.LocalName == "sql-query").ToList();

                var bagMtmCount = bags.Count(b => b.Descendants().Any(x => x.Name.LocalName == "many-to-many"));
                var bagOtmCount = bags.Count(b => b.Descendants().Any(x => x.Name.LocalName == "one-to-many"));
                var summary = $"properties {props.Count}, mto {mtos.Count}, oto {otos.Count}, bag mtm {bagMtmCount}, bag otm {bagOtmCount}, sets {sets.Count}, joins {joins.Count}, queries {qCls.Count}, sql {sqlCls.Count}";

                sb.Append($@"<div class=""meta""><div><b>Domain:</b> {Html(domain)}</div><div><b>Table:</b> {Html(tableName)}</div><div class=""small"">{Html(summary)}</div></div>");

                // Primary Key
                var pkRows = new List<Dictionary<string,string>>();
                if (idNode is not null)
                {
                    var gen = idNode.Descendants().FirstOrDefault(e=>e.Name.LocalName=="generator");
                    pkRows.Add(new Dictionary<string,string>{
                        ["column"] = Html(ResolveColumn(idNode)), ["name"]=Html(Attr(idNode,"name")), ["type"]=Html(Attr(idNode,"type")), ["generator"]=Html(Attr(gen, "class"))
                    });
                }
                sb.Append(Panel("Primary Key", pkRows.Count, Table(new[]{("column","Column"),("name","Name"),("type","Type"),("generator","Generator")}, pkRows)));

                // Composite Key
                if (comp is not null)
                {
                    var kp = comp.Descendants().Where(e => e.Name.LocalName == "key-property").Select(e => new Dictionary<string,string>{{"name",Html(Attr(e,"name"))},{"column",Html(Attr(e,"column"))},{"type",Html(Attr(e,"type"))}}).ToList();
                    var km = comp.Descendants().Where(e => e.Name.LocalName == "key-many-to-one").Select(e => new Dictionary<string,string>{{"name",Html(Attr(e,"name"))},{"column",Html(Attr(e,"column"))},{"class",Html(Attr(e,"class"))}}).ToList();
                    sb.Append(Panel("Composite Key - key-property", kp.Count, Table(new[]{("name","Name"),("column","Column"),("type","Type")}, kp)));
                    sb.Append(Panel("Composite Key - key-many-to-one", km.Count, Table(new[]{("name","Name"),("column","Column"),("class","Class")}, km)));
                }

                // Properties
                var propRows = props.Select(p => new Dictionary<string,string>{
                    ["name"]=Html(Attr(p,"name")),["column"]=Html(ResolveColumn(p)),["type"]=Html(Attr(p,"type")),["length"]=Html(Attr(p,"length")),["notnull"]=Html(Attr(p,"not-null")),["unique"]=Html(Attr(p,"unique")),["insert"]=Html(Attr(p,"insert")),["update"]=Html(Attr(p,"update"))
                }).ToList();
                sb.Append(Panel("Properties", propRows.Count, Table(new[]{("name","Name"),("column","Column"),("type","Type"),("length","Length"),("notnull","Not Null"),("unique","Unique"),("insert","Insert"),("update","Update")}, propRows)));

                // Many-to-one
                var mtoRows = mtos.Select(m => new Dictionary<string,string>{
                    ["name"]=Html(Attr(m,"name")),["class"]=Html(Attr(m,"class")),["column"]=Html(ResolveColumn(m)),["notnull"]=Html(Attr(m,"not-null")),["cascade"]=Html(Attr(m,"cascade")),["fetch"]=Html(Attr(m,"fetch")),["lazy"]=Html(Attr(m,"lazy"))
                }).ToList();
                sb.Append(Panel("Many-to-one", mtoRows.Count, Table(new[]{("name","Name"),("class","Class"),("column","Column"),("notnull","Not Null"),("cascade","Cascade"),("fetch","Fetch"),("lazy","Lazy")}, mtoRows)));

                // One-to-one
                var otoRows = otos.Select(o => new Dictionary<string,string>{
                    ["class"]=Html(Attr(o,"class")),["constrained"]=Html(Attr(o,"constrained")),["propertyref"]=Html(Attr(o,"property-ref")),["cascade"]=Html(Attr(o,"cascade")),["fetch"]=Html(Attr(o,"fetch")),["lazy"]=Html(Attr(o,"lazy"))
                }).ToList();
                sb.Append(Panel("One-to-one", otoRows.Count, Table(new[]{("class","Class"),("constrained","Constrained"),("propertyref","Property-Ref"),("cascade","Cascade"),("fetch","Fetch"),("lazy","Lazy")}, otoRows)));

                // Bags - many-to-many
                var bagMtmRows = new List<Dictionary<string,string>>();
                foreach (var bag in bags)
                {
                    var mtm = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "many-to-many");
                    if (mtm is null) continue;
                    var key = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "key");
                    bagMtmRows.Add(new Dictionary<string,string>{
                        ["collection"]=Html(Attr(bag,"name")),
                        ["jointable"]=Html(Attr(bag,"table")),
                        ["keycolumn"]=Html(Attr(key,"column")),
                        ["keypropref"]=Html(Attr(key,"property-ref")),
                        ["targetclass"]=Html(Attr(mtm,"class")),
                        ["manymanycolumn"]=Html(ResolveColumn(mtm)),
                        ["cascade"]=Html(Attr(bag,"cascade")??Attr(mtm,"cascade")),
                        ["lazy"]=Html(Attr(bag,"lazy")),
                        ["orderby"]=Html(Attr(bag,"order-by"))
                    });
                }
                sb.Append(Panel("Bags: many-to-many", bagMtmRows.Count, Table(new[]{("collection","Collection"),("jointable","Join Table"),("keycolumn","Key Column"),("keypropref","Key Property-Ref"),("targetclass","Target Class"),("manymanycolumn","ManyMany Column"),("cascade","Cascade"),("lazy","Lazy"),("orderby","Order By")}, bagMtmRows)));

                // Bags - one-to-many
                var bagOtmRows = new List<Dictionary<string,string>>();
                foreach (var bag in bags)
                {
                    var otm = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "one-to-many");
                    if (otm is null) continue;
                    var key = bag.Descendants().FirstOrDefault(e => e.Name.LocalName == "key");
                    bagOtmRows.Add(new Dictionary<string,string>{
                        ["collection"]=Html(Attr(bag,"name")),
                        ["table"]=Html(Attr(bag,"table")),
                        ["keycolumn"]=Html(Attr(key,"column")),
                        ["targetclass"]=Html(Attr(otm,"class")),
                        ["cascade"]=Html(Attr(bag,"cascade")??Attr(otm,"cascade")),
                        ["lazy"]=Html(Attr(bag,"lazy")),
                        ["orderby"]=Html(Attr(bag,"order-by"))
                    });
                }
                sb.Append(Panel("Bags: one-to-many", bagOtmRows.Count, Table(new[]{("collection","Collection"),("table","Table"),("keycolumn","Key Column"),("targetclass","Target Class"),("cascade","Cascade"),("lazy","Lazy"),("orderby","Order By")}, bagOtmRows)));

                // Sets
                var setRows = new List<Dictionary<string,string>>();
                foreach (var st in sets)
                {
                    var mtm = st.Descendants().FirstOrDefault(e => e.Name.LocalName == "many-to-many");
                    var otm = st.Descendants().FirstOrDefault(e => e.Name.LocalName == "one-to-many");
                    var subtype = mtm is not null ? "many-to-many" : (otm is not null ? "one-to-many" : "");
                    var target = mtm is not null ? Attr(mtm,"class") : (otm is not null ? Attr(otm,"class") : "");
                    var manymanycol = mtm is not null ? ResolveColumn(mtm) : "";
                    var key = st.Descendants().FirstOrDefault(e => e.Name.LocalName == "key");
                    setRows.Add(new Dictionary<string,string>{
                        ["collection"]=Html(Attr(st,"name")),
                        ["table"]=Html(Attr(st,"table")),
                        ["keycolumn"]=Html(Attr(key,"column")),
                        ["subtype"]=Html(subtype),
                        ["targetclass"]=Html(target),
                        ["manymanycolumn"]=Html(manymanycol),
                        ["cascade"]=Html(Attr(st,"cascade")??(mtm is not null?Attr(mtm,"cascade"):"")),
                        ["lazy"]=Html(Attr(st,"lazy")),
                        ["orderby"]=Html(Attr(st,"order-by"))
                    });
                }
                sb.Append(Panel("Sets", setRows.Count, Table(new[]{("collection","Collection"),("table","Table"),("keycolumn","Key Column"),("subtype","Subtype"),("targetclass","Target Class"),("manymanycolumn","ManyMany Column"),("cascade","Cascade"),("lazy","Lazy"),("orderby","Order By")}, setRows)));

                // Joins
                var joinRows = new List<Dictionary<string,string>>();
                var joinPropRows = new List<Dictionary<string,string>>();
                foreach (var j in joins)
                {
                    var key = j.Descendants().FirstOrDefault(e => e.Name.LocalName == "key");
                    joinRows.Add(new Dictionary<string,string>{
                        ["table"]=Html(Attr(j,"table")),["schema"]=Html(Attr(j,"schema")),["inverse"]=Html(Attr(j,"inverse")),["fetch"]=Html(Attr(j,"fetch")),["keycolumn"]=Html(Attr(key,"column"))
                    });
                    foreach (var p in j.Descendants().Where(e => e.Name.LocalName == "property"))
                    {
                        joinPropRows.Add(new Dictionary<string,string>{
                            ["join_table"]=Html(Attr(j,"table")),["name"]=Html(Attr(p,"name")),["column"]=Html(Attr(p,"column")),["type"]=Html(Attr(p,"type")),["notnull"]=Html(Attr(p,"not-null")),["unique"]=Html(Attr(p,"unique"))
                        });
                    }
                }
                sb.Append(Panel("Joins", joinRows.Count, Table(new[]{("table","Table"),("schema","Schema"),("inverse","Inverse"),("fetch","Fetch"),("keycolumn","Key Column")}, joinRows)));
                sb.Append(Panel("Join Properties", joinPropRows.Count, Table(new[]{("join_table","Join Table"),("name","Name"),("column","Column"),("type","Type"),("notnull","Not Null"),("unique","Unique")}, joinPropRows)));

                // HQL
                var hqlRows = qCls.Select(q => new Dictionary<string,string>{{"name",Html(Attr(q,"name"))},{"query",$"<pre><code>{Html(InnerText(q))}</code></pre>"}}).ToList();
                sb.Append(Panel("Named Queries (HQL)", hqlRows.Count, Table(new[]{("name","Name"),("query","Query")}, hqlRows)));

                // SQL
                var sqlRows = sqlCls.Select(q => new Dictionary<string,string>{{"name",Html(Attr(q,"name"))},{"query",$"<pre><code>{Html(InnerText(q))}</code></pre>"}}).ToList();
                sb.Append(Panel("SQL Queries", sqlRows.Count, Table(new[]{("name","Name"),("query","Query")}, sqlRows)));
            }

            // File-level queries panels
            if (fileHql.Any())
            {
                var rows = fileHql.Select(q => new Dictionary<string,string>{{"name",Html(Attr(q,"name"))},{"query",$"<pre><code>{Html(InnerText(q))}</code></pre>"}}).ToList();
                sb.Append(Panel("File-level Named Queries (HQL)", rows.Count, Table(new[]{("name","Name"),("query","Query")}, rows)));
            }
            if (fileSql.Any())
            {
                var rows = fileSql.Select(q => new Dictionary<string,string>{{"name",Html(Attr(q,"name"))},{"query",$"<pre><code>{Html(InnerText(q))}</code></pre>"}}).ToList();
                sb.Append(Panel("File-level SQL Queries", rows.Count, Table(new[]{("name","Name"),("query","Query")}, rows)));
            }

            sb.Append(@"<footer>Generated by Hibernate HBM HTML Exporter v3</footer></body></html>");
            return sb.ToString();
        }

        private static int ComputeComplexity(XElement cls)
        {
            int property_count = cls.Descendants().Count(e => e.Name.LocalName == "property");
            int many_to_one = cls.Descendants().Count(e => e.Name.LocalName == "many-to-one");
            int many_to_many = cls.Descendants().Count(e => e.Name.LocalName == "many-to-many");
            int one_to_many = cls.Descendants().Count(e => e.Name.LocalName == "one-to-many");
            int set_count = cls.Descendants().Count(e => e.Name.LocalName == "set");
            int join_count = cls.Descendants().Count(e => e.Name.LocalName == "join");
            int bag_otm = cls.Descendants().Where(e => e.Name.LocalName == "bag").Count(b => b.Descendants().Any(x => x.Name.LocalName=="one-to-many"));
            int bag_mtm = cls.Descendants().Where(e => e.Name.LocalName == "bag").Count(b => b.Descendants().Any(x => x.Name.LocalName=="many-to-many"));
            int comp_keys = 0;
            foreach (var c in cls.Descendants().Where(e => e.Name.LocalName == "composite-id"))
                comp_keys += c.Descendants().Count(e => e.Name.LocalName == "key-property" || e.Name.LocalName == "key-many-to-one");
            int component_count = cls.Descendants().Count(e => e.Name.LocalName == "component" || e.Name.LocalName == "dynamic-component" || e.Name.LocalName == "composite-element");
            int query_count = cls.Descendants().Count(e => e.Name.LocalName == "query");
            int sqlquery_count = cls.Descendants().Count(e => e.Name.LocalName == "sql-query");
            int score = property_count*1 + many_to_one*2 + one_to_many*3 + many_to_many*4 + bag_otm*2 + bag_mtm*3 + set_count*2 + join_count*1 + comp_keys*2 + component_count*1 + query_count*2 + sqlquery_count*3;
            return score;
        }

        private static (string label, string cssc) ComplexityLabel(int score)
        {
            if (score <= 5) return ("Low","low");
            if (score <= 15) return ("Medium","medium");
            if (score <= 30) return ("High","high");
            return ("VeryHigh","veryhigh");
        }

        private static string Panel(string title, int count, string inner) => $@"<details><summary>{Html(title)} <span class=""badge"">{count}</span></summary>{inner}</details>";

        private static string Table((string key,string label)[] headers, List<Dictionary<string,string>> rows)
        {
            var sb = new StringBuilder();
            sb.Append("<table><thead><tr>");
            foreach (var h in headers) sb.Append($"<th>{Html(h.label)}</th>");
            sb.Append("</tr></thead><tbody>");
            if (rows.Count == 0)
            {
                sb.Append($@"<tr><td colspan=""{headers.Length}""><em>No items</em></td></tr>");
            }
            else
            {
                foreach (var r in rows)
                {
                    sb.Append("<tr>");
                    foreach (var h in headers)
                    {
                        r.TryGetValue(h.key, out var val);
                        sb.Append($"<td>{val ?? ""}</td>");
                    }
                    sb.Append("</tr>");
                }
            }
            sb.Append("</tbody></table>");
            return sb.ToString();
        }

        private static string Html(string? s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("&","&amp;").Replace("<","&lt;").Replace(">","&gt;").Replace("\"","&quot;").Replace("'","&#39;");
        }

        private static string Attr(XElement? e, string name)
        {
            if (e == null) return "";
            return e.Attribute(name)?.Value ?? "";
        }


        private static string ResolveColumn(XElement e)
        {
            var col = Attr(e,"column");
            if (!string.IsNullOrWhiteSpace(col)) return col;
            var el = e.Descendants().FirstOrDefault(n => n.Name.LocalName == "column");
            return el is null ? "" : Attr(el,"name");
        }

        private static string InnerText(XElement e)
        {
            var sb = new StringBuilder();
            foreach (var node in e.Nodes())
            {
                if (node is XCData c) sb.Append(c.Value);
                else if (node is XText t) sb.Append(t.Value);
            }
            var val = sb.ToString();
            if (string.IsNullOrWhiteSpace(val)) val = e.Value;
            return val?.Trim() ?? "";
        }

        private static string Css() => @"
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:20px;background:#fafafa;}
h1{font-size:20px;margin:0 0 12px 0}
.meta{background:#fff;border:1px solid #e5e5e5;border-radius:8px;padding:10px;margin-bottom:12px}
summary{cursor:pointer;font-weight:600}
details{background:#fff;border:1px solid #e5e5e5;border-radius:8px;margin:10px 0;padding:8px}
.badge{display:inline-block;background:#eee;border-radius:12px;padding:2px 8px;margin-left:8px;font-size:12px}
.small{font-size:12px;color:#666}
footer{margin-top:16px;color:#888;font-size:12px}
.controls{margin:10px 0}
button{padding:6px 10px;border:1px solid #ddd;background:#fff;border-radius:6px;cursor:pointer;margin-right:6px}
button:hover{background:#f3f3f3}
table{width:100%;border-collapse:collapse;margin-top:8px}
th,td{border:1px solid #eee;padding:6px 8px;text-align:left;vertical-align:top}
th{background:#f9f9f9;font-weight:600}
pre{background:#0b1021;color:#eaeaea;padding:10px;border-radius:6px;overflow:auto;margin:6px 0}
code{font-family:ui-monospace,SFMono-Regular,Consolas,Monaco,monospace}
.complexity{font-weight:600;padding:2px 8px;border-radius:12px;background:#eee;margin-left:8px}
.complexity.low{background:#d9f7be}
.complexity.medium{background:#ffe58f}
.complexity.high{background:#ffa39e}
.complexity.veryhigh{background:#ff7875}
";
        private static string Js() => @"
function toggleAll(open) {
  document.querySelectorAll('details').forEach(d => d.open = open);
}";
    }
}
