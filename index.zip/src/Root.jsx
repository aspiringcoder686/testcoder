import { useState } from 'react'
import App from './App.jsx'
import EndpointDashboard from './endpoints/EndpointDashboard.jsx'
import './endpoints/endpoints.css'

function EntityHost(){
  return (
    <div className="entity-host">
      <iframe className="entity-frame" src="/entity/index.html" title="Entity Dashboard"></iframe>
      <div className="entity-note">This tab loads your existing Entity Dashboard untouched from <code>/public/entity/index.html</code>. Replace that file with your build.</div>
    </div>
  )
}

export default function Root() {
  const [tab, setTab] = useState('entities') // 'entities' | 'endpoints'
  return (
    <>
      <nav className="topnav">
        <div className="nav-left">
          <span className="brand">NH Dashboard</span>
          <button
            className={'nav-btn' + (tab==='entities'?' active':'')}
            onClick={()=> setTab('entities')}
          >
            Entities
          </button>
          <button
            className={'nav-btn' + (tab==='endpoints'?' active':'')}
            onClick={()=> setTab('endpoints')}
          >
            Endpoints
          </button>
        </div>
      </nav>

      <main>
        {tab === 'entities' ? <App /> : <EndpointDashboard />}
      </main>
    </>
  )
}
