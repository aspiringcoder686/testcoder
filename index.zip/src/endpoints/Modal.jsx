import { useEffect } from 'react'

export default function Modal({ isOpen, src, onClose, title='Endpoint detail' }){
  useEffect(()=>{
    function onEsc(e){ if(e.key==='Escape') onClose?.() }
    if(isOpen) window.addEventListener('keydown', onEsc)
    return ()=> window.removeEventListener('keydown', onEsc)
  },[isOpen,onClose])

  if(!isOpen) return null
  function onBackdrop(e){ if(e.target===e.currentTarget) onClose?.() }

  return (
    <div className="ep-modal-backdrop" onMouseDown={onBackdrop}>
      <div className="ep-modal ep-modal--wide">
        <button className="ep-modal-close" onClick={onClose} aria-label="Close">×</button>
        <iframe className="ep-modal-frame" src={src} title={title} sandbox=""></iframe>
      </div>
    </div>
  )
}
