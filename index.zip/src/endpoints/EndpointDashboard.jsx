import { useEffect, useMemo, useState } from 'react'
import Modal from './Modal.jsx'

function Chip({ label }){
  const cls = 'ep-chip ' + (label||'').replace(/\s+/g,'').toLowerCase()
  return <span className={cls}>{label}</span>
}

function SummaryTile({ title, value }){
  return (
    <div className="ep-tile">
      <h3>{title}</h3>
      <div className="value">{value ?? '—'}</div>
    </div>
  )
}

function EndpointCard({ e, onOpen }){
  return (
    <article className="ep-card ep-endpoint-card">
      <div className="ep-card-header">
        <div className="ep-card-title">
          <h2 title={e.Controller + '.' + e.Method}>
            <a href="#" onClick={(ev)=>{ev.preventDefault(); onOpen(e)}}>{e.Controller}.{e.Method}</a>
          </h2>
          <Chip label={e.Complexity} />
          {e.NotFound ? <span className="ep-badge">NotFound</span> : null}
        </div>
        <div className="ep-meta">{(e.ControllerFile || '').split(/[\\/]/).pop()}</div>
      </div>

      <div className="ep-metrics">
        <div className="ep-metric"><div className="k">Total LOC</div><div className="v">{e.TotalLoc ?? 0}</div></div>
        <div className="ep-metric"><div className="k"># Methods</div><div className="v">{e.MethodsCount ?? 0}</div></div>
        <div className="ep-metric"><div className="k"># Classes</div><div className="v">{e.ClassesCount ?? 0}</div></div>
      </div>

      <details className="ep-details">
        <summary>Impacted entities & projects</summary>
        <div className="ep-twocol">
          <div><b>Entities</b><div className="ep-wrap">{(e.ImpactedEntities?.length? e.ImpactedEntities.join(', ') : '—')}</div></div>
          <div><b>Projects</b><div className="ep-wrap">{(e.ImpactedProjects?.length? e.ImpactedProjects.join(', ') : '—')}</div></div>
        </div>
      </details>

      <details className="ep-details">
        <summary>Impacted classes & methods</summary>
        <div className="ep-twocol">
          <div><b>Classes</b><div className="ep-wrap">{(e.ImpactedClasses?.length? e.ImpactedClasses.join(', ') : '—')}</div></div>
          <div><b>Methods</b><div className="ep-wrap">{(e.ImpactedMethods?.length? e.ImpactedMethods.join(', ') : '—')}</div></div>
        </div>
      </details>

      <details className="ep-details">
        <summary>Queries</summary>
        <div className="ep-twocol">
          <div><b>Named queries</b><div className="ep-wrap">{(e.ImpactedQueries?.Named?.length? e.ImpactedQueries.Named.map(x=> <code key={x}>{x}</code>) : '—')}</div></div>
          <div><b>Entity queries</b><div className="ep-wrap">{(e.ImpactedQueries?.Entity?.length? e.ImpactedQueries.Entity.map(x=> <code key={x}>{x}</code>) : '—')}</div></div>
          <div><b>Native SQL</b><div className="ep-wrap">{(e.ImpactedQueries?.Native?.length? e.ImpactedQueries.Native.map(x=> <code key={x}>{x}</code>) : '—')}</div></div>
          <div><b>Loaders</b><div className="ep-wrap">{(e.ImpactedQueries?.DomainLoaders?.length? e.ImpactedQueries.DomainLoaders.map(x=> <code key={x}>{x}</code>) : '—')}</div></div>
        </div>
      </details>

    </article>
  )
}

function TableView({ rows, onOpen }){
  const headers = [
    ['endpoint','Endpoint'],
    ['Complexity','Complexity'],
    ['TotalLoc','Total LOC'],
    ['MethodsCount','# Methods'],
    ['ClassesCount','# Classes'],
    ['ImpactedClasses','Impacted Classes'],
    ['ImpactedEntities','Impacted Entities'],
    ['ImpactedProjects','Projects']
  ]
  return (
    <div className="ep-table-wrap">
      <table className="ep-table">
        <thead>
          <tr>{headers.map(([k,h])=> <th key={k}>{h}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((r, idx)=>(
            <tr key={idx}>
              <td><a href="#" onClick={(e)=>{e.preventDefault(); onOpen(r.__raw)}}><b>{r.__raw.Controller}.{r.__raw.Method}</b></a>{r.__raw.NotFound ? ' (NotFound)': ''}</td>
              <td>{r.Complexity}</td>
              <td>{r.TotalLoc}</td>
              <td>{r.MethodsCount}</td>
              <td>{r.ClassesCount}</td>
              <td className="ep-wrap">{r.ImpactedClasses?.join(', ')}</td>
              <td className="ep-wrap">{r.ImpactedEntities?.join(', ')}</td>
              <td className="ep-wrap">{r.ImpactedProjects?.join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function buildRow(e){
  return {
    endpoint: `${e.Controller}.${e.Method}`,
    Complexity: e.Complexity,
    TotalLoc: e.TotalLoc || 0,
    MethodsCount: e.MethodsCount || 0,
    ClassesCount: e.ClassesCount || 0,
    ImpactedClasses: e.ImpactedClasses || [],
    ImpactedEntities: e.ImpactedEntities || [],
    ImpactedProjects: e.ImpactedProjects || [],
    __raw: e
  }
}

export default function EndpointDashboard(){
  const [data, setData] = useState(null)
  const [band, setBand] = useState('')
  const [q, setQ] = useState('')
  const [view, setView] = useState('cards')
  const [modalSrc, setModalSrc] = useState(null)

  // numeric filters
  const [locMin, setLocMin] = useState('')
  const [locMax, setLocMax] = useState('')
  const [clsMin, setClsMin] = useState('')
  const [clsMax, setClsMax] = useState('')
  const [entMin, setEntMin] = useState('')
  const [entMax, setEntMax] = useState('')

  useEffect(()=>{
    fetch('/all_metrics.json').then(r=>r.json()).then(setData).catch(err=>{
      console.error('Failed to load all_metrics.json', err)
      alert('Failed to load all_metrics.json')
    })
  },[])

  const endpoints = data?.Endpoints || []

  const filtered = useMemo(()=>{
    let arr = endpoints.slice()
    if (band) arr = arr.filter(e => (e.Complexity || '').toLowerCase() === band.toLowerCase())
    if (q.trim()) {
      const qq = q.toLowerCase()
      arr = arr.filter(e =>
        (e.Controller || '').toLowerCase().includes(qq) ||
        (e.Method || '').toLowerCase().includes(qq) ||
        (e.ImpactedEntities || []).some(x=> (x||'').toLowerCase().includes(qq)) ||
        (e.ImpactedClasses || []).some(x=> (x||'').toLowerCase().includes(qq)) ||
        (e.ImpactedProjects || []).some(x=> (x||'').toLowerCase().includes(qq))
      )
    }
    // numeric filters
    const inRange = (val, lo, hi)=> {
      if (lo !== '' && val < Number(lo)) return false
      if (hi !== '' && val > Number(hi)) return false
      return true
    }
    arr = arr.filter(e => inRange(Number(e.TotalLoc||0), locMin, locMax))
    arr = arr.filter(e => inRange(Number(e.ClassesCount||0), clsMin, clsMax))
    arr = arr.filter(e => inRange(Number((e.ImpactedEntities||[]).length), entMin, entMax))

    return arr
  }, [endpoints, band, q, locMin, locMax, clsMin, clsMax, entMin, entMax])

  const rows = useMemo(()=> filtered.map(buildRow), [filtered])
  const open = (e)=> setModalSrc(e.OutputHtml ? `/endpoint/${e.OutputHtml}` : '#')

  const groups = useMemo(()=>{
    const g = { 'Simple':[], 'Medium':[], 'High':[], 'Very High':[] }
    for (const e of filtered) {
      const k = e.Complexity && g[e.Complexity] ? e.Complexity : 'Medium'
      g[k].push(e)
    }
    return g
  }, [filtered])

  const resetFilters = ()=>{
    setQ(''); setBand(''); setLocMin(''); setLocMax(''); setClsMin(''); setClsMax(''); setEntMin(''); setEntMax('')
  }

  return (
    <div className="ep-root">
      <header><h1>Endpoint Dashboard</h1></header>

      <div className="ep-summary">
        <SummaryTile title="Total endpoints" value={endpoints.length} />
        <SummaryTile title="Simple" value={endpoints.filter(e=>e.Complexity==='Simple').length} />
        <SummaryTile title="Medium" value={endpoints.filter(e=>e.Complexity==='Medium').length} />
        <SummaryTile title="High" value={endpoints.filter(e=>e.Complexity==='High').length} />
        <SummaryTile title="Very High" value={endpoints.filter(e=>e.Complexity==='Very High').length} />
      </div>

      <div className="ep-filters">
        <input className="ep-input" placeholder="Search endpoint / class / entity…" value={q} onChange={e=>setQ(e.target.value)} />
        <select className="ep-input" value={band} onChange={(e)=> setBand(e.target.value)}>
          <option value="">All complexities</option>
          <option>Simple</option>
          <option>Medium</option>
          <option>High</option>
          <option>Very High</option>
        </select>
        <select className="ep-input" value={view} onChange={(e)=> setView(e.target.value)}>
          <option value="cards">Cards</option>
          <option value="table">Table</option>
        </select>
      </div>

      <div className="ep-filters ep-filters--grid">
        <div className="ep-frow">
          <label>Total LOC</label>
          <input className="ep-num" type="number" placeholder="Min" value={locMin} onChange={e=>setLocMin(e.target.value)} />
          <input className="ep-num" type="number" placeholder="Max" value={locMax} onChange={e=>setLocMax(e.target.value)} />
        </div>
        <div className="ep-frow">
          <label># Classes</label>
          <input className="ep-num" type="number" placeholder="Min" value={clsMin} onChange={e=>setClsMin(e.target.value)} />
          <input className="ep-num" type="number" placeholder="Max" value={clsMax} onChange={e=>setClsMax(e.target.value)} />
        </div>
        <div className="ep-frow">
          <label># Entities</label>
          <input className="ep-num" type="number" placeholder="Min" value={entMin} onChange={e=>setEntMin(e.target.value)} />
          <input className="ep-num" type="number" placeholder="Max" value={entMax} onChange={e=>setEntMax(e.target.value)} />
        </div>
        <div className="ep-frow ep-frow--actions">
          <button className="ep-btn" onClick={resetFilters}>Reset</button>
        </div>
      </div>

      {view==='cards' ? (
        <div className="ep-cards-groups">
          {(['Simple','Medium','High','Very High']).map(key => (
            <details key={key} open>
              <summary><b>{key}</b> <span className="ep-muted">({groups[key].length})</span></summary>
              <section className="ep-cards">
                {groups[key].map((e,i)=> <EndpointCard key={key+'_'+i} e={e} onOpen={open} />)}
              </section>
            </details>
          ))}
        </div>
      ) : (
        <TableView rows={rows} onOpen={open} />
      )}

      <Modal isOpen={!!modalSrc} src={modalSrc} onClose={()=> setModalSrc(null)} />
    </div>
  )
}
