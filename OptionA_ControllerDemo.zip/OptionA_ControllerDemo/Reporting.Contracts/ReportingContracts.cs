
namespace Reporting.Contracts;

public readonly record struct ReportPeriodId(Guid Value)
{
    public static implicit operator Guid(ReportPeriodId id) => id.Value;
    public static implicit operator ReportPeriodId(Guid value) => new(value);
}

public sealed record ReportPeriodDto(
    Guid Id,
    int FiscalYear,
    int Quarter,
    DateOnly StartDate,
    DateOnly EndDate
);

public interface IReportingCalendarClient
{
    Task<ReportPeriodId> GetCurrentAsync(CancellationToken ct = default);
    Task<ReportPeriodId?> TryGetByDateAsync(DateOnly date, CancellationToken ct = default);
    Task<ReportPeriodId?> TryGetPreviousAsync(ReportPeriodId id, CancellationToken ct = default);
    Task<ReportPeriodId?> TryGetNextAsync(ReportPeriodId id, CancellationToken ct = default);
}
