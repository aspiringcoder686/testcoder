
using System.Net.Http.Json;
using Reporting.Contracts;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http.Headers;

namespace Reporting.Client;

public sealed class HttpReportingCalendarClient : IReportingCalendarClient
{
    private readonly HttpClient _http;
    public HttpReportingCalendarClient(HttpClient http) => _http = http;

    public async Task<ReportPeriodId> GetCurrentAsync(CancellationToken ct = default)
    {
        var dto = await _http.GetFromJsonAsync<ReportPeriodDto>("api/v1/reportperiod/current", ct);
        if (dto is null) throw new InvalidOperationException("No current report period.");
        return new ReportPeriodId(dto.Id);
    }

    public async Task<ReportPeriodId?> TryGetByDateAsync(DateOnly date, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"api/v1/reportperiod/by-date?date={date:yyyy-MM-dd}", ct);
        if (resp.StatusCode == System.Net.HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        var dto = await resp.Content.ReadFromJsonAsync<ReportPeriodDto>(cancellationToken: ct);
        return dto is null ? null : new ReportPeriodId(dto.Id);
    }

    public async Task<ReportPeriodId?> TryGetPreviousAsync(ReportPeriodId id, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"api/v1/reportperiod/previous/{(Guid)id}", ct);
        if (resp.StatusCode == System.Net.HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        var dto = await resp.Content.ReadFromJsonAsync<ReportPeriodDto>(cancellationToken: ct);
        return dto is null ? null : new ReportPeriodId(dto.Id);
    }

    public async Task<ReportPeriodId?> TryGetNextAsync(ReportPeriodId id, CancellationToken ct = default)
    {
        var resp = await _http.GetAsync($"api/v1/reportperiod/next/{(Guid)id}", ct);
        if (resp.StatusCode == System.Net.HttpStatusCode.NotFound) return null;
        resp.EnsureSuccessStatusCode();
        var dto = await resp.Content.ReadFromJsonAsync<ReportPeriodDto>(cancellationToken: ct);
        return dto is null ? null : new ReportPeriodId(dto.Id);
    }
}

public static class ReportingClientRegistration
{
    public static IHttpClientBuilder AddReportingCalendarHttpClient(this IServiceCollection services, Uri baseAddress)
    {
        return services.AddHttpClient<IReportingCalendarClient, HttpReportingCalendarClient>(c =>
        {
            c.BaseAddress = baseAddress;
            c.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        });
    }
}
