
namespace ReportingService;

public sealed class ReportPeriod
{
    public Guid Id { get; init; }
    public int FiscalYear { get; init; }
    public int Quarter { get; init; }
    public DateOnly StartDate { get; init; }
    public DateOnly EndDate { get; init; }
}

public interface IReportPeriodRepository
{
    Task<ReportPeriod> GetCurrentAsync(CancellationToken ct = default);
    Task<ReportPeriod?> TryGetByDateAsync(DateOnly date, CancellationToken ct = default);
    Task<ReportPeriod?> TryGetPreviousAsync(Guid id, CancellationToken ct = default);
    Task<ReportPeriod?> TryGetNextAsync(Guid id, CancellationToken ct = default);
}

public sealed class InMemoryReportPeriodRepository : IReportPeriodRepository
{
    private readonly List<ReportPeriod> _rows;

    public InMemoryReportPeriodRepository()
    {
        _rows = new()
        {
            new() { Id = Guid.NewGuid(), FiscalYear = 2025, Quarter = 2, StartDate = new(2025, 4, 1), EndDate = new(2025, 6, 30) },
            new() { Id = Guid.NewGuid(), FiscalYear = 2025, Quarter = 3, StartDate = new(2025, 7, 1), EndDate = new(2025, 9, 30) },
            new() { Id = Guid.NewGuid(), FiscalYear = 2025, Quarter = 4, StartDate = new(2025, 10, 1), EndDate = new(2025, 12, 31) }
        };
    }

    public Task<ReportPeriod> GetCurrentAsync(CancellationToken ct = default)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var hit = _rows.FirstOrDefault(r => r.StartDate <= today && r.EndDate >= today)
                  ?? _rows.OrderBy(r => r.StartDate).Last();
        return Task.FromResult(hit);
    }

    public Task<ReportPeriod?> TryGetByDateAsync(DateOnly date, CancellationToken ct = default)
        => Task.FromResult(_rows.FirstOrDefault(r => r.StartDate <= date && r.EndDate >= date));

    public Task<ReportPeriod?> TryGetPreviousAsync(Guid id, CancellationToken ct = default)
    {
        var cur = _rows.FirstOrDefault(r => r.Id == id);
        if (cur is null) return Task.FromResult<ReportPeriod?>(null);
        var prev = _rows.Where(r => r.EndDate < cur.StartDate).OrderByDescending(r => r.EndDate).FirstOrDefault();
        return Task.FromResult(prev);
    }

    public Task<ReportPeriod?> TryGetNextAsync(Guid id, CancellationToken ct = default)
    {
        var cur = _rows.FirstOrDefault(r => r.Id == id);
        if (cur is null) return Task.FromResult<ReportPeriod?>(null);
        var next = _rows.Where(r => r.StartDate > cur.EndDate).OrderBy(r => r.StartDate).FirstOrDefault();
        return Task.FromResult(next);
    }
}
