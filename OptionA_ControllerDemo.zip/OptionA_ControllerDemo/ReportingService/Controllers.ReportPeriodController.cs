
using Microsoft.AspNetCore.Mvc;
using ReportingService;
using Reporting.Contracts;

namespace ReportingService.Controllers;

[ApiController]
[Route("api/v1/reportperiod")]
public sealed class ReportPeriodController : ControllerBase
{
    private readonly IReportPeriodRepository _repo;
    public ReportPeriodController(IReportPeriodRepository repo) => _repo = repo;

    [HttpGet("current")]
    public async Task<ActionResult<ReportPeriodDto>> GetCurrent(CancellationToken ct)
    {
        var r = await _repo.GetCurrentAsync(ct);
        return Ok(ToDto(r));
    }

    [HttpGet("by-date")]
    public async Task<ActionResult<ReportPeriodDto>> GetByDate([FromQuery] string date, CancellationToken ct)
    {
        if (!DateOnly.TryParse(date, out var d))
            return BadRequest("Invalid date (use yyyy-MM-dd).");
        var r = await _repo.TryGetByDateAsync(d, ct);
        if (r is null) return NotFound();
        return Ok(ToDto(r));
    }

    [HttpGet("previous/{id:guid}")]
    public async Task<ActionResult<ReportPeriodDto>> GetPrevious(Guid id, CancellationToken ct)
    {
        var r = await _repo.TryGetPreviousAsync(id, ct);
        if (r is null) return NotFound();
        return Ok(ToDto(r));
    }

    [HttpGet("next/{id:guid}")]
    public async Task<ActionResult<ReportPeriodDto>> GetNext(Guid id, CancellationToken ct)
    {
        var r = await _repo.TryGetNextAsync(id, ct);
        if (r is null) return NotFound();
        return Ok(ToDto(r));
    }

    private static ReportPeriodDto ToDto(ReportPeriod r)
        => new(r.Id, r.FiscalYear, r.Quarter, r.StartDate, r.EndDate);
}
