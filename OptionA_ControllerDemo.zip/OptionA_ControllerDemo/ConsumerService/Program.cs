﻿
using Reporting.Client;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();

var baseUrl = builder.Configuration["Reporting:BaseAddress"] ?? "http://localhost:5080/";
builder.Services.AddReportingCalendarHttpClient(new Uri(baseUrl));

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();
app.Run();
