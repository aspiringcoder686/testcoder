
using Microsoft.AspNetCore.Mvc;
using Reporting.Client;
using Reporting.Contracts;

namespace ConsumerService.Controllers;

[ApiController]
[Route("demo")]
public sealed class DemoController : ControllerBase
{
    private readonly IReportingCalendarClient _client;
    public DemoController(IReportingCalendarClient client) => _client = client;

    [HttpGet("current")]
    public async Task<IActionResult> GetCurrent(CancellationToken ct)
    {
        var id = await _client.GetCurrentAsync(ct);
        return Ok(new { ReportPeriodId = (Guid)id });
    }

    [HttpGet("by-date")]
    public async Task<IActionResult> GetByDate([FromQuery] string date, CancellationToken ct)
    {
        if (!DateOnly.TryParse(date, out var d))
            return BadRequest("Invalid date (use yyyy-MM-dd).");
        var id = await _client.TryGetByDateAsync(d, ct);
        if (id is null) return NotFound();
        return Ok(new { ReportPeriodId = (Guid)id });
    }
}
